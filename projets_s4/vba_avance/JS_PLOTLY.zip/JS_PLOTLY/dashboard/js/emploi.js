/**
 * @AI_SPACE
 * @purpose : Gestionnaire des graphiques de l'onglet Emploi.
 * @logic : Rendu de diagrammes Sunburst et barres via Plotly.react pour une comparaison interactive des taux de chômage et structures CSP.
 * @decisions : Abandon du radar au profit du sunburst pour une meilleure lisibilité des proportions hiérarchiques.
 * @references : https://plotly.com/javascript/sunburst-charts/
 */

/* ============================================================
   js/emploi.js — Onglet Emploi
   
   Graphiques produits :
     1. Taux de chômage (barres groupées + ligne nationale)
     2. NOUVEAU : Sunburst des catégories socio-professionnelles
        (remplace le radar chart — plus intuitif pour les %CSP)
     3. Taux d'emploi (barres horizontales)
   
   Pour le QCM :
     - type:'sunburst' → diagramme circulaire hiérarchique
     - labels / parents / values → structure parent-enfant obligatoire
       (le nœud racine a parent = '')
     - branchvalues:'total' → la valeur du parent = somme des enfants
     - insidetextorientation:'radial' → texte dans les secteurs
============================================================ */

'use strict';

/* ── 1. Taux de chômage ─────────────────────────────────────── */
function _renderChomage(eA, eB, nomA, nomB) {
  Plotly.react('chart-emp-chomage', [
    {
      type: 'bar', name: nomA, x: [nomA], y: [eA.taux_chomage],
      marker: { color: COLOR_A },
      hovertemplate: '<b>' + nomA + '</b><br>%{y:.1f}%<extra></extra>',
    },
    {
      type: 'bar', name: nomB, x: [nomB], y: [eB.taux_chomage],
      marker: { color: COLOR_B },
      hovertemplate: '<b>' + nomB + '</b><br>%{y:.1f}%<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', showlegend: false,
    shapes: [{
      type: 'line', x0: -0.5, x1: 1.5, y0: 7.3, y1: 7.3,
      line: { color: '#DC2626', width: 1.5, dash: 'dash' },
    }],
    annotations: [{
      x: 1.4, y: 7.3, xref: 'x', yref: 'y', text: 'Moy. nationale (7.3%)',
      showarrow: false, font: { size: 10, color: '#DC2626' }, xanchor: 'right',
    }],
    yaxis: {
      ..._baseLayout().yaxis, type: 'linear',
      range: [0, Math.max(eA.taux_chomage || 20, eB.taux_chomage || 20) + 4],
      title: { text: 'Taux (%)', font: { size: 11 } },
    },
  }), PLOTLY_CFG);
}

/* ── 2. NOUVEAU : Sunburst CSP ─────────────────────────────── */
/**
 * _renderSunburst(eA, eB, nomA, nomB)
 * Crée un Sunburst Plotly comparant les catégories socio-professionnelles.
 *
 * Structure d'un Sunburst :
 *   - labels  : noms de TOUS les nœuds (racine + enfants)
 *   - parents : pour chaque nœud, l'ID du parent ('' pour la racine)
 *   - values  : valeur numérique de chaque nœud
 *
 * Ici on crée une hiérarchie à 2 niveaux :
 *   Racine (ville) → Catégories CSP
 *
 * Comme Plotly ne gère pas nativement 2 sunbursts côte à côte,
 * on utilise le système de domain.
 *
 * @param {Object} eA - données emploi ville A
 * @param {Object} eB - données emploi ville B
 */
function _renderSunburst(eA, eB, nomA, nomB) {
  // Couleurs par catégorie CSP (même pour A et B → lecture comparative)
  const CSP_COLORS = {
    'Agriculteurs':           '#16A34A',
    'Artisans/commerçants':   '#CA8A04',
    'Cadres':                 '#1D4ED8',
    'Prof. intermédiaires':   '#7C3AED',
    'Employés':               '#0891B2',
    'Ouvriers':               '#DC2626',
    'Retraités':              '#64748B',
    'Autres inactifs':        '#94A3B8',
  };

  /**
   * buildSunburstData(emploiData, nom, column)
   * Génère les traces labels/parents/values pour un sunburst.
   * Le nœud racine a le nom de la ville, parents[0] = ''.
   */
  const buildSunburstData = (emploiData, nom, column) => {
    const csp = emploiData.categories_sociopro || {};
    const cats = Object.keys(csp);

    // Calc exact sum to satisfy Plotly branchvalues: 'total' constraint
    const childrenVals = cats.map(c => csp[c] || 0);
    const totalSum = childrenVals.reduce((a, b) => a + b, 0);

    // labels : [racine, ...catégories]
    const labels  = [nom, ...cats];
    // parents : racine → '', chaque catégorie → racine
    const parents = ['',  ...cats.map(() => nom)];
    // values : racine = total exact, chaque catégorie = sa valeur
    const values  = [totalSum, ...childrenVals];
    // couleurs
    const colors  = ['rgba(0,0,0,0)', ...cats.map(c => CSP_COLORS[c] || '#94A3B8')];

    return {
      type: 'sunburst',
      name: nom,
      labels, parents, values,
      marker: { colors },
      branchvalues: 'total',           // valeur racine = somme des enfants
      textinfo:  'label+percent parent',
      hovertemplate: '<b>%{label}</b><br>%{value:.1f}%<extra>' + nom + '</extra>',
      insidetextorientation: 'radial', // texte orienté radialement dans les secteurs
      domain: { column },
    };
  };

  Plotly.react('chart-emp-sunburst', [
    buildSunburstData(eA, nomA, 0),
    buildSunburstData(eB, nomB, 1),
  ], _baseLayout({
    grid: { rows: 1, columns: 2 },
    margin: { t: 30, r: 20, b: 30, l: 20 },
    showlegend: false,
  }), PLOTLY_CFG);
}

/* ── 3. Taux d'emploi ───────────────────────────────────────── */
function _renderTauxEmploi(eA, eB, nomA, nomB) {
  Plotly.react('chart-emp-taux', [
    {
      type: 'bar', orientation: 'h', name: nomA,
      y: [nomA], x: [eA.taux_emploi],
      marker: { color: COLOR_A },
      hovertemplate: '<b>' + nomA + '</b><br>Taux d\'emploi : %{x:.1f}%<extra></extra>',
    },
    {
      type: 'bar', orientation: 'h', name: nomB,
      y: [nomB], x: [eB.taux_emploi],
      marker: { color: COLOR_B },
      hovertemplate: '<b>' + nomB + '</b><br>Taux d\'emploi : %{x:.1f}%<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', showlegend: false,
    margin: { t: 30, r: 20, b: 40, l: 110 },
    xaxis: { ..._baseLayout().xaxis, type: 'linear', range: [0, 100], title: { text: '%', font: { size: 11 } } },
    yaxis: { ..._baseLayout().yaxis, autorange: 'reversed' },
  }), PLOTLY_CFG);
}

/* ── Orchestrateur ──────────────────────────────────────────── */
function renderEmploi(cityA, cityB) {
  const eA = cityA.emploi, eB = cityB.emploi;
  if (!eA || !eB) { console.warn('[emploi] Données manquantes'); return; }
  const nomA = cityA.base.nom, nomB = cityB.base.nom;
  try { _renderChomage(eA, eB, nomA, nomB); } catch (e) { console.error('[Emploi] Chomage error:', e); }
  try { _renderSunburst(eA, eB, nomA, nomB); } catch (e) { console.error('[Emploi] Sunburst error:', e); }
  try { _renderTauxEmploi(eA, eB, nomA, nomB); } catch (e) { console.error('[Emploi] TauxEmploi error:', e); }
}

window.EmploiChart = { renderEmploi };
