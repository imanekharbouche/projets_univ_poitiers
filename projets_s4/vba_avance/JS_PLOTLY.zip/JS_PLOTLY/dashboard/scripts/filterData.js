const fs = require('fs');
const path = require('path');

const villesFile = path.resolve(__dirname, '../data/villes.js');

try {
  console.log('[1/3] Lecture du fichier:', villesFile);
  const rawData = fs.readFileSync(villesFile, 'utf8');

  // Extraction of the JSON payload
  // Removing 'window.DATA_VILLES = ' and the trailing ';'
  const jsonStr = rawData.replace(/^\s*window\.DATA_VILLES\s*=\s*/, '').replace(/;\s*$/, '');
  
  const villesArray = JSON.parse(jsonStr);
  const initialCount = villesArray.length;
  console.log(`[2/3] Villes analysées: ${initialCount}. Filtrage population >= 20000...`);

  const filteredVilles = villesArray.filter(v => (v.population || 0) >= 20000);
  const finalCount = filteredVilles.length;

  console.log(`[3/3] Villes restantes: ${finalCount} (Supprimées: ${initialCount - finalCount})`);

  const outputJs = `window.DATA_VILLES = ${JSON.stringify(filteredVilles, null, 2)};\n`;
  fs.writeFileSync(villesFile, outputJs, 'utf8');
  
  console.log('✅ Succès: Le fichier data/villes.js a été mis à jour.');
} catch (err) {
  console.error('❌ Erreur:', err.message);
  process.exit(1);
}
