/**
 * @AI_SPACE
 * @purpose : Gestionnaire des graphiques de l'onglet Démographie/Général.
 * @logic : Utilise Plotly.react pour le rendu haute performance de pyramides des âges, répartition des sexes et jauges.
 * @decisions : Remplacement de newPlot par react pour optimiser les performances de mise à jour lors du changement de ville.
 * @references : https://plotly.com/javascript/react/
 */

/* ============================================================
   js/general.js — Onglet Démographie / Général
   
   Graphiques produits :
     1. Pyramide des âges (barres horizontales)
     2. Répartition hommes/femmes (pie charts)
     3. Population totale (barres verticales)
     4. NOUVEAU : Gauge "Pourcentage de jeunes 15-29 ans"
        (proxy pour la proportion d'étudiants + jeunes actifs)
   
   Pour le QCM :
     - type:'indicator' mode:'gauge+number' → jauge Plotly
     - gauge.axis.range → borne min/max de la jauge
     - gauge.steps → zones de couleur sur la jauge
     - gauge.threshold → ligne de référence
============================================================ */

'use strict';

/* ── 1. Pyramide des âges ──────────────────────────────────── */
function _renderPyramide(A, B) {
  const tranches = Object.keys(A.tranches_age);
  Plotly.react('chart-gen-pyramid', [
    {
      type: 'bar', orientation: 'h', name: A.nom,
      y: tranches, x: tranches.map(t => A.tranches_age[t]),
      marker: { color: COLOR_A },
      hovertemplate: '<b>%{y}</b><br>' + A.nom + ' : %{x:.1f}%<extra></extra>',
    },
    {
      type: 'bar', orientation: 'h', name: B.nom,
      y: tranches, x: tranches.map(t => B.tranches_age[t]),
      marker: { color: COLOR_B },
      hovertemplate: '<b>%{y}</b><br>' + B.nom + ' : %{x:.1f}%<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', hovermode: 'y unified',
    margin: { t: 30, r: 20, b: 40, l: 70 },
    xaxis: { ..._baseLayout().xaxis, title: { text: '% de la population', font: { size: 11 } } },
    yaxis: { ..._baseLayout().yaxis, title: null, autorange: 'reversed' },
  }), PLOTLY_CFG);
}

/* ── 2. Répartition hommes/femmes ──────────────────────────── */
function _renderSexe(A, B) {
  Plotly.react('chart-gen-sex', [
    {
      type: 'pie', name: A.nom,
      labels: ['Hommes', 'Femmes'],
      values: [A.pop_hommes, A.pop_femmes],
      domain: { column: 0 },
      marker: { colors: [COLOR_A, '#93C5FD'] },
      textinfo: 'label+percent',
      hovertemplate: '%{label} (%{percent})<extra>' + A.nom + '</extra>',
      title: { text: A.nom, font: { size: 12 } },
    },
    {
      type: 'pie', name: B.nom,
      labels: ['Hommes', 'Femmes'],
      values: [B.pop_hommes, B.pop_femmes],
      domain: { column: 1 },
      marker: { colors: [COLOR_B, '#FCD34D'] },
      textinfo: 'label+percent',
      hovertemplate: '%{label} (%{percent})<extra>' + B.nom + '</extra>',
      title: { text: B.nom, font: { size: 12 } },
    },
  ], _baseLayout({
    grid: { rows: 1, columns: 2 },
    margin: { t: 40, r: 20, b: 20, l: 20 },
    showlegend: true,
    legend: { orientation: 'h', y: -0.1 },
  }), PLOTLY_CFG);
}

/* ── 3. Population totale ──────────────────────────────────── */
function _renderPopulation(A, B) {
  Plotly.react('chart-gen-pop', [
    {
      type: 'bar', name: A.nom, x: [A.nom], y: [A.population],
      marker: { color: COLOR_A },
      text: [A.population.toLocaleString('fr-FR')], textposition: 'outside',
      hovertemplate: '<b>' + A.nom + '</b><br>%{y:,.0f} hab.<extra></extra>',
    },
    {
      type: 'bar', name: B.nom, x: [B.nom], y: [B.population],
      marker: { color: COLOR_B },
      text: [B.population.toLocaleString('fr-FR')], textposition: 'outside',
      hovertemplate: '<b>' + B.nom + '</b><br>%{y:,.0f} hab.<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', showlegend: false,
    yaxis: { ..._baseLayout().yaxis, type: 'linear', title: { text: 'Habitants', font: { size: 11 } } },
  }), PLOTLY_CFG);
}

/* ── 4. NOUVEAU : Jauge "Jeunes 15-29 ans" ────────────────── */
/**
 * _renderStudentGauge(A, B)
 * Affiche deux jauges Plotly (type:'indicator', mode:'gauge+number')
 * pour le pourcentage de 15-29 ans (proxy étudiants).
 *
 * Structure d'une jauge Plotly :
 *   - value       : valeur affichée (nombre)
 *   - gauge.axis.range : [min, max] de l'échelle
 *   - gauge.steps : zones de couleur [{ range:[a,b], color:'...' }]
 *   - gauge.threshold : ligne de référence style { line, thickness, value }
 *   - domain      : positionnement { column, row } dans une grille
 *
 * @param {Object} A - base data ville A
 * @param {Object} B - base data ville B
 */
function _renderStudentGauge(A, B) {
  // Valeur = % de la tranche 15-29 ans (proxy étudiant)
  const valA = +(A.tranches_age?.['15-29'] ?? 0);
  const valB = +(B.tranches_age?.['15-29'] ?? 0);

  // Moyenne nationale de référence (~18%)
  const SEUIL_NATIONAL = 18;

  const makeGauge = (nom, val, color, column) => ({
    type: 'indicator',
    mode: 'gauge+number+delta',       // affiche valeur + delta vs référence
    title: { text: nom, font: { size: 13 } },
    value: val,
    delta: {
      reference:  SEUIL_NATIONAL,    // comparaison avec la moyenne nationale
      valueformat: '.1f',
      suffix:     '%',
      increasing: { color: '#16A34A' },  // + d'étudiants = vert
      decreasing: { color: '#DC2626' },
    },
    number: { suffix: '%', font: { size: 28 } },
    gauge: {
      axis: {
        range:     [0, 35],           // bornes réalistes pour la France
        ticksuffix: '%',
        tickfont:  { size: 10 },
      },
      // Zones colorées : rouge → jaune → vert
      steps: [
        { range: [0,  12], color: '#FEE2E2' },   // Très peu de jeunes
        { range: [12, 20], color: '#FEF9C3' },   // Moyen
        { range: [20, 35], color: '#DCFCE7' },   // Beaucoup de jeunes
      ],
      // Ligne de référence nationale
      threshold: {
        line:      { color: '#7C3AED', width: 2.5 },
        thickness: 0.75,
        value:     SEUIL_NATIONAL,
      },
      bar: { color },
    },
    domain: { column },
  });

  Plotly.react('chart-gen-gauge', [
    makeGauge(A.nom, valA, COLOR_A, 0),
    makeGauge(B.nom, valB, COLOR_B, 1),
  ], _baseLayout({
    grid: { rows: 1, columns: 2, pattern: 'independent' },
    margin: { t: 50, r: 30, b: 30, l: 30 },
    annotations: [{
      x: 0.5, y: -0.05, xref: 'paper', yref: 'paper',
      text: `Ligne violette = moyenne nationale (${SEUIL_NATIONAL}%)`,
      showarrow: false, font: { size: 10, color: '#7C3AED' },
      xanchor: 'center',
    }],
  }), PLOTLY_CFG);
}

/* ── Orchestrateur ──────────────────────────────────────────── */
function renderGeneral(cityA, cityB) {
  const A = cityA.base, B = cityB.base;
  if (!A || !B) return;
  try { _renderPyramide(A, B); } catch (e) { console.error('[General] Pyramid error:', e); }
  try { _renderSexe(A, B); } catch (e) { console.error('[General] Sexe error:', e); }
  try { _renderPopulation(A, B); } catch (e) { console.error('[General] Population error:', e); }
  try { _renderStudentGauge(A, B); } catch (e) { console.error('[General] StudentGauge error:', e); }
}

window.GeneralChart = { renderGeneral };
