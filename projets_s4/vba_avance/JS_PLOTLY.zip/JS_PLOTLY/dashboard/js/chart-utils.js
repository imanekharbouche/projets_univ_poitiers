/**
 * @AI_SPACE
 * @purpose : Centralisation des utilitaires et de la configuration Plotly.js.
 * @logic : Fournit une configuration responsive globale et un générateur de layout DRY pour assurer la cohérence visuelle.
 * @decisions : centralisation pour respecter la règle "Zero-Waste" et éviter les duplications dans les modules thématiques.
 * @references : https://plotly.com/javascript/layout-options/
 */

/* ============================================================
   js/chart-utils.js — Utilitaires partagés pour Plotly
   Évite les redéclarations de constantes (SyntaxError)
============================================================ */

'use strict';

/** Configuration de base pour la fluidité/responsive de Plotly */
window.PLOTLY_CFG = {
  responsive: true,
  displayModeBar: false,
  locale: 'fr'
};

/** 
 * Génère le layout de base commun à la plupart des graphiques
 * (couleurs, polices, marges, grille css)
 */
window._baseLayout = function (overrides = {}) {
  return {
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: { family: "'Inter', system-ui, sans-serif", size: 12, color: '#f8fafc' },
    margin: { t: 30, r: 20, b: 50, l: 55 },
    height: 400,
    legend: { orientation: 'h', x: 0, y: 1.08, font: { size: 11, color: '#94a3b8' } },
    xaxis: {
      gridcolor: 'rgba(255, 255, 255, 0.05)',
      linecolor: 'rgba(255, 255, 255, 0.1)',
      zerolinecolor: 'rgba(255, 255, 255, 0.1)',
      tickfont: { size: 11, color: '#94a3b8' }
    },
    yaxis: {
      gridcolor: 'rgba(255, 255, 255, 0.05)',
      linecolor: 'rgba(255, 255, 255, 0.1)',
      zerolinecolor: 'rgba(255, 255, 255, 0.1)',
      tickfont: { size: 11, color: '#94a3b8' }
    },
    hovermode: 'x unified',
    ...overrides,
  };
};

/* Couleurs principales partagées */
window.COLOR_A = '#1D4ED8';
window.COLOR_B = '#D97706';
window.COLOR_A_FILL = 'rgba(29,78,216,0.15)';
window.COLOR_B_FILL = 'rgba(217,119,6,0.15)';
