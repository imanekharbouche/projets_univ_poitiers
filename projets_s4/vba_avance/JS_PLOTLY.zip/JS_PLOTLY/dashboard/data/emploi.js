window.DATA_EMPLOI = {
  "75056": {
    "codgeo": "75056",
    "nom": "Paris",
    "taux_chomage": 5.0,
    "pop_active": 1017347,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.7,
      "Cadres": 30.5,
      "Prof. intermédiaires": 14.3,
      "Employés": 11.5,
      "Ouvriers": 4.0,
      "Retraités": 18.2,
      "Autres inactifs": 17.7
    },
    "taux_emploi": 74.4
  },
  "13055": {
    "codgeo": "13055",
    "nom": "Marseille",
    "taux_chomage": 9.3,
    "pop_active": 396007,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 10.3,
      "Prof. intermédiaires": 13.7,
      "Employés": 15.7,
      "Ouvriers": 8.4,
      "Retraités": 22.6,
      "Autres inactifs": 25.9
    },
    "taux_emploi": 55.3
  },
  "69123": {
    "codgeo": "69123",
    "nom": "Lyon",
    "taux_chomage": 5.0,
    "pop_active": 243825,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 22.1,
      "Prof. intermédiaires": 17.1,
      "Employés": 13.6,
      "Ouvriers": 5.8,
      "Retraités": 17.0,
      "Autres inactifs": 21.4
    },
    "taux_emploi": 68.2
  },
  "31555": {
    "codgeo": "31555",
    "nom": "Toulouse",
    "taux_chomage": 5.0,
    "pop_active": 237374,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 19.2,
      "Prof. intermédiaires": 15.7,
      "Employés": 14.5,
      "Ouvriers": 7.8,
      "Retraités": 15.1,
      "Autres inactifs": 24.8
    },
    "taux_emploi": 58.4
  },
  "06088": {
    "codgeo": "06088",
    "nom": "Nice",
    "taux_chomage": 8.3,
    "pop_active": 162201,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.2,
      "Cadres": 10.1,
      "Prof. intermédiaires": 12.8,
      "Employés": 16.8,
      "Ouvriers": 8.4,
      "Retraités": 27.1,
      "Autres inactifs": 20.6
    },
    "taux_emploi": 63.3
  },
  "44109": {
    "codgeo": "44109",
    "nom": "Nantes",
    "taux_chomage": 5.0,
    "pop_active": 148955,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 19.4,
      "Prof. intermédiaires": 16.4,
      "Employés": 14.0,
      "Ouvriers": 8.0,
      "Retraités": 18.0,
      "Autres inactifs": 21.3
    },
    "taux_emploi": 61.1
  },
  "34172": {
    "codgeo": "34172",
    "nom": "Montpellier",
    "taux_chomage": 5.0,
    "pop_active": 141320,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 13.5,
      "Prof. intermédiaires": 15.1,
      "Employés": 14.3,
      "Ouvriers": 7.8,
      "Retraités": 17.1,
      "Autres inactifs": 28.7
    },
    "taux_emploi": 57.8
  },
  "67482": {
    "codgeo": "67482",
    "nom": "Strasbourg",
    "taux_chomage": 5.0,
    "pop_active": 133376,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 14.6,
      "Prof. intermédiaires": 14.4,
      "Employés": 14.7,
      "Ouvriers": 9.8,
      "Retraités": 17.5,
      "Autres inactifs": 26.5
    },
    "taux_emploi": 59.2
  },
  "33063": {
    "codgeo": "33063",
    "nom": "Bordeaux",
    "taux_chomage": 5.0,
    "pop_active": 125050,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.0,
      "Cadres": 19.2,
      "Prof. intermédiaires": 16.4,
      "Employés": 14.0,
      "Ouvriers": 6.6,
      "Retraités": 17.4,
      "Autres inactifs": 22.2
    },
    "taux_emploi": 63.4
  },
  "59350": {
    "codgeo": "59350",
    "nom": "Lille",
    "taux_chomage": 8.0,
    "pop_active": 111319,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 18.5,
      "Prof. intermédiaires": 14.9,
      "Employés": 14.3,
      "Ouvriers": 7.3,
      "Retraités": 13.2,
      "Autres inactifs": 29.4
    },
    "taux_emploi": 65.9
  },
  "35238": {
    "codgeo": "35238",
    "nom": "Rennes",
    "taux_chomage": 5.0,
    "pop_active": 106801,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 16.8,
      "Prof. intermédiaires": 14.8,
      "Employés": 13.4,
      "Ouvriers": 8.2,
      "Retraités": 17.9,
      "Autres inactifs": 26.6
    },
    "taux_emploi": 58.2
  },
  "83137": {
    "codgeo": "83137",
    "nom": "Toulon",
    "taux_chomage": 10.6,
    "pop_active": 83037,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 7.0,
      "Prof. intermédiaires": 12.6,
      "Employés": 17.9,
      "Ouvriers": 10.2,
      "Retraités": 27.1,
      "Autres inactifs": 21.6
    },
    "taux_emploi": 53.5
  },
  "51454": {
    "codgeo": "51454",
    "nom": "Reims",
    "taux_chomage": 7.6,
    "pop_active": 81979,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 10.0,
      "Prof. intermédiaires": 13.8,
      "Employés": 16.4,
      "Ouvriers": 11.5,
      "Retraités": 21.0,
      "Autres inactifs": 24.5
    },
    "taux_emploi": 54.8
  },
  "42218": {
    "codgeo": "42218",
    "nom": "Saint-Étienne",
    "taux_chomage": 8.1,
    "pop_active": 78569,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 8.0,
      "Prof. intermédiaires": 12.6,
      "Employés": 14.9,
      "Ouvriers": 12.5,
      "Retraités": 24.6,
      "Autres inactifs": 24.8
    },
    "taux_emploi": 51.5
  },
  "76351": {
    "codgeo": "76351",
    "nom": "Le Havre",
    "taux_chomage": 10.5,
    "pop_active": 75143,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 6.6,
      "Prof. intermédiaires": 13.3,
      "Employés": 16.5,
      "Ouvriers": 12.9,
      "Retraités": 27.2,
      "Autres inactifs": 21.4
    },
    "taux_emploi": 50.9
  },
  "21231": {
    "codgeo": "21231",
    "nom": "Dijon",
    "taux_chomage": 8.3,
    "pop_active": 76156,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 12.3,
      "Prof. intermédiaires": 15.2,
      "Employés": 15.1,
      "Ouvriers": 9.6,
      "Retraités": 22.6,
      "Autres inactifs": 22.6
    },
    "taux_emploi": 58.9
  },
  "38185": {
    "codgeo": "38185",
    "nom": "Grenoble",
    "taux_chomage": 7.1,
    "pop_active": 73830,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 18.5,
      "Prof. intermédiaires": 14.8,
      "Employés": 13.7,
      "Ouvriers": 7.2,
      "Retraités": 18.0,
      "Autres inactifs": 25.4
    },
    "taux_emploi": 62.5
  },
  "49007": {
    "codgeo": "49007",
    "nom": "Angers",
    "taux_chomage": 10.3,
    "pop_active": 73576,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.7,
      "Cadres": 12.0,
      "Prof. intermédiaires": 14.4,
      "Employés": 15.0,
      "Ouvriers": 9.8,
      "Retraités": 22.1,
      "Autres inactifs": 24.0
    },
    "taux_emploi": 56.3
  },
  "69266": {
    "codgeo": "69266",
    "nom": "Villeurbanne",
    "taux_chomage": 6.9,
    "pop_active": 72420,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 16.2,
      "Prof. intermédiaires": 16.5,
      "Employés": 16.3,
      "Ouvriers": 8.6,
      "Retraités": 16.8,
      "Autres inactifs": 23.1
    },
    "taux_emploi": 59.7
  },
  "97411": {
    "codgeo": "97411",
    "nom": "Saint-Denis",
    "taux_chomage": 8.9,
    "pop_active": 66013,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.3,
      "Cadres": 8.0,
      "Prof. intermédiaires": 14.3,
      "Employés": 19.0,
      "Ouvriers": 9.3,
      "Retraités": 16.2,
      "Autres inactifs": 29.7
    },
    "taux_emploi": 52.7
  },
  "30189": {
    "codgeo": "30189",
    "nom": "Nîmes",
    "taux_chomage": 8.7,
    "pop_active": 67188,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.5,
      "Cadres": 7.3,
      "Prof. intermédiaires": 12.4,
      "Employés": 16.3,
      "Ouvriers": 9.2,
      "Retraités": 26.0,
      "Autres inactifs": 25.1
    },
    "taux_emploi": 51.4
  },
  "13001": {
    "codgeo": "13001",
    "nom": "Aix-en-Provence",
    "taux_chomage": 9.3,
    "pop_active": 70209,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.7,
      "Cadres": 16.9,
      "Prof. intermédiaires": 14.5,
      "Employés": 13.8,
      "Ouvriers": 5.8,
      "Retraités": 22.1,
      "Autres inactifs": 23.0
    },
    "taux_emploi": 60.7
  },
  "63113": {
    "codgeo": "63113",
    "nom": "Clermont-Ferrand",
    "taux_chomage": 8.6,
    "pop_active": 69178,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 11.7,
      "Prof. intermédiaires": 13.6,
      "Employés": 15.8,
      "Ouvriers": 10.0,
      "Retraités": 20.0,
      "Autres inactifs": 26.4
    },
    "taux_emploi": 52.2
  },
  "72181": {
    "codgeo": "72181",
    "nom": "Le Mans",
    "taux_chomage": 9.1,
    "pop_active": 66529,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 9.4,
      "Prof. intermédiaires": 14.0,
      "Employés": 16.0,
      "Ouvriers": 10.6,
      "Retraités": 28.7,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 51.1
  },
  "29019": {
    "codgeo": "29019",
    "nom": "Brest",
    "taux_chomage": 5.8,
    "pop_active": 66096,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 11.1,
      "Prof. intermédiaires": 14.1,
      "Employés": 16.4,
      "Ouvriers": 10.3,
      "Retraités": 22.2,
      "Autres inactifs": 23.9
    },
    "taux_emploi": 54.2
  },
  "37261": {
    "codgeo": "37261",
    "nom": "Tours",
    "taux_chomage": 7.7,
    "pop_active": 65170,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 12.3,
      "Prof. intermédiaires": 15.3,
      "Employés": 15.7,
      "Ouvriers": 9.3,
      "Retraités": 22.5,
      "Autres inactifs": 22.5
    },
    "taux_emploi": 61.5
  },
  "80021": {
    "codgeo": "80021",
    "nom": "Amiens",
    "taux_chomage": 5.0,
    "pop_active": 61092,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.1,
      "Cadres": 10.9,
      "Prof. intermédiaires": 13.6,
      "Employés": 15.7,
      "Ouvriers": 9.9,
      "Retraités": 19.5,
      "Autres inactifs": 28.2
    },
    "taux_emploi": 58.9
  },
  "74010": {
    "codgeo": "74010",
    "nom": "Annecy",
    "taux_chomage": 8.3,
    "pop_active": 61881,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.8,
      "Cadres": 12.8,
      "Prof. intermédiaires": 17.4,
      "Employés": 15.9,
      "Ouvriers": 10.6,
      "Retraités": 25.7,
      "Autres inactifs": 13.8
    },
    "taux_emploi": 55.9
  },
  "87085": {
    "codgeo": "87085",
    "nom": "Limoges",
    "taux_chomage": 13.7,
    "pop_active": 61378,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.3,
      "Cadres": 8.6,
      "Prof. intermédiaires": 13.4,
      "Employés": 14.9,
      "Ouvriers": 10.4,
      "Retraités": 28.1,
      "Autres inactifs": 22.3
    },
    "taux_emploi": 51.0
  },
  "57463": {
    "codgeo": "57463",
    "nom": "Metz",
    "taux_chomage": 9.2,
    "pop_active": 56877,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 11.7,
      "Prof. intermédiaires": 14.5,
      "Employés": 16.5,
      "Ouvriers": 10.6,
      "Retraités": 21.6,
      "Autres inactifs": 22.7
    },
    "taux_emploi": 58.7
  },
  "92012": {
    "codgeo": "92012",
    "nom": "Boulogne-Billancourt",
    "taux_chomage": 5.0,
    "pop_active": 55081,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.4,
      "Cadres": 34.0,
      "Prof. intermédiaires": 14.6,
      "Employés": 10.3,
      "Ouvriers": 2.8,
      "Retraités": 19.2,
      "Autres inactifs": 14.6
    },
    "taux_emploi": 75
  },
  "66136": {
    "codgeo": "66136",
    "nom": "Perpignan",
    "taux_chomage": 10.6,
    "pop_active": 54160,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.7,
      "Cadres": 5.4,
      "Prof. intermédiaires": 10.9,
      "Employés": 14.5,
      "Ouvriers": 10.3,
      "Retraités": 26.9,
      "Autres inactifs": 28.1
    },
    "taux_emploi": 55.7
  },
  "25056": {
    "codgeo": "25056",
    "nom": "Besançon",
    "taux_chomage": 10.3,
    "pop_active": 56208,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.3,
      "Cadres": 11.2,
      "Prof. intermédiaires": 13.7,
      "Employés": 15.0,
      "Ouvriers": 10.1,
      "Retraités": 22.2,
      "Autres inactifs": 25.4
    },
    "taux_emploi": 53.8
  },
  "45234": {
    "codgeo": "45234",
    "nom": "Orléans",
    "taux_chomage": 5.6,
    "pop_active": 53077,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.4,
      "Cadres": 13.1,
      "Prof. intermédiaires": 14.9,
      "Employés": 15.8,
      "Ouvriers": 12.0,
      "Retraités": 20.7,
      "Autres inactifs": 21.0
    },
    "taux_emploi": 56.8
  },
  "76540": {
    "codgeo": "76540",
    "nom": "Rouen",
    "taux_chomage": 5.0,
    "pop_active": 54361,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 14.9,
      "Prof. intermédiaires": 15.8,
      "Employés": 14.4,
      "Ouvriers": 8.0,
      "Retraités": 18.0,
      "Autres inactifs": 26.5
    },
    "taux_emploi": 55.2
  },
  "93066": {
    "codgeo": "93066",
    "nom": "Saint-Denis",
    "taux_chomage": 7.5,
    "pop_active": 49366,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 10.3,
      "Prof. intermédiaires": 13.0,
      "Employés": 20.3,
      "Ouvriers": 14.2,
      "Retraités": 11.9,
      "Autres inactifs": 27.3
    },
    "taux_emploi": 54.7
  },
  "93048": {
    "codgeo": "93048",
    "nom": "Montreuil",
    "taux_chomage": 5.0,
    "pop_active": 49345,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 19.3,
      "Prof. intermédiaires": 16.2,
      "Employés": 16.6,
      "Ouvriers": 9.5,
      "Retraités": 15.7,
      "Autres inactifs": 19.6
    },
    "taux_emploi": 65.3
  },
  "14118": {
    "codgeo": "14118",
    "nom": "Caen",
    "taux_chomage": 9.7,
    "pop_active": 52075,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 11.9,
      "Prof. intermédiaires": 13.6,
      "Employés": 14.2,
      "Ouvriers": 8.4,
      "Retraités": 22.3,
      "Autres inactifs": 27.2
    },
    "taux_emploi": 54.6
  },
  "95018": {
    "codgeo": "95018",
    "nom": "Argenteuil",
    "taux_chomage": 8.3,
    "pop_active": 45749,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 11.3,
      "Prof. intermédiaires": 14.9,
      "Employés": 18.1,
      "Ouvriers": 12.7,
      "Retraités": 16.9,
      "Autres inactifs": 22.8
    },
    "taux_emploi": 51.2
  },
  "68224": {
    "codgeo": "68224",
    "nom": "Mulhouse",
    "taux_chomage": 14.3,
    "pop_active": 46729,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 6.5,
      "Prof. intermédiaires": 10.4,
      "Employés": 15.6,
      "Ouvriers": 16.3,
      "Retraités": 20.6,
      "Autres inactifs": 28.0
    },
    "taux_emploi": 47.5
  },
  "97415": {
    "codgeo": "97415",
    "nom": "Saint-Paul",
    "taux_chomage": 8.3,
    "pop_active": 46237,
    "categories_sociopro": {
      "Agriculteurs": 0.6,
      "Artisans/commerçants": 3.6,
      "Cadres": 6.7,
      "Prof. intermédiaires": 13.2,
      "Employés": 17.3,
      "Ouvriers": 11.4,
      "Retraités": 15.9,
      "Autres inactifs": 31.1
    },
    "taux_emploi": 46.3
  },
  "54395": {
    "codgeo": "54395",
    "nom": "Nancy",
    "taux_chomage": 8.9,
    "pop_active": 50198,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 15.3,
      "Prof. intermédiaires": 15.0,
      "Employés": 14.0,
      "Ouvriers": 6.8,
      "Retraités": 17.0,
      "Autres inactifs": 29.3
    },
    "taux_emploi": 63.1
  },
  "59599": {
    "codgeo": "59599",
    "nom": "Tourcoing",
    "taux_chomage": 11.7,
    "pop_active": 42241,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 6.3,
      "Prof. intermédiaires": 13.4,
      "Employés": 18.8,
      "Ouvriers": 16.7,
      "Retraités": 18.3,
      "Autres inactifs": 23.9
    },
    "taux_emploi": 56.5
  },
  "59512": {
    "codgeo": "59512",
    "nom": "Roubaix",
    "taux_chomage": 11.8,
    "pop_active": 40315,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 5.0,
      "Prof. intermédiaires": 9.8,
      "Employés": 15.4,
      "Ouvriers": 15.8,
      "Retraités": 16.2,
      "Autres inactifs": 35.5
    },
    "taux_emploi": 48.9
  },
  "92050": {
    "codgeo": "92050",
    "nom": "Nanterre",
    "taux_chomage": 5.2,
    "pop_active": 42981,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 17.4,
      "Prof. intermédiaires": 15.0,
      "Employés": 19.3,
      "Ouvriers": 8.3,
      "Retraités": 15.3,
      "Autres inactifs": 21.8
    },
    "taux_emploi": 59.2
  },
  "94081": {
    "codgeo": "94081",
    "nom": "Vitry-sur-Seine",
    "taux_chomage": 12.5,
    "pop_active": 42425,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 10.0,
      "Prof. intermédiaires": 13.8,
      "Employés": 19.5,
      "Ouvriers": 12.5,
      "Retraités": 16.7,
      "Autres inactifs": 24.0
    },
    "taux_emploi": 53.4
  },
  "94028": {
    "codgeo": "94028",
    "nom": "Créteil",
    "taux_chomage": 8.9,
    "pop_active": 40530,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 12.6,
      "Prof. intermédiaires": 16.5,
      "Employés": 20.7,
      "Ouvriers": 8.9,
      "Retraités": 17.6,
      "Autres inactifs": 20.8
    },
    "taux_emploi": 49.9
  },
  "84007": {
    "codgeo": "84007",
    "nom": "Avignon",
    "taux_chomage": 7.7,
    "pop_active": 40119,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.4,
      "Cadres": 8.2,
      "Prof. intermédiaires": 11.7,
      "Employés": 15.3,
      "Ouvriers": 11.9,
      "Retraités": 23.7,
      "Autres inactifs": 25.7
    },
    "taux_emploi": 52.9
  },
  "86194": {
    "codgeo": "86194",
    "nom": "Poitiers",
    "taux_chomage": 8.0,
    "pop_active": 42741,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 1.9,
      "Cadres": 10.9,
      "Prof. intermédiaires": 13.3,
      "Employés": 16.3,
      "Ouvriers": 7.8,
      "Retraités": 18.5,
      "Autres inactifs": 31.1
    },
    "taux_emploi": 53.7
  },
  "93001": {
    "codgeo": "93001",
    "nom": "Aubervilliers",
    "taux_chomage": 10.9,
    "pop_active": 38784,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 7.4,
      "Prof. intermédiaires": 11.0,
      "Employés": 21.2,
      "Ouvriers": 16.8,
      "Retraités": 11.1,
      "Autres inactifs": 29.0
    },
    "taux_emploi": 50.5
  },
  "92004": {
    "codgeo": "92004",
    "nom": "Asnières-sur-Seine",
    "taux_chomage": 5.0,
    "pop_active": 39791,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 29.0,
      "Prof. intermédiaires": 16.3,
      "Employés": 13.9,
      "Ouvriers": 5.7,
      "Retraités": 14.9,
      "Autres inactifs": 16.7
    },
    "taux_emploi": 74.0
  },
  "92025": {
    "codgeo": "92025",
    "nom": "Colombes",
    "taux_chomage": 5.0,
    "pop_active": 38675,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 21.1,
      "Prof. intermédiaires": 15.6,
      "Employés": 16.5,
      "Ouvriers": 7.5,
      "Retraités": 16.3,
      "Autres inactifs": 19.5
    },
    "taux_emploi": 59.3
  },
  "59183": {
    "codgeo": "59183",
    "nom": "Dunkerque",
    "taux_chomage": 10.3,
    "pop_active": 40087,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 6.2,
      "Prof. intermédiaires": 12.7,
      "Employés": 16.2,
      "Ouvriers": 13.9,
      "Retraités": 28.7,
      "Autres inactifs": 20.0
    },
    "taux_emploi": 52.9
  },
  "93005": {
    "codgeo": "93005",
    "nom": "Aulnay-sous-Bois",
    "taux_chomage": 11.7,
    "pop_active": 36707,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 7.6,
      "Prof. intermédiaires": 13.2,
      "Employés": 18.8,
      "Ouvriers": 14.4,
      "Retraités": 16.8,
      "Autres inactifs": 26.3
    },
    "taux_emploi": 51.4
  },
  "97416": {
    "codgeo": "97416",
    "nom": "Saint-Pierre",
    "taux_chomage": 13.1,
    "pop_active": 36632,
    "categories_sociopro": {
      "Agriculteurs": 0.8,
      "Artisans/commerçants": 4.0,
      "Cadres": 5.9,
      "Prof. intermédiaires": 13.8,
      "Employés": 19.3,
      "Ouvriers": 10.8,
      "Retraités": 15.2,
      "Autres inactifs": 30.2
    },
    "taux_emploi": 54.9
  },
  "78646": {
    "codgeo": "78646",
    "nom": "Versailles",
    "taux_chomage": 5.0,
    "pop_active": 37459,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.7,
      "Cadres": 28.7,
      "Prof. intermédiaires": 13.1,
      "Employés": 12.4,
      "Ouvriers": 3.0,
      "Retraités": 20.5,
      "Autres inactifs": 19.6
    },
    "taux_emploi": 75
  },
  "97422": {
    "codgeo": "97422",
    "nom": "Le Tampon",
    "taux_chomage": 13.7,
    "pop_active": 34965,
    "categories_sociopro": {
      "Agriculteurs": 1.9,
      "Artisans/commerçants": 4.3,
      "Cadres": 3.9,
      "Prof. intermédiaires": 11.7,
      "Employés": 20.5,
      "Ouvriers": 13.0,
      "Retraités": 16.7,
      "Autres inactifs": 27.9
    },
    "taux_emploi": 46.0
  },
  "92026": {
    "codgeo": "92026",
    "nom": "Courbevoie",
    "taux_chomage": 5.0,
    "pop_active": 37858,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 32.7,
      "Prof. intermédiaires": 15.3,
      "Employés": 12.4,
      "Ouvriers": 3.6,
      "Retraités": 17.3,
      "Autres inactifs": 15.6
    },
    "taux_emploi": 75
  },
  "34032": {
    "codgeo": "34032",
    "nom": "Béziers",
    "taux_chomage": 14.5,
    "pop_active": 36100,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.7,
      "Cadres": 4.6,
      "Prof. intermédiaires": 9.5,
      "Employés": 14.9,
      "Ouvriers": 11.3,
      "Retraités": 29.1,
      "Autres inactifs": 26.6
    },
    "taux_emploi": 58.8
  },
  "17300": {
    "codgeo": "17300",
    "nom": "La Rochelle",
    "taux_chomage": 12.7,
    "pop_active": 37594,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 10.0,
      "Prof. intermédiaires": 12.4,
      "Employés": 14.9,
      "Ouvriers": 8.8,
      "Retraités": 29.4,
      "Autres inactifs": 20.9
    },
    "taux_emploi": 54.1
  },
  "92063": {
    "codgeo": "92063",
    "nom": "Rueil-Malmaison",
    "taux_chomage": 5.0,
    "pop_active": 34877,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 29.2,
      "Prof. intermédiaires": 15.7,
      "Employés": 11.8,
      "Ouvriers": 3.9,
      "Retraités": 20.6,
      "Autres inactifs": 15.5
    },
    "taux_emploi": 75
  },
  "50129": {
    "codgeo": "50129",
    "nom": "Cherbourg-en-Cotentin",
    "taux_chomage": 7.9,
    "pop_active": 37258,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 1.9,
      "Cadres": 9.1,
      "Prof. intermédiaires": 15.8,
      "Employés": 16.7,
      "Ouvriers": 12.2,
      "Retraités": 29.0,
      "Autres inactifs": 15.3
    },
    "taux_emploi": 57.3
  },
  "94017": {
    "codgeo": "94017",
    "nom": "Champigny-sur-Marne",
    "taux_chomage": 8.8,
    "pop_active": 33895,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 11.1,
      "Prof. intermédiaires": 15.4,
      "Employés": 18.7,
      "Ouvriers": 11.0,
      "Retraités": 18.7,
      "Autres inactifs": 21.7
    },
    "taux_emploi": 54.6
  },
  "64445": {
    "codgeo": "64445",
    "nom": "Pau",
    "taux_chomage": 9.4,
    "pop_active": 37224,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 9.8,
      "Prof. intermédiaires": 12.9,
      "Employés": 15.2,
      "Ouvriers": 9.4,
      "Retraités": 27.1,
      "Autres inactifs": 22.6
    },
    "taux_emploi": 51.7
  },
  "33281": {
    "codgeo": "33281",
    "nom": "Mérignac",
    "taux_chomage": 6.8,
    "pop_active": 35076,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 15.6,
      "Prof. intermédiaires": 18.1,
      "Employés": 16.7,
      "Ouvriers": 8.9,
      "Retraités": 22.3,
      "Autres inactifs": 14.9
    },
    "taux_emploi": 56.7
  },
  "94068": {
    "codgeo": "94068",
    "nom": "Saint-Maur-des-Fossés",
    "taux_chomage": 5.0,
    "pop_active": 34802,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.1,
      "Cadres": 24.5,
      "Prof. intermédiaires": 15.7,
      "Employés": 10.9,
      "Ouvriers": 4.3,
      "Retraités": 25.7,
      "Autres inactifs": 14.7
    },
    "taux_emploi": 75
  },
  "06004": {
    "codgeo": "06004",
    "nom": "Antibes",
    "taux_chomage": 5.0,
    "pop_active": 35959,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 5.2,
      "Cadres": 13.7,
      "Prof. intermédiaires": 13.3,
      "Employés": 15.2,
      "Ouvriers": 6.5,
      "Retraités": 32.3,
      "Autres inactifs": 13.7
    },
    "taux_emploi": 62.5
  },
  "97209": {
    "codgeo": "97209",
    "nom": "Fort-de-France",
    "taux_chomage": 10.7,
    "pop_active": 34314,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.7,
      "Cadres": 5.7,
      "Prof. intermédiaires": 13.2,
      "Employés": 19.0,
      "Ouvriers": 9.1,
      "Retraités": 25.0,
      "Autres inactifs": 24.1
    },
    "taux_emploi": 51.9
  },
  "2A004": {
    "codgeo": "2A004",
    "nom": "Ajaccio",
    "taux_chomage": 9.7,
    "pop_active": 33561,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.6,
      "Cadres": 6.4,
      "Prof. intermédiaires": 14.0,
      "Employés": 20.1,
      "Ouvriers": 10.3,
      "Retraités": 27.2,
      "Autres inactifs": 18.3
    },
    "taux_emploi": 52.4
  },
  "06029": {
    "codgeo": "06029",
    "nom": "Cannes",
    "taux_chomage": 10.3,
    "pop_active": 34788,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 5.3,
      "Cadres": 6.4,
      "Prof. intermédiaires": 10.1,
      "Employés": 17.5,
      "Ouvriers": 9.0,
      "Retraités": 33.9,
      "Autres inactifs": 17.8
    },
    "taux_emploi": 46.7
  },
  "44184": {
    "codgeo": "44184",
    "nom": "Saint-Nazaire",
    "taux_chomage": 10.8,
    "pop_active": 33285,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 8.7,
      "Prof. intermédiaires": 13.1,
      "Employés": 14.1,
      "Ouvriers": 12.7,
      "Retraités": 32.0,
      "Autres inactifs": 16.7
    },
    "taux_emploi": 54.0
  },
  "93029": {
    "codgeo": "93029",
    "nom": "Drancy",
    "taux_chomage": 12.5,
    "pop_active": 30715,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 5.7,
      "Prof. intermédiaires": 13.2,
      "Employés": 20.4,
      "Ouvriers": 15.3,
      "Retraités": 17.0,
      "Autres inactifs": 24.7
    },
    "taux_emploi": 51.7
  },
  "93051": {
    "codgeo": "93051",
    "nom": "Noisy-le-Grand",
    "taux_chomage": 5.0,
    "pop_active": 31083,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 15.2,
      "Prof. intermédiaires": 16.9,
      "Employés": 19.2,
      "Ouvriers": 9.4,
      "Retraités": 17.4,
      "Autres inactifs": 18.9
    },
    "taux_emploi": 63.5
  },
  "92040": {
    "codgeo": "92040",
    "nom": "Issy-les-Moulineaux",
    "taux_chomage": 5.0,
    "pop_active": 30751,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 36.2,
      "Prof. intermédiaires": 15.9,
      "Employés": 11.3,
      "Ouvriers": 2.8,
      "Retraités": 17.1,
      "Autres inactifs": 13.7
    },
    "taux_emploi": 75
  },
  "95127": {
    "codgeo": "95127",
    "nom": "Cergy",
    "taux_chomage": 9.2,
    "pop_active": 29216,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 12.7,
      "Prof. intermédiaires": 15.8,
      "Employés": 20.4,
      "Ouvriers": 10.6,
      "Retraités": 12.1,
      "Autres inactifs": 26.1
    },
    "taux_emploi": 57.2
  },
  "92044": {
    "codgeo": "92044",
    "nom": "Levallois-Perret",
    "taux_chomage": 5.0,
    "pop_active": 30785,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.4,
      "Cadres": 33.1,
      "Prof. intermédiaires": 16.5,
      "Employés": 11.0,
      "Ouvriers": 3.2,
      "Retraités": 17.4,
      "Autres inactifs": 14.3
    },
    "taux_emploi": 75
  },
  "68066": {
    "codgeo": "68066",
    "nom": "Colmar",
    "taux_chomage": 10.7,
    "pop_active": 31226,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.5,
      "Cadres": 8.7,
      "Prof. intermédiaires": 12.7,
      "Employés": 17.2,
      "Ouvriers": 15.3,
      "Retraités": 26.6,
      "Autres inactifs": 16.8
    },
    "taux_emploi": 55.6
  },
  "62193": {
    "codgeo": "62193",
    "nom": "Calais",
    "taux_chomage": 14.4,
    "pop_active": 30743,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 1.9,
      "Cadres": 3.7,
      "Prof. intermédiaires": 10.8,
      "Employés": 19.0,
      "Ouvriers": 14.7,
      "Retraités": 25.1,
      "Autres inactifs": 24.8
    },
    "taux_emploi": 47.5
  },
  "33318": {
    "codgeo": "33318",
    "nom": "Pessac",
    "taux_chomage": 6.2,
    "pop_active": 30645,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 15.2,
      "Prof. intermédiaires": 15.3,
      "Employés": 13.5,
      "Ouvriers": 7.5,
      "Retraités": 22.0,
      "Autres inactifs": 23.3
    },
    "taux_emploi": 57.1
  },
  "69259": {
    "codgeo": "69259",
    "nom": "Vénissieux",
    "taux_chomage": 11.2,
    "pop_active": 28101,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 4.5,
      "Prof. intermédiaires": 11.4,
      "Employés": 18.0,
      "Ouvriers": 16.7,
      "Retraités": 18.7,
      "Autres inactifs": 27.6
    },
    "taux_emploi": 47.4
  },
  "91228": {
    "codgeo": "91228",
    "nom": "Évry-Courcouronnes",
    "taux_chomage": 11.6,
    "pop_active": 28166,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 8.3,
      "Prof. intermédiaires": 14.8,
      "Employés": 19.6,
      "Ouvriers": 13.5,
      "Retraités": 15.7,
      "Autres inactifs": 25.7
    },
    "taux_emploi": 49.3
  },
  "92024": {
    "codgeo": "92024",
    "nom": "Clichy",
    "taux_chomage": 5.0,
    "pop_active": 29418,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 21.6,
      "Prof. intermédiaires": 16.3,
      "Employés": 17.8,
      "Ouvriers": 7.3,
      "Retraités": 14.9,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 75
  },
  "26362": {
    "codgeo": "26362",
    "nom": "Valence",
    "taux_chomage": 11.7,
    "pop_active": 29670,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 9.6,
      "Prof. intermédiaires": 13.7,
      "Employés": 15.6,
      "Ouvriers": 12.0,
      "Retraités": 25.4,
      "Autres inactifs": 20.4
    },
    "taux_emploi": 58.9
  },
  "94041": {
    "codgeo": "94041",
    "nom": "Ivry-sur-Seine",
    "taux_chomage": 5.0,
    "pop_active": 28625,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 16.1,
      "Prof. intermédiaires": 15.0,
      "Employés": 16.8,
      "Ouvriers": 9.7,
      "Retraités": 14.2,
      "Autres inactifs": 25.1
    },
    "taux_emploi": 60.0
  },
  "18033": {
    "codgeo": "18033",
    "nom": "Bourges",
    "taux_chomage": 7.6,
    "pop_active": 29854,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.7,
      "Cadres": 9.1,
      "Prof. intermédiaires": 13.8,
      "Employés": 15.7,
      "Ouvriers": 10.4,
      "Retraités": 29.0,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 51.7
  },
  "29232": {
    "codgeo": "29232",
    "nom": "Quimper",
    "taux_chomage": 10.1,
    "pop_active": 29928,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.6,
      "Cadres": 9.1,
      "Prof. intermédiaires": 15.2,
      "Employés": 14.9,
      "Ouvriers": 11.4,
      "Retraités": 29.3,
      "Autres inactifs": 16.3
    },
    "taux_emploi": 51.4
  },
  "97302": {
    "codgeo": "97302",
    "nom": "Cayenne",
    "taux_chomage": 10.5,
    "pop_active": 24851,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.1,
      "Cadres": 5.3,
      "Prof. intermédiaires": 11.7,
      "Employés": 18.4,
      "Ouvriers": 10.4,
      "Retraités": 10.0,
      "Autres inactifs": 40.0
    },
    "taux_emploi": 58.7
  },
  "92002": {
    "codgeo": "92002",
    "nom": "Antony",
    "taux_chomage": 5.0,
    "pop_active": 28580,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 30.9,
      "Prof. intermédiaires": 14.8,
      "Employés": 10.9,
      "Ouvriers": 3.8,
      "Retraités": 21.1,
      "Autres inactifs": 15.9
    },
    "taux_emploi": 75
  },
  "10387": {
    "codgeo": "10387",
    "nom": "Troyes",
    "taux_chomage": 11.7,
    "pop_active": 28552,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.7,
      "Cadres": 6.5,
      "Prof. intermédiaires": 12.6,
      "Employés": 16.4,
      "Ouvriers": 13.5,
      "Retraités": 23.1,
      "Autres inactifs": 25.1
    },
    "taux_emploi": 50.7
  },
  "83126": {
    "codgeo": "83126",
    "nom": "La Seyne-sur-Mer",
    "taux_chomage": 10.2,
    "pop_active": 29312,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.7,
      "Cadres": 5.4,
      "Prof. intermédiaires": 13.1,
      "Employés": 17.6,
      "Ouvriers": 9.3,
      "Retraités": 31.7,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 48.0
  },
  "59009": {
    "codgeo": "59009",
    "nom": "Villeneuve-d'Ascq",
    "taux_chomage": 5.4,
    "pop_active": 28382,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 14.1,
      "Prof. intermédiaires": 14.1,
      "Employés": 14.9,
      "Ouvriers": 8.2,
      "Retraités": 20.7,
      "Autres inactifs": 25.8
    },
    "taux_emploi": 58.4
  },
  "82121": {
    "codgeo": "82121",
    "nom": "Montauban",
    "taux_chomage": 11.6,
    "pop_active": 28105,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.7,
      "Cadres": 8.4,
      "Prof. intermédiaires": 13.6,
      "Employés": 16.1,
      "Ouvriers": 10.5,
      "Retraités": 28.7,
      "Autres inactifs": 18.7
    },
    "taux_emploi": 50.7
  },
  "93055": {
    "codgeo": "93055",
    "nom": "Pantin",
    "taux_chomage": 8.3,
    "pop_active": 26358,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 15.9,
      "Prof. intermédiaires": 15.9,
      "Employés": 18.4,
      "Ouvriers": 10.6,
      "Retraités": 13.7,
      "Autres inactifs": 22.0
    },
    "taux_emploi": 54.9
  },
  "73065": {
    "codgeo": "73065",
    "nom": "Chambéry",
    "taux_chomage": 7.1,
    "pop_active": 27451,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 11.1,
      "Prof. intermédiaires": 14.4,
      "Employés": 15.4,
      "Ouvriers": 11.8,
      "Retraités": 24.1,
      "Autres inactifs": 20.2
    },
    "taux_emploi": 57.7
  },
  "79191": {
    "codgeo": "79191",
    "nom": "Niort",
    "taux_chomage": 5.2,
    "pop_active": 27663,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 12.7,
      "Prof. intermédiaires": 14.3,
      "Employés": 15.7,
      "Ouvriers": 9.7,
      "Retraités": 28.6,
      "Autres inactifs": 15.9
    },
    "taux_emploi": 57.4
  },
  "92051": {
    "codgeo": "92051",
    "nom": "Neuilly-sur-Seine",
    "taux_chomage": 5.0,
    "pop_active": 27517,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 6.6,
      "Cadres": 31.6,
      "Prof. intermédiaires": 10.4,
      "Employés": 8.5,
      "Ouvriers": 1.8,
      "Retraités": 22.5,
      "Autres inactifs": 18.6
    },
    "taux_emploi": 75
  },
  "95585": {
    "codgeo": "95585",
    "nom": "Sarcelles",
    "taux_chomage": 9.5,
    "pop_active": 24079,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 4.1,
      "Prof. intermédiaires": 10.7,
      "Employés": 21.8,
      "Ouvriers": 15.5,
      "Retraités": 16.3,
      "Autres inactifs": 28.5
    },
    "taux_emploi": 45.6
  },
  "93007": {
    "codgeo": "93007",
    "nom": "Le Blanc-Mesnil",
    "taux_chomage": 9.7,
    "pop_active": 24957,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.9,
      "Cadres": 4.9,
      "Prof. intermédiaires": 12.2,
      "Employés": 20.6,
      "Ouvriers": 16.0,
      "Retraités": 15.5,
      "Autres inactifs": 26.8
    },
    "taux_emploi": 46.8
  },
  "94046": {
    "codgeo": "94046",
    "nom": "Maisons-Alfort",
    "taux_chomage": 5.0,
    "pop_active": 26599,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 23.5,
      "Prof. intermédiaires": 18.3,
      "Employés": 16.2,
      "Ouvriers": 5.1,
      "Retraités": 19.7,
      "Autres inactifs": 14.6
    },
    "taux_emploi": 70.3
  },
  "56121": {
    "codgeo": "56121",
    "nom": "Lorient",
    "taux_chomage": 11.6,
    "pop_active": 27414,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 8.4,
      "Prof. intermédiaires": 13.2,
      "Employés": 14.2,
      "Ouvriers": 12.1,
      "Retraités": 27.6,
      "Autres inactifs": 21.1
    },
    "taux_emploi": 55.3
  },
  "94076": {
    "codgeo": "94076",
    "nom": "Villejuif",
    "taux_chomage": 8.6,
    "pop_active": 26486,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 15.9,
      "Prof. intermédiaires": 15.8,
      "Employés": 18.2,
      "Ouvriers": 8.3,
      "Retraités": 17.6,
      "Autres inactifs": 21.8
    },
    "taux_emploi": 61.2
  },
  "97409": {
    "codgeo": "97409",
    "nom": "Saint-André",
    "taux_chomage": 14.1,
    "pop_active": 24607,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 3.6,
      "Cadres": 3.1,
      "Prof. intermédiaires": 11.2,
      "Employés": 20.7,
      "Ouvriers": 12.4,
      "Retraités": 12.3,
      "Autres inactifs": 36.3
    },
    "taux_emploi": 54.5
  },
  "83061": {
    "codgeo": "83061",
    "nom": "Fréjus",
    "taux_chomage": 13.8,
    "pop_active": 27106,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 5.5,
      "Cadres": 5.6,
      "Prof. intermédiaires": 12.7,
      "Employés": 17.1,
      "Ouvriers": 8.8,
      "Retraités": 35.5,
      "Autres inactifs": 14.8
    },
    "taux_emploi": 56.5
  },
  "60057": {
    "codgeo": "60057",
    "nom": "Beauvais",
    "taux_chomage": 8.7,
    "pop_active": 25139,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 7.7,
      "Prof. intermédiaires": 12.5,
      "Employés": 16.1,
      "Ouvriers": 14.3,
      "Retraités": 23.0,
      "Autres inactifs": 24.0
    },
    "taux_emploi": 58.2
  },
  "11262": {
    "codgeo": "11262",
    "nom": "Narbonne",
    "taux_chomage": 14.8,
    "pop_active": 26282,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 4.3,
      "Cadres": 5.8,
      "Prof. intermédiaires": 12.6,
      "Employés": 15.8,
      "Ouvriers": 9.5,
      "Retraités": 31.7,
      "Autres inactifs": 20.1
    },
    "taux_emploi": 48.2
  },
  "77284": {
    "codgeo": "77284",
    "nom": "Meaux",
    "taux_chomage": 9.6,
    "pop_active": 23835,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 7.7,
      "Prof. intermédiaires": 15.1,
      "Employés": 21.8,
      "Ouvriers": 13.5,
      "Retraités": 19.2,
      "Autres inactifs": 20.4
    },
    "taux_emploi": 50.6
  },
  "83069": {
    "codgeo": "83069",
    "nom": "Hyères",
    "taux_chomage": 13.4,
    "pop_active": 26618,
    "categories_sociopro": {
      "Agriculteurs": 0.7,
      "Artisans/commerçants": 4.3,
      "Cadres": 6.5,
      "Prof. intermédiaires": 12.8,
      "Employés": 15.9,
      "Ouvriers": 7.3,
      "Retraités": 35.8,
      "Autres inactifs": 16.7
    },
    "taux_emploi": 51.3
  },
  "93008": {
    "codgeo": "93008",
    "nom": "Bobigny",
    "taux_chomage": 12.1,
    "pop_active": 23602,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 4.8,
      "Prof. intermédiaires": 9.8,
      "Employés": 20.4,
      "Ouvriers": 15.1,
      "Retraités": 13.0,
      "Autres inactifs": 34.0
    },
    "taux_emploi": 42.1
  },
  "85191": {
    "codgeo": "85191",
    "nom": "La Roche-sur-Yon",
    "taux_chomage": 10.2,
    "pop_active": 25700,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.4,
      "Cadres": 8.3,
      "Prof. intermédiaires": 14.7,
      "Employés": 14.5,
      "Ouvriers": 12.9,
      "Retraités": 29.1,
      "Autres inactifs": 17.9
    },
    "taux_emploi": 53.1
  },
  "92023": {
    "codgeo": "92023",
    "nom": "Clamart",
    "taux_chomage": 5.0,
    "pop_active": 24365,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 24.1,
      "Prof. intermédiaires": 16.4,
      "Employés": 14.0,
      "Ouvriers": 5.3,
      "Retraités": 21.6,
      "Autres inactifs": 15.1
    },
    "taux_emploi": 71.9
  },
  "56260": {
    "codgeo": "56260",
    "nom": "Vannes",
    "taux_chomage": 7.8,
    "pop_active": 26189,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.0,
      "Cadres": 10.2,
      "Prof. intermédiaires": 13.5,
      "Employés": 13.7,
      "Ouvriers": 8.0,
      "Retraités": 33.4,
      "Autres inactifs": 18.0
    },
    "taux_emploi": 58.9
  },
  "77108": {
    "codgeo": "77108",
    "nom": "Chelles",
    "taux_chomage": 12.2,
    "pop_active": 23576,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 12.1,
      "Prof. intermédiaires": 17.3,
      "Employés": 19.1,
      "Ouvriers": 10.7,
      "Retraités": 21.3,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 63.0
  },
  "49099": {
    "codgeo": "49099",
    "nom": "Cholet",
    "taux_chomage": 15.4,
    "pop_active": 24647,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.2,
      "Cadres": 7.9,
      "Prof. intermédiaires": 13.5,
      "Employés": 13.3,
      "Ouvriers": 17.1,
      "Retraités": 30.0,
      "Autres inactifs": 14.7
    },
    "taux_emploi": 56.1
  },
  "97414": {
    "codgeo": "97414",
    "nom": "Saint-Louis",
    "taux_chomage": 17.0,
    "pop_active": 22416,
    "categories_sociopro": {
      "Agriculteurs": 0.8,
      "Artisans/commerçants": 3.0,
      "Cadres": 2.5,
      "Prof. intermédiaires": 10.1,
      "Employés": 19.6,
      "Ouvriers": 13.8,
      "Retraités": 14.8,
      "Autres inactifs": 35.4
    },
    "taux_emploi": 44.3
  },
  "93031": {
    "codgeo": "93031",
    "nom": "Épinay-sur-Seine",
    "taux_chomage": 11.7,
    "pop_active": 22821,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 8.3,
      "Prof. intermédiaires": 13.7,
      "Employés": 21.3,
      "Ouvriers": 12.9,
      "Retraités": 15.2,
      "Autres inactifs": 25.7
    },
    "taux_emploi": 46.9
  },
  "93070": {
    "codgeo": "93070",
    "nom": "Saint-Ouen-sur-Seine",
    "taux_chomage": 5.0,
    "pop_active": 23928,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 18.3,
      "Prof. intermédiaires": 16.3,
      "Employés": 18.7,
      "Ouvriers": 9.6,
      "Retraités": 12.9,
      "Autres inactifs": 20.6
    },
    "taux_emploi": 65.1
  },
  "02691": {
    "codgeo": "02691",
    "nom": "Saint-Quentin",
    "taux_chomage": 11.2,
    "pop_active": 24001,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.5,
      "Cadres": 5.7,
      "Prof. intermédiaires": 11.0,
      "Employés": 15.4,
      "Ouvriers": 13.6,
      "Retraités": 28.8,
      "Autres inactifs": 23.0
    },
    "taux_emploi": 48.0
  },
  "93010": {
    "codgeo": "93010",
    "nom": "Bondy",
    "taux_chomage": 11.4,
    "pop_active": 22055,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 6.5,
      "Prof. intermédiaires": 12.5,
      "Employés": 21.2,
      "Ouvriers": 14.1,
      "Retraités": 16.5,
      "Autres inactifs": 25.7
    },
    "taux_emploi": 51.8
  },
  "64102": {
    "codgeo": "64102",
    "nom": "Bayonne",
    "taux_chomage": 9.5,
    "pop_active": 25391,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.1,
      "Cadres": 9.4,
      "Prof. intermédiaires": 15.9,
      "Employés": 17.8,
      "Ouvriers": 10.2,
      "Retraités": 26.2,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 55.4
  },
  "91174": {
    "codgeo": "91174",
    "nom": "Corbeil-Essonnes",
    "taux_chomage": 12.2,
    "pop_active": 22363,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 6.8,
      "Prof. intermédiaires": 15.0,
      "Employés": 19.7,
      "Ouvriers": 17.1,
      "Retraités": 15.0,
      "Autres inactifs": 23.5
    },
    "taux_emploi": 53.1
  },
  "06027": {
    "codgeo": "06027",
    "nom": "Cagnes-sur-Mer",
    "taux_chomage": 8.0,
    "pop_active": 24377,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 5.4,
      "Cadres": 9.3,
      "Prof. intermédiaires": 14.0,
      "Employés": 17.3,
      "Ouvriers": 8.6,
      "Retraités": 32.0,
      "Autres inactifs": 13.4
    },
    "taux_emploi": 56.3
  },
  "69256": {
    "codgeo": "69256",
    "nom": "Vaulx-en-Velin",
    "taux_chomage": 10.7,
    "pop_active": 20953,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 5.1,
      "Prof. intermédiaires": 11.5,
      "Employés": 18.1,
      "Ouvriers": 17.5,
      "Retraités": 14.6,
      "Autres inactifs": 30.1
    },
    "taux_emploi": 50.0
  },
  "97101": {
    "codgeo": "97101",
    "nom": "Les Abymes",
    "taux_chomage": 16.4,
    "pop_active": 23423,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 4.5,
      "Cadres": 3.3,
      "Prof. intermédiaires": 11.1,
      "Employés": 20.2,
      "Ouvriers": 10.6,
      "Retraités": 21.1,
      "Autres inactifs": 28.9
    },
    "taux_emploi": 46.2
  },
  "93071": {
    "codgeo": "93071",
    "nom": "Sevran",
    "taux_chomage": 12.0,
    "pop_active": 21819,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 5.2,
      "Prof. intermédiaires": 12.3,
      "Employés": 20.7,
      "Ouvriers": 15.1,
      "Retraités": 16.3,
      "Autres inactifs": 27.4
    },
    "taux_emploi": 45.0
  },
  "94033": {
    "codgeo": "94033",
    "nom": "Fontenay-sous-Bois",
    "taux_chomage": 5.0,
    "pop_active": 23060,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 21.1,
      "Prof. intermédiaires": 16.4,
      "Employés": 15.7,
      "Ouvriers": 6.8,
      "Retraités": 20.3,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 69.1
  },
  "78586": {
    "codgeo": "78586",
    "nom": "Sartrouville",
    "taux_chomage": 5.0,
    "pop_active": 22857,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 18.6,
      "Prof. intermédiaires": 15.0,
      "Employés": 16.2,
      "Ouvriers": 9.5,
      "Retraités": 21.6,
      "Autres inactifs": 16.5
    },
    "taux_emploi": 66.5
  },
  "91377": {
    "codgeo": "91377",
    "nom": "Massy",
    "taux_chomage": 5.0,
    "pop_active": 22417,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.8,
      "Cadres": 26.6,
      "Prof. intermédiaires": 17.2,
      "Employés": 14.6,
      "Ouvriers": 7.5,
      "Retraités": 16.5,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 75
  },
  "13004": {
    "codgeo": "13004",
    "nom": "Arles",
    "taux_chomage": 9.1,
    "pop_active": 23221,
    "categories_sociopro": {
      "Agriculteurs": 0.8,
      "Artisans/commerçants": 4.4,
      "Cadres": 6.4,
      "Prof. intermédiaires": 12.0,
      "Employés": 15.1,
      "Ouvriers": 11.2,
      "Retraités": 29.2,
      "Autres inactifs": 21.0
    },
    "taux_emploi": 51.7
  },
  "97311": {
    "codgeo": "97311",
    "nom": "Saint-Laurent-du-Maroni",
    "taux_chomage": 15.7,
    "pop_active": 15234,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 1.8,
      "Cadres": 3.7,
      "Prof. intermédiaires": 8.5,
      "Employés": 13.4,
      "Ouvriers": 13.1,
      "Retraités": 3.1,
      "Autres inactifs": 56.0
    },
    "taux_emploi": 50.2
  },
  "81004": {
    "codgeo": "81004",
    "nom": "Albi",
    "taux_chomage": 12.6,
    "pop_active": 23981,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.6,
      "Cadres": 7.7,
      "Prof. intermédiaires": 12.7,
      "Employés": 13.5,
      "Ouvriers": 8.7,
      "Retraités": 32.4,
      "Autres inactifs": 21.3
    },
    "taux_emploi": 51.6
  },
  "53130": {
    "codgeo": "53130",
    "nom": "Laval",
    "taux_chomage": 8.8,
    "pop_active": 22784,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.2,
      "Cadres": 9.1,
      "Prof. intermédiaires": 14.3,
      "Employés": 13.9,
      "Ouvriers": 13.8,
      "Retraités": 28.0,
      "Autres inactifs": 18.4
    },
    "taux_emploi": 52.4
  },
  "44162": {
    "codgeo": "44162",
    "nom": "Saint-Herblain",
    "taux_chomage": 5.6,
    "pop_active": 22382,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 13.1,
      "Prof. intermédiaires": 18.1,
      "Employés": 15.8,
      "Ouvriers": 10.6,
      "Retraités": 24.0,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 57.6
  },
  "92036": {
    "codgeo": "92036",
    "nom": "Gennevilliers",
    "taux_chomage": 10.7,
    "pop_active": 21262,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 8.0,
      "Prof. intermédiaires": 14.0,
      "Employés": 20.6,
      "Ouvriers": 13.3,
      "Retraités": 17.0,
      "Autres inactifs": 24.0
    },
    "taux_emploi": 54.2
  },
  "92073": {
    "codgeo": "92073",
    "nom": "Suresnes",
    "taux_chomage": 5.0,
    "pop_active": 21613,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.9,
      "Cadres": 32.1,
      "Prof. intermédiaires": 15.2,
      "Employés": 13.9,
      "Ouvriers": 4.4,
      "Retraités": 16.3,
      "Autres inactifs": 14.2
    },
    "taux_emploi": 75
  },
  "69290": {
    "codgeo": "69290",
    "nom": "Saint-Priest",
    "taux_chomage": 8.4,
    "pop_active": 20952,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 8.7,
      "Prof. intermédiaires": 16.1,
      "Employés": 17.9,
      "Ouvriers": 14.2,
      "Retraités": 20.8,
      "Autres inactifs": 19.2
    },
    "taux_emploi": 51.2
  },
  "94080": {
    "codgeo": "94080",
    "nom": "Vincennes",
    "taux_chomage": 5.0,
    "pop_active": 22188,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 37.0,
      "Prof. intermédiaires": 16.3,
      "Employés": 9.7,
      "Ouvriers": 3.2,
      "Retraités": 18.0,
      "Autres inactifs": 12.5
    },
    "taux_emploi": 75
  },
  "2B033": {
    "codgeo": "2B033",
    "nom": "Bastia",
    "taux_chomage": 9.7,
    "pop_active": 22426,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.8,
      "Cadres": 4.9,
      "Prof. intermédiaires": 11.6,
      "Employés": 18.5,
      "Ouvriers": 10.3,
      "Retraités": 24.1,
      "Autres inactifs": 25.6
    },
    "taux_emploi": 47.2
  },
  "13056": {
    "codgeo": "13056",
    "nom": "Martigues",
    "taux_chomage": 9.3,
    "pop_active": 21991,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.3,
      "Cadres": 6.8,
      "Prof. intermédiaires": 14.5,
      "Employés": 16.9,
      "Ouvriers": 12.3,
      "Retraités": 27.2,
      "Autres inactifs": 18.9
    },
    "taux_emploi": 50.4
  },
  "85194": {
    "codgeo": "85194",
    "nom": "Les Sables-d'Olonne",
    "taux_chomage": 9.9,
    "pop_active": 24215,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 4.9,
      "Cadres": 6.2,
      "Prof. intermédiaires": 10.0,
      "Employés": 12.0,
      "Ouvriers": 7.6,
      "Retraités": 49.1,
      "Autres inactifs": 10.0
    },
    "taux_emploi": 54.3
  },
  "06069": {
    "codgeo": "06069",
    "nom": "Grasse",
    "taux_chomage": 9.6,
    "pop_active": 22242,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 5.4,
      "Cadres": 9.3,
      "Prof. intermédiaires": 13.5,
      "Employés": 16.6,
      "Ouvriers": 11.5,
      "Retraités": 25.0,
      "Autres inactifs": 18.7
    },
    "taux_emploi": 55.3
  },
  "92049": {
    "codgeo": "92049",
    "nom": "Montrouge",
    "taux_chomage": 5.0,
    "pop_active": 22374,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 31.3,
      "Prof. intermédiaires": 16.5,
      "Employés": 12.5,
      "Ouvriers": 4.2,
      "Retraités": 18.8,
      "Autres inactifs": 14.0
    },
    "taux_emploi": 75
  },
  "13005": {
    "codgeo": "13005",
    "nom": "Aubagne",
    "taux_chomage": 9.6,
    "pop_active": 21452,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 7.6,
      "Prof. intermédiaires": 14.6,
      "Employés": 17.8,
      "Ouvriers": 10.8,
      "Retraités": 27.4,
      "Autres inactifs": 18.4
    },
    "taux_emploi": 55.2
  },
  "35288": {
    "codgeo": "35288",
    "nom": "Saint-Malo",
    "taux_chomage": 10.5,
    "pop_active": 23104,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.6,
      "Cadres": 7.7,
      "Prof. intermédiaires": 11.3,
      "Employés": 13.9,
      "Ouvriers": 8.9,
      "Retraités": 41.0,
      "Autres inactifs": 13.5
    },
    "taux_emploi": 48.7
  },
  "27229": {
    "codgeo": "27229",
    "nom": "Évreux",
    "taux_chomage": 11.4,
    "pop_active": 21251,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 7.5,
      "Prof. intermédiaires": 12.8,
      "Employés": 18.0,
      "Ouvriers": 13.8,
      "Retraités": 23.6,
      "Autres inactifs": 22.3
    },
    "taux_emploi": 54.2
  },
  "93027": {
    "codgeo": "93027",
    "nom": "La Courneuve",
    "taux_chomage": 11.4,
    "pop_active": 19896,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.8,
      "Cadres": 4.0,
      "Prof. intermédiaires": 9.3,
      "Employés": 20.8,
      "Ouvriers": 20.4,
      "Retraités": 11.6,
      "Autres inactifs": 30.1
    },
    "taux_emploi": 51.6
  },
  "41018": {
    "codgeo": "41018",
    "nom": "Blois",
    "taux_chomage": 9.1,
    "pop_active": 20877,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 8.5,
      "Prof. intermédiaires": 12.4,
      "Employés": 14.3,
      "Ouvriers": 13.1,
      "Retraités": 27.4,
      "Autres inactifs": 21.5
    },
    "taux_emploi": 55.6
  },
  "19031": {
    "codgeo": "19031",
    "nom": "Brive-la-Gaillarde",
    "taux_chomage": 9.0,
    "pop_active": 22037,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.1,
      "Cadres": 6.9,
      "Prof. intermédiaires": 11.9,
      "Employés": 16.1,
      "Ouvriers": 11.7,
      "Retraités": 32.8,
      "Autres inactifs": 17.3
    },
    "taux_emploi": 48.8
  },
  "08105": {
    "codgeo": "08105",
    "nom": "Charleville-Mézières",
    "taux_chomage": 9.9,
    "pop_active": 21311,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 5.6,
      "Prof. intermédiaires": 11.1,
      "Employés": 16.2,
      "Ouvriers": 13.1,
      "Retraités": 28.7,
      "Autres inactifs": 22.9
    },
    "taux_emploi": 50.3
  },
  "92048": {
    "codgeo": "92048",
    "nom": "Meudon",
    "taux_chomage": 5.0,
    "pop_active": 20644,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 26.9,
      "Prof. intermédiaires": 14.7,
      "Employés": 12.9,
      "Ouvriers": 4.4,
      "Retraités": 21.8,
      "Autres inactifs": 15.6
    },
    "taux_emploi": 73.3
  },
  "11069": {
    "codgeo": "11069",
    "nom": "Carcassonne",
    "taux_chomage": 14.8,
    "pop_active": 21641,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.5,
      "Cadres": 5.6,
      "Prof. intermédiaires": 12.0,
      "Employés": 18.6,
      "Ouvriers": 9.2,
      "Retraités": 30.3,
      "Autres inactifs": 20.6
    },
    "taux_emploi": 49.8
  },
  "94022": {
    "codgeo": "94022",
    "nom": "Choisy-le-Roi",
    "taux_chomage": 6.3,
    "pop_active": 20362,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 12.4,
      "Prof. intermédiaires": 15.9,
      "Employés": 19.0,
      "Ouvriers": 11.9,
      "Retraités": 16.1,
      "Autres inactifs": 21.4
    },
    "taux_emploi": 60.4
  },
  "93053": {
    "codgeo": "93053",
    "nom": "Noisy-le-Sec",
    "taux_chomage": 14.2,
    "pop_active": 19166,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 9.2,
      "Prof. intermédiaires": 14.6,
      "Employés": 22.0,
      "Ouvriers": 12.8,
      "Retraités": 14.5,
      "Autres inactifs": 23.3
    },
    "taux_emploi": 59.0
  },
  "93046": {
    "codgeo": "93046",
    "nom": "Livry-Gargan",
    "taux_chomage": 10.3,
    "pop_active": 19717,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 9.3,
      "Prof. intermédiaires": 17.0,
      "Employés": 19.4,
      "Ouvriers": 11.7,
      "Retraités": 19.3,
      "Autres inactifs": 19.4
    },
    "taux_emploi": 56.3
  },
  "93064": {
    "codgeo": "93064",
    "nom": "Rosny-sous-Bois",
    "taux_chomage": 9.5,
    "pop_active": 19581,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 13.0,
      "Prof. intermédiaires": 16.8,
      "Employés": 21.1,
      "Ouvriers": 9.9,
      "Retraités": 17.2,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 61.5
  },
  "33522": {
    "codgeo": "33522",
    "nom": "Talence",
    "taux_chomage": 8.9,
    "pop_active": 21621,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 16.9,
      "Prof. intermédiaires": 15.1,
      "Employés": 13.8,
      "Ouvriers": 6.8,
      "Retraités": 16.4,
      "Autres inactifs": 27.9
    },
    "taux_emploi": 64.2
  },
  "90010": {
    "codgeo": "90010",
    "nom": "Belfort",
    "taux_chomage": 9.4,
    "pop_active": 20670,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 10.0,
      "Prof. intermédiaires": 11.5,
      "Employés": 16.2,
      "Ouvriers": 13.3,
      "Retraités": 23.3,
      "Autres inactifs": 23.7
    },
    "taux_emploi": 53.0
  },
  "94002": {
    "codgeo": "94002",
    "nom": "Alfortville",
    "taux_chomage": 8.2,
    "pop_active": 20259,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 16.7,
      "Prof. intermédiaires": 17.0,
      "Employés": 17.1,
      "Ouvriers": 8.9,
      "Retraités": 18.5,
      "Autres inactifs": 18.4
    },
    "taux_emploi": 65.5
  },
  "71076": {
    "codgeo": "71076",
    "nom": "Chalon-sur-Saône",
    "taux_chomage": 12.3,
    "pop_active": 20875,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.5,
      "Cadres": 6.3,
      "Prof. intermédiaires": 13.5,
      "Employés": 15.7,
      "Ouvriers": 14.9,
      "Retraités": 29.6,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 49.2
  },
  "13103": {
    "codgeo": "13103",
    "nom": "Salon-de-Provence",
    "taux_chomage": 5.9,
    "pop_active": 20426,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.2,
      "Cadres": 10.4,
      "Prof. intermédiaires": 15.5,
      "Employés": 16.3,
      "Ouvriers": 11.2,
      "Retraités": 24.7,
      "Autres inactifs": 18.4
    },
    "taux_emploi": 56.4
  },
  "34301": {
    "codgeo": "34301",
    "nom": "Sète",
    "taux_chomage": 9.0,
    "pop_active": 21540,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.7,
      "Cadres": 6.0,
      "Prof. intermédiaires": 10.1,
      "Employés": 13.6,
      "Ouvriers": 8.3,
      "Retraités": 38.4,
      "Autres inactifs": 19.5
    },
    "taux_emploi": 51.5
  },
  "13047": {
    "codgeo": "13047",
    "nom": "Istres",
    "taux_chomage": 13.4,
    "pop_active": 20134,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.4,
      "Cadres": 6.3,
      "Prof. intermédiaires": 17.2,
      "Employés": 20.2,
      "Ouvriers": 12.1,
      "Retraités": 24.8,
      "Autres inactifs": 16.9
    },
    "taux_emploi": 49.6
  },
  "78361": {
    "codgeo": "78361",
    "nom": "Mantes-la-Jolie",
    "taux_chomage": 12.6,
    "pop_active": 18879,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 6.5,
      "Prof. intermédiaires": 12.0,
      "Employés": 17.5,
      "Ouvriers": 13.6,
      "Retraités": 17.9,
      "Autres inactifs": 30.5
    },
    "taux_emploi": 53.1
  },
  "78551": {
    "codgeo": "78551",
    "nom": "Saint-Germain-en-Laye",
    "taux_chomage": 5.0,
    "pop_active": 19813,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 26.3,
      "Prof. intermédiaires": 15.6,
      "Employés": 12.1,
      "Ouvriers": 4.1,
      "Retraités": 20.8,
      "Autres inactifs": 18.2
    },
    "taux_emploi": 72.5
  },
  "22278": {
    "codgeo": "22278",
    "nom": "Saint-Brieuc",
    "taux_chomage": 7.3,
    "pop_active": 20648,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.1,
      "Cadres": 8.5,
      "Prof. intermédiaires": 14.1,
      "Employés": 13.8,
      "Ouvriers": 12.1,
      "Retraités": 29.0,
      "Autres inactifs": 19.3
    },
    "taux_emploi": 57.1
  },
  "65440": {
    "codgeo": "65440",
    "nom": "Tarbes",
    "taux_chomage": 11.5,
    "pop_active": 20992,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 5.2,
      "Prof. intermédiaires": 10.3,
      "Employés": 18.3,
      "Ouvriers": 10.0,
      "Retraités": 26.6,
      "Autres inactifs": 26.9
    },
    "taux_emploi": 43.0
  },
  "30007": {
    "codgeo": "30007",
    "nom": "Alès",
    "taux_chomage": 12.2,
    "pop_active": 20868,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.3,
      "Cadres": 3.7,
      "Prof. intermédiaires": 9.1,
      "Employés": 15.4,
      "Ouvriers": 10.4,
      "Retraités": 30.3,
      "Autres inactifs": 27.7
    },
    "taux_emploi": 49.5
  },
  "51108": {
    "codgeo": "51108",
    "nom": "Châlons-en-Champagne",
    "taux_chomage": 13.9,
    "pop_active": 20093,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.4,
      "Cadres": 6.7,
      "Prof. intermédiaires": 11.9,
      "Employés": 17.7,
      "Ouvriers": 14.7,
      "Retraités": 25.9,
      "Autres inactifs": 20.4
    },
    "taux_emploi": 50.2
  },
  "92007": {
    "codgeo": "92007",
    "nom": "Bagneux",
    "taux_chomage": 6.7,
    "pop_active": 19113,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 13.7,
      "Prof. intermédiaires": 15.9,
      "Employés": 21.1,
      "Ouvriers": 9.2,
      "Retraités": 16.4,
      "Autres inactifs": 20.8
    },
    "taux_emploi": 58.5
  },
  "92062": {
    "codgeo": "92062",
    "nom": "Puteaux",
    "taux_chomage": 5.0,
    "pop_active": 19528,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 35.0,
      "Prof. intermédiaires": 15.3,
      "Employés": 12.0,
      "Ouvriers": 3.6,
      "Retraités": 16.9,
      "Autres inactifs": 14.2
    },
    "taux_emploi": 74.6
  },
  "69034": {
    "codgeo": "69034",
    "nom": "Caluire-et-Cuire",
    "taux_chomage": 5.0,
    "pop_active": 19703,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.0,
      "Cadres": 18.9,
      "Prof. intermédiaires": 17.3,
      "Employés": 12.6,
      "Ouvriers": 5.7,
      "Retraités": 27.8,
      "Autres inactifs": 13.6
    },
    "taux_emploi": 63.4
  },
  "69029": {
    "codgeo": "69029",
    "nom": "Bron",
    "taux_chomage": 7.6,
    "pop_active": 19151,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 11.9,
      "Prof. intermédiaires": 15.7,
      "Employés": 15.5,
      "Ouvriers": 10.1,
      "Retraités": 21.3,
      "Autres inactifs": 22.4
    },
    "taux_emploi": 54.1
  },
  "44143": {
    "codgeo": "44143",
    "nom": "Rezé",
    "taux_chomage": 8.9,
    "pop_active": 19379,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 14.1,
      "Prof. intermédiaires": 20.0,
      "Employés": 14.8,
      "Ouvriers": 9.7,
      "Retraités": 24.2,
      "Autres inactifs": 14.3
    },
    "taux_emploi": 59.7
  },
  "59606": {
    "codgeo": "59606",
    "nom": "Valenciennes",
    "taux_chomage": 10.4,
    "pop_active": 20146,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 10.3,
      "Prof. intermédiaires": 13.9,
      "Employés": 15.3,
      "Ouvriers": 11.0,
      "Retraités": 21.6,
      "Autres inactifs": 25.4
    },
    "taux_emploi": 54.4
  },
  "36044": {
    "codgeo": "36044",
    "nom": "Châteauroux",
    "taux_chomage": 10.9,
    "pop_active": 19752,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.2,
      "Cadres": 7.0,
      "Prof. intermédiaires": 13.0,
      "Employés": 16.4,
      "Ouvriers": 11.5,
      "Retraités": 32.5,
      "Autres inactifs": 17.2
    },
    "taux_emploi": 55.8
  },
  "95268": {
    "codgeo": "95268",
    "nom": "Garges-lès-Gonesse",
    "taux_chomage": 12.2,
    "pop_active": 17716,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 3.8,
      "Prof. intermédiaires": 10.6,
      "Employés": 19.1,
      "Ouvriers": 17.9,
      "Retraités": 12.5,
      "Autres inactifs": 32.8
    },
    "taux_emploi": 48.1
  },
  "81065": {
    "codgeo": "81065",
    "nom": "Castres",
    "taux_chomage": 12.8,
    "pop_active": 19685,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.7,
      "Cadres": 6.4,
      "Prof. intermédiaires": 12.7,
      "Employés": 16.5,
      "Ouvriers": 10.1,
      "Retraités": 32.9,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 53.3
  },
  "62041": {
    "codgeo": "62041",
    "nom": "Arras",
    "taux_chomage": 6.2,
    "pop_active": 19350,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 10.1,
      "Prof. intermédiaires": 13.8,
      "Employés": 16.1,
      "Ouvriers": 12.2,
      "Retraités": 21.3,
      "Autres inactifs": 24.2
    },
    "taux_emploi": 63.5
  },
  "77288": {
    "codgeo": "77288",
    "nom": "Melun",
    "taux_chomage": 12.2,
    "pop_active": 18101,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.1,
      "Cadres": 9.2,
      "Prof. intermédiaires": 13.7,
      "Employés": 21.4,
      "Ouvriers": 13.8,
      "Retraités": 14.3,
      "Autres inactifs": 25.4
    },
    "taux_emploi": 53.8
  },
  "57672": {
    "codgeo": "57672",
    "nom": "Thionville",
    "taux_chomage": 9.0,
    "pop_active": 19859,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.5,
      "Cadres": 11.3,
      "Prof. intermédiaires": 15.1,
      "Employés": 19.3,
      "Ouvriers": 10.0,
      "Retraités": 24.6,
      "Autres inactifs": 17.0
    },
    "taux_emploi": 55.0
  },
  "06030": {
    "codgeo": "06030",
    "nom": "Le Cannet",
    "taux_chomage": 7.2,
    "pop_active": 19655,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 5.6,
      "Cadres": 7.2,
      "Prof. intermédiaires": 12.9,
      "Employés": 17.4,
      "Ouvriers": 10.2,
      "Retraités": 31.5,
      "Autres inactifs": 15.2
    },
    "taux_emploi": 60.7
  },
  "01053": {
    "codgeo": "01053",
    "nom": "Bourg-en-Bresse",
    "taux_chomage": 8.1,
    "pop_active": 19210,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 6.7,
      "Prof. intermédiaires": 13.8,
      "Employés": 14.6,
      "Ouvriers": 13.9,
      "Retraités": 27.7,
      "Autres inactifs": 21.2
    },
    "taux_emploi": 46.1
  },
  "64024": {
    "codgeo": "64024",
    "nom": "Anglet",
    "taux_chomage": 8.5,
    "pop_active": 20278,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.5,
      "Cadres": 9.5,
      "Prof. intermédiaires": 14.7,
      "Employés": 14.7,
      "Ouvriers": 6.9,
      "Retraités": 35.9,
      "Autres inactifs": 13.7
    },
    "taux_emploi": 57.8
  },
  "16015": {
    "codgeo": "16015",
    "nom": "Angoulême",
    "taux_chomage": 11.8,
    "pop_active": 19308,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.1,
      "Cadres": 10.3,
      "Prof. intermédiaires": 14.7,
      "Employés": 15.6,
      "Ouvriers": 10.6,
      "Retraités": 25.4,
      "Autres inactifs": 20.3
    },
    "taux_emploi": 57.3
  },
  "62160": {
    "codgeo": "62160",
    "nom": "Boulogne-sur-Mer",
    "taux_chomage": 16.7,
    "pop_active": 18799,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 4.7,
      "Prof. intermédiaires": 10.4,
      "Employés": 17.0,
      "Ouvriers": 17.0,
      "Retraités": 24.9,
      "Autres inactifs": 23.4
    },
    "taux_emploi": 52.9
  },
  "59650": {
    "codgeo": "59650",
    "nom": "Wattrelos",
    "taux_chomage": 11.8,
    "pop_active": 17909,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 3.6,
      "Prof. intermédiaires": 12.7,
      "Employés": 19.6,
      "Ouvriers": 18.7,
      "Retraités": 23.9,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 48.0
  },
  "05061": {
    "codgeo": "05061",
    "nom": "Gap",
    "taux_chomage": 11.9,
    "pop_active": 18950,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.7,
      "Cadres": 6.5,
      "Prof. intermédiaires": 14.2,
      "Employés": 17.7,
      "Ouvriers": 9.4,
      "Retraités": 33.8,
      "Autres inactifs": 14.6
    },
    "taux_emploi": 48.4
  },
  "33550": {
    "codgeo": "33550",
    "nom": "Villenave-d'Ornon",
    "taux_chomage": 10.8,
    "pop_active": 18587,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.7,
      "Cadres": 11.2,
      "Prof. intermédiaires": 20.3,
      "Employés": 19.2,
      "Ouvriers": 10.5,
      "Retraités": 20.7,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 56.1
  },
  "26198": {
    "codgeo": "26198",
    "nom": "Montélimar",
    "taux_chomage": 11.1,
    "pop_active": 18206,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.8,
      "Cadres": 6.9,
      "Prof. intermédiaires": 13.6,
      "Employés": 15.0,
      "Ouvriers": 13.0,
      "Retraités": 28.5,
      "Autres inactifs": 19.2
    },
    "taux_emploi": 54.3
  },
  "60159": {
    "codgeo": "60159",
    "nom": "Compiègne",
    "taux_chomage": 9.6,
    "pop_active": 18462,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 12.2,
      "Prof. intermédiaires": 12.0,
      "Employés": 15.0,
      "Ouvriers": 10.4,
      "Retraités": 22.8,
      "Autres inactifs": 25.1
    },
    "taux_emploi": 54.0
  },
  "93072": {
    "codgeo": "93072",
    "nom": "Stains",
    "taux_chomage": 11.5,
    "pop_active": 16606,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 3.1,
      "Prof. intermédiaires": 11.1,
      "Employés": 22.4,
      "Ouvriers": 16.1,
      "Retraités": 12.8,
      "Autres inactifs": 31.3
    },
    "taux_emploi": 50.7
  },
  "93032": {
    "codgeo": "93032",
    "nom": "Gagny",
    "taux_chomage": 7.5,
    "pop_active": 17193,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 12.0,
      "Prof. intermédiaires": 18.0,
      "Employés": 17.6,
      "Ouvriers": 10.9,
      "Retraités": 18.8,
      "Autres inactifs": 19.5
    },
    "taux_emploi": 54.8
  },
  "31149": {
    "codgeo": "31149",
    "nom": "Colomiers",
    "taux_chomage": 7.1,
    "pop_active": 17896,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 16.5,
      "Prof. intermédiaires": 16.5,
      "Employés": 14.6,
      "Ouvriers": 10.6,
      "Retraités": 21.7,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 66.0
  },
  "78498": {
    "codgeo": "78498",
    "nom": "Poissy",
    "taux_chomage": 5.5,
    "pop_active": 17394,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 17.7,
      "Prof. intermédiaires": 15.2,
      "Employés": 17.0,
      "Ouvriers": 8.3,
      "Retraités": 22.1,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 66.6
  },
  "83050": {
    "codgeo": "83050",
    "nom": "Draguignan",
    "taux_chomage": 6.0,
    "pop_active": 18128,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 4.2,
      "Cadres": 5.9,
      "Prof. intermédiaires": 12.9,
      "Employés": 18.7,
      "Ouvriers": 10.0,
      "Retraités": 29.0,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 51.4
  },
  "59178": {
    "codgeo": "59178",
    "nom": "Douai",
    "taux_chomage": 12.1,
    "pop_active": 18126,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 7.1,
      "Prof. intermédiaires": 11.3,
      "Employés": 15.0,
      "Ouvriers": 14.4,
      "Retraités": 22.9,
      "Autres inactifs": 26.9
    },
    "taux_emploi": 54.7
  },
  "97213": {
    "codgeo": "97213",
    "nom": "Le Lamentin",
    "taux_chomage": 8.0,
    "pop_active": 18207,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 4.7,
      "Cadres": 7.2,
      "Prof. intermédiaires": 16.5,
      "Employés": 19.8,
      "Ouvriers": 9.9,
      "Retraités": 21.9,
      "Autres inactifs": 19.8
    },
    "taux_emploi": 51.4
  },
  "93006": {
    "codgeo": "93006",
    "nom": "Bagnolet",
    "taux_chomage": 6.5,
    "pop_active": 17433,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 15.0,
      "Prof. intermédiaires": 15.1,
      "Employés": 19.3,
      "Ouvriers": 10.8,
      "Retraités": 15.2,
      "Autres inactifs": 21.0
    },
    "taux_emploi": 57.6
  },
  "59378": {
    "codgeo": "59378",
    "nom": "Marcq-en-Barœul",
    "taux_chomage": 5.0,
    "pop_active": 17573,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 23.5,
      "Prof. intermédiaires": 15.0,
      "Employés": 11.8,
      "Ouvriers": 5.5,
      "Retraités": 25.1,
      "Autres inactifs": 15.7
    },
    "taux_emploi": 70.5
  },
  "97412": {
    "codgeo": "97412",
    "nom": "Saint-Joseph",
    "taux_chomage": 12.1,
    "pop_active": 16794,
    "categories_sociopro": {
      "Agriculteurs": 1.8,
      "Artisans/commerçants": 3.4,
      "Cadres": 2.0,
      "Prof. intermédiaires": 9.7,
      "Employés": 21.4,
      "Ouvriers": 14.3,
      "Retraités": 17.3,
      "Autres inactifs": 30.0
    },
    "taux_emploi": 45.5
  },
  "93078": {
    "codgeo": "93078",
    "nom": "Villepinte",
    "taux_chomage": 13.3,
    "pop_active": 15998,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 5.3,
      "Prof. intermédiaires": 14.2,
      "Employés": 21.1,
      "Ouvriers": 13.7,
      "Retraités": 14.6,
      "Autres inactifs": 28.0
    },
    "taux_emploi": 47.0
  },
  "38421": {
    "codgeo": "38421",
    "nom": "Saint-Martin-d'Hères",
    "taux_chomage": 12.6,
    "pop_active": 17909,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 9.8,
      "Prof. intermédiaires": 13.6,
      "Employés": 16.3,
      "Ouvriers": 10.9,
      "Retraités": 15.3,
      "Autres inactifs": 32.0
    },
    "taux_emploi": 53.3
  },
  "28085": {
    "codgeo": "28085",
    "nom": "Chartres",
    "taux_chomage": 10.8,
    "pop_active": 17960,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.7,
      "Cadres": 11.9,
      "Prof. intermédiaires": 14.8,
      "Employés": 15.0,
      "Ouvriers": 11.3,
      "Retraités": 27.5,
      "Autres inactifs": 16.6
    },
    "taux_emploi": 61.6
  },
  "77373": {
    "codgeo": "77373",
    "nom": "Pontault-Combault",
    "taux_chomage": 10.7,
    "pop_active": 16953,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.7,
      "Cadres": 10.8,
      "Prof. intermédiaires": 17.9,
      "Employés": 19.6,
      "Ouvriers": 11.0,
      "Retraités": 20.1,
      "Autres inactifs": 16.9
    },
    "taux_emploi": 59.3
  },
  "37122": {
    "codgeo": "37122",
    "nom": "Joué-lès-Tours",
    "taux_chomage": 7.9,
    "pop_active": 17540,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.5,
      "Cadres": 7.2,
      "Prof. intermédiaires": 14.5,
      "Employés": 16.9,
      "Ouvriers": 11.7,
      "Retraités": 29.6,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 57.2
  },
  "74012": {
    "codgeo": "74012",
    "nom": "Annemasse",
    "taux_chomage": 11.3,
    "pop_active": 16558,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 7.5,
      "Prof. intermédiaires": 14.6,
      "Employés": 23.3,
      "Ouvriers": 16.0,
      "Retraités": 16.0,
      "Autres inactifs": 19.2
    },
    "taux_emploi": 53.5
  },
  "69149": {
    "codgeo": "69149",
    "nom": "Oullins-Pierre-Bénite",
    "taux_chomage": 5.0,
    "pop_active": 17664,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 12.4,
      "Prof. intermédiaires": 18.2,
      "Employés": 16.9,
      "Ouvriers": 10.6,
      "Retraités": 21.6,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 59.0
  },
  "93050": {
    "codgeo": "93050",
    "nom": "Neuilly-sur-Marne",
    "taux_chomage": 11.1,
    "pop_active": 16220,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 9.4,
      "Prof. intermédiaires": 15.2,
      "Employés": 23.5,
      "Ouvriers": 11.0,
      "Retraités": 16.2,
      "Autres inactifs": 22.0
    },
    "taux_emploi": 54.5
  },
  "95252": {
    "codgeo": "95252",
    "nom": "Franconville",
    "taux_chomage": 8.2,
    "pop_active": 16229,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 12.5,
      "Prof. intermédiaires": 19.2,
      "Employés": 19.5,
      "Ouvriers": 9.7,
      "Retraités": 20.8,
      "Autres inactifs": 15.5
    },
    "taux_emploi": 58.1
  },
  "91589": {
    "codgeo": "91589",
    "nom": "Savigny-sur-Orge",
    "taux_chomage": 9.4,
    "pop_active": 16746,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 14.5,
      "Prof. intermédiaires": 17.6,
      "Employés": 16.1,
      "Ouvriers": 10.3,
      "Retraités": 20.6,
      "Autres inactifs": 17.6
    },
    "taux_emploi": 60.0
  },
  "93073": {
    "codgeo": "93073",
    "nom": "Tremblay-en-France",
    "taux_chomage": 11.7,
    "pop_active": 16125,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 7.1,
      "Prof. intermédiaires": 17.7,
      "Employés": 20.0,
      "Ouvriers": 14.2,
      "Retraités": 18.2,
      "Autres inactifs": 19.9
    },
    "taux_emploi": 50.8
  },
  "74281": {
    "codgeo": "74281",
    "nom": "Thonon-les-Bains",
    "taux_chomage": 9.0,
    "pop_active": 16778,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 8.0,
      "Prof. intermédiaires": 16.3,
      "Employés": 18.8,
      "Ouvriers": 12.4,
      "Retraités": 26.7,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 58.3
  },
  "97410": {
    "codgeo": "97410",
    "nom": "Saint-Benoît",
    "taux_chomage": 14.8,
    "pop_active": 14609,
    "categories_sociopro": {
      "Agriculteurs": 1.5,
      "Artisans/commerçants": 3.5,
      "Cadres": 2.8,
      "Prof. intermédiaires": 9.6,
      "Employés": 18.6,
      "Ouvriers": 12.0,
      "Retraités": 15.1,
      "Autres inactifs": 36.9
    },
    "taux_emploi": 39.3
  },
  "13028": {
    "codgeo": "13028",
    "nom": "La Ciotat",
    "taux_chomage": 6.7,
    "pop_active": 17582,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.2,
      "Cadres": 9.4,
      "Prof. intermédiaires": 14.0,
      "Employés": 13.7,
      "Ouvriers": 8.0,
      "Retraités": 33.6,
      "Autres inactifs": 17.0
    },
    "taux_emploi": 52.1
  },
  "38151": {
    "codgeo": "38151",
    "nom": "Échirolles",
    "taux_chomage": 10.2,
    "pop_active": 16028,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 5.9,
      "Prof. intermédiaires": 12.0,
      "Employés": 18.2,
      "Ouvriers": 14.6,
      "Retraités": 24.6,
      "Autres inactifs": 22.1
    },
    "taux_emploi": 52.9
  },
  "92020": {
    "codgeo": "92020",
    "nom": "Châtillon",
    "taux_chomage": 5.0,
    "pop_active": 16581,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 29.7,
      "Prof. intermédiaires": 16.9,
      "Employés": 11.7,
      "Ouvriers": 4.1,
      "Retraités": 20.9,
      "Autres inactifs": 14.2
    },
    "taux_emploi": 74.4
  },
  "91027": {
    "codgeo": "91027",
    "nom": "Athis-Mons",
    "taux_chomage": 6.2,
    "pop_active": 15279,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 10.6,
      "Prof. intermédiaires": 16.5,
      "Employés": 20.2,
      "Ouvriers": 12.5,
      "Retraités": 18.2,
      "Autres inactifs": 18.6
    },
    "taux_emploi": 51.9
  },
  "83129": {
    "codgeo": "83129",
    "nom": "Six-Fours-les-Plages",
    "taux_chomage": 10.6,
    "pop_active": 17495,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.7,
      "Cadres": 8.1,
      "Prof. intermédiaires": 13.0,
      "Employés": 14.8,
      "Ouvriers": 6.0,
      "Retraités": 39.9,
      "Autres inactifs": 13.5
    },
    "taux_emploi": 56.2
  },
  "60175": {
    "codgeo": "60175",
    "nom": "Creil",
    "taux_chomage": 10.5,
    "pop_active": 14494,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 4.0,
      "Prof. intermédiaires": 9.5,
      "Employés": 19.2,
      "Ouvriers": 17.7,
      "Retraités": 14.2,
      "Autres inactifs": 32.8
    },
    "taux_emploi": 47.0
  },
  "83118": {
    "codgeo": "83118",
    "nom": "Saint-Raphaël",
    "taux_chomage": 11.8,
    "pop_active": 17578,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 5.1,
      "Cadres": 5.7,
      "Prof. intermédiaires": 9.9,
      "Employés": 12.0,
      "Ouvriers": 5.5,
      "Retraités": 48.2,
      "Autres inactifs": 13.6
    },
    "taux_emploi": 51.8
  },
  "78172": {
    "codgeo": "78172",
    "nom": "Conflans-Sainte-Honorine",
    "taux_chomage": 5.0,
    "pop_active": 15783,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 18.4,
      "Prof. intermédiaires": 18.0,
      "Employés": 15.9,
      "Ouvriers": 7.7,
      "Retraités": 21.6,
      "Autres inactifs": 16.2
    },
    "taux_emploi": 62.0
  },
  "69264": {
    "codgeo": "69264",
    "nom": "Villefranche-sur-Saône",
    "taux_chomage": 10.4,
    "pop_active": 16113,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 7.7,
      "Prof. intermédiaires": 13.1,
      "Employés": 15.7,
      "Ouvriers": 13.9,
      "Retraités": 25.0,
      "Autres inactifs": 21.6
    },
    "taux_emploi": 55.0
  },
  "69282": {
    "codgeo": "69282",
    "nom": "Meyzieu",
    "taux_chomage": 7.0,
    "pop_active": 15657,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 11.7,
      "Prof. intermédiaires": 16.9,
      "Employés": 16.3,
      "Ouvriers": 11.3,
      "Retraités": 23.5,
      "Autres inactifs": 17.0
    },
    "taux_emploi": 55.8
  },
  "91549": {
    "codgeo": "91549",
    "nom": "Sainte-Geneviève-des-Bois",
    "taux_chomage": 9.3,
    "pop_active": 15600,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 12.1,
      "Prof. intermédiaires": 16.7,
      "Employés": 17.0,
      "Ouvriers": 10.0,
      "Retraités": 24.4,
      "Autres inactifs": 16.6
    },
    "taux_emploi": 55.2
  },
  "67180": {
    "codgeo": "67180",
    "nom": "Haguenau",
    "taux_chomage": 10.1,
    "pop_active": 16753,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 8.3,
      "Prof. intermédiaires": 15.0,
      "Employés": 19.1,
      "Ouvriers": 15.0,
      "Retraités": 25.4,
      "Autres inactifs": 14.2
    },
    "taux_emploi": 51.8
  },
  "13117": {
    "codgeo": "13117",
    "nom": "Vitrolles",
    "taux_chomage": 12.9,
    "pop_active": 15550,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 8.6,
      "Prof. intermédiaires": 15.7,
      "Employés": 18.2,
      "Ouvriers": 11.4,
      "Retraités": 23.9,
      "Autres inactifs": 19.3
    },
    "taux_emploi": 60.3
  },
  "94078": {
    "codgeo": "94078",
    "nom": "Villeneuve-Saint-Georges",
    "taux_chomage": 11.2,
    "pop_active": 14904,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 4.2,
      "Prof. intermédiaires": 10.9,
      "Employés": 22.2,
      "Ouvriers": 18.0,
      "Retraités": 13.2,
      "Autres inactifs": 28.0
    },
    "taux_emploi": 46.2
  },
  "97408": {
    "codgeo": "97408",
    "nom": "La Possession",
    "taux_chomage": 9.1,
    "pop_active": 14012,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 4.1,
      "Cadres": 9.8,
      "Prof. intermédiaires": 19.8,
      "Employés": 18.1,
      "Ouvriers": 11.9,
      "Retraités": 12.9,
      "Autres inactifs": 23.2
    },
    "taux_emploi": 59.3
  },
  "42207": {
    "codgeo": "42207",
    "nom": "Saint-Chamond",
    "taux_chomage": 12.4,
    "pop_active": 15793,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.0,
      "Cadres": 5.3,
      "Prof. intermédiaires": 12.1,
      "Employés": 15.5,
      "Ouvriers": 14.2,
      "Retraités": 29.1,
      "Autres inactifs": 20.6
    },
    "taux_emploi": 50.3
  },
  "92019": {
    "codgeo": "92019",
    "nom": "Châtenay-Malabry",
    "taux_chomage": 5.0,
    "pop_active": 15422,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 22.6,
      "Prof. intermédiaires": 16.6,
      "Employés": 15.5,
      "Ouvriers": 6.6,
      "Retraités": 19.6,
      "Autres inactifs": 16.3
    },
    "taux_emploi": 66.4
  },
  "91477": {
    "codgeo": "91477",
    "nom": "Palaiseau",
    "taux_chomage": 5.0,
    "pop_active": 15725,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 25.4,
      "Prof. intermédiaires": 15.9,
      "Employés": 13.1,
      "Ouvriers": 6.2,
      "Retraités": 19.2,
      "Autres inactifs": 18.0
    },
    "taux_emploi": 71.0
  },
  "97413": {
    "codgeo": "97413",
    "nom": "Saint-Leu",
    "taux_chomage": 11.3,
    "pop_active": 14959,
    "categories_sociopro": {
      "Agriculteurs": 1.0,
      "Artisans/commerçants": 5.0,
      "Cadres": 6.3,
      "Prof. intermédiaires": 13.5,
      "Employés": 18.7,
      "Ouvriers": 14.4,
      "Retraités": 15.3,
      "Autres inactifs": 25.8
    },
    "taux_emploi": 53.6
  },
  "97307": {
    "codgeo": "97307",
    "nom": "Matoury",
    "taux_chomage": 12.0,
    "pop_active": 13220,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 4.5,
      "Cadres": 4.1,
      "Prof. intermédiaires": 12.2,
      "Employés": 17.4,
      "Ouvriers": 12.3,
      "Retraités": 9.5,
      "Autres inactifs": 39.8
    },
    "taux_emploi": 49.5
  },
  "89024": {
    "codgeo": "89024",
    "nom": "Auxerre",
    "taux_chomage": 11.5,
    "pop_active": 16200,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.5,
      "Cadres": 6.9,
      "Prof. intermédiaires": 12.7,
      "Employés": 16.7,
      "Ouvriers": 12.7,
      "Retraités": 29.2,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 47.9
  },
  "42187": {
    "codgeo": "42187",
    "nom": "Roanne",
    "taux_chomage": 16.8,
    "pop_active": 16606,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 5.5,
      "Prof. intermédiaires": 11.5,
      "Employés": 13.8,
      "Ouvriers": 12.4,
      "Retraités": 32.9,
      "Autres inactifs": 21.1
    },
    "taux_emploi": 53.7
  },
  "71270": {
    "codgeo": "71270",
    "nom": "Mâcon",
    "taux_chomage": 12.2,
    "pop_active": 15500,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.2,
      "Cadres": 6.9,
      "Prof. intermédiaires": 11.8,
      "Employés": 14.9,
      "Ouvriers": 16.4,
      "Retraités": 28.0,
      "Autres inactifs": 18.6
    },
    "taux_emploi": 49.4
  },
  "97418": {
    "codgeo": "97418",
    "nom": "Sainte-Marie",
    "taux_chomage": 11.5,
    "pop_active": 14356,
    "categories_sociopro": {
      "Agriculteurs": 0.4,
      "Artisans/commerçants": 3.6,
      "Cadres": 6.1,
      "Prof. intermédiaires": 14.3,
      "Employés": 21.1,
      "Ouvriers": 12.6,
      "Retraités": 14.2,
      "Autres inactifs": 27.7
    },
    "taux_emploi": 48.7
  },
  "94058": {
    "codgeo": "94058",
    "nom": "Le Perreux-sur-Marne",
    "taux_chomage": 5.0,
    "pop_active": 15352,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 25.9,
      "Prof. intermédiaires": 18.0,
      "Employés": 11.7,
      "Ouvriers": 4.8,
      "Retraités": 22.0,
      "Autres inactifs": 13.8
    },
    "taux_emploi": 70.3
  },
  "67447": {
    "codgeo": "67447",
    "nom": "Schiltigheim",
    "taux_chomage": 6.5,
    "pop_active": 15160,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 12.3,
      "Prof. intermédiaires": 16.2,
      "Employés": 16.8,
      "Ouvriers": 11.7,
      "Retraités": 20.5,
      "Autres inactifs": 19.7
    },
    "taux_emploi": 57.8
  },
  "78440": {
    "codgeo": "78440",
    "nom": "Les Mureaux",
    "taux_chomage": 9.8,
    "pop_active": 13847,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 5.1,
      "Prof. intermédiaires": 12.4,
      "Employés": 19.5,
      "Ouvriers": 16.5,
      "Retraités": 17.7,
      "Autres inactifs": 26.6
    },
    "taux_emploi": 48.2
  },
  "78621": {
    "codgeo": "78621",
    "nom": "Trappes",
    "taux_chomage": 9.6,
    "pop_active": 14011,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 7.7,
      "Prof. intermédiaires": 14.5,
      "Employés": 20.9,
      "Ouvriers": 16.2,
      "Retraités": 14.1,
      "Autres inactifs": 24.4
    },
    "taux_emploi": 45.4
  },
  "94052": {
    "codgeo": "94052",
    "nom": "Nogent-sur-Marne",
    "taux_chomage": 5.0,
    "pop_active": 15156,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.0,
      "Cadres": 28.4,
      "Prof. intermédiaires": 15.6,
      "Employés": 12.7,
      "Ouvriers": 3.6,
      "Retraités": 20.2,
      "Autres inactifs": 15.5
    },
    "taux_emploi": 72.9
  },
  "78311": {
    "codgeo": "78311",
    "nom": "Houilles",
    "taux_chomage": 5.0,
    "pop_active": 14783,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 29.3,
      "Prof. intermédiaires": 16.6,
      "Employés": 13.3,
      "Ouvriers": 5.0,
      "Retraités": 18.5,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 75
  },
  "03185": {
    "codgeo": "03185",
    "nom": "Montluçon",
    "taux_chomage": 12.8,
    "pop_active": 15904,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.2,
      "Cadres": 5.2,
      "Prof. intermédiaires": 10.4,
      "Employés": 18.8,
      "Ouvriers": 11.2,
      "Retraités": 33.6,
      "Autres inactifs": 18.5
    },
    "taux_emploi": 49.3
  },
  "97407": {
    "codgeo": "97407",
    "nom": "Le Port",
    "taux_chomage": 14.0,
    "pop_active": 14080,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.2,
      "Cadres": 1.4,
      "Prof. intermédiaires": 8.8,
      "Employés": 20.3,
      "Ouvriers": 16.2,
      "Retraités": 14.1,
      "Autres inactifs": 36.9
    },
    "taux_emploi": 43.1
  },
  "93063": {
    "codgeo": "93063",
    "nom": "Romainville",
    "taux_chomage": 8.8,
    "pop_active": 14391,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 14.7,
      "Prof. intermédiaires": 18.5,
      "Employés": 17.8,
      "Ouvriers": 9.4,
      "Retraités": 14.7,
      "Autres inactifs": 21.0
    },
    "taux_emploi": 59.0
  },
  "13054": {
    "codgeo": "13054",
    "nom": "Marignane",
    "taux_chomage": 11.4,
    "pop_active": 14924,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.5,
      "Cadres": 6.2,
      "Prof. intermédiaires": 16.8,
      "Employés": 17.0,
      "Ouvriers": 13.5,
      "Retraités": 24.0,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 50.9
  },
  "26281": {
    "codgeo": "26281",
    "nom": "Romans-sur-Isère",
    "taux_chomage": 12.2,
    "pop_active": 15066,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 5.8,
      "Prof. intermédiaires": 12.8,
      "Employés": 14.9,
      "Ouvriers": 14.9,
      "Retraités": 30.7,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 46.8
  },
  "58194": {
    "codgeo": "58194",
    "nom": "Nevers",
    "taux_chomage": 10.5,
    "pop_active": 15798,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.3,
      "Cadres": 6.8,
      "Prof. intermédiaires": 12.6,
      "Employés": 13.6,
      "Ouvriers": 10.5,
      "Retraités": 33.0,
      "Autres inactifs": 21.1
    },
    "taux_emploi": 55.5
  },
  "62498": {
    "codgeo": "62498",
    "nom": "Lens",
    "taux_chomage": 8.3,
    "pop_active": 14780,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 4.2,
      "Prof. intermédiaires": 9.9,
      "Employés": 16.2,
      "Ouvriers": 16.7,
      "Retraités": 23.8,
      "Autres inactifs": 26.9
    },
    "taux_emploi": 52.4
  },
  "33449": {
    "codgeo": "33449",
    "nom": "Saint-Médard-en-Jalles",
    "taux_chomage": 5.0,
    "pop_active": 14466,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 14.7,
      "Prof. intermédiaires": 18.5,
      "Employés": 15.3,
      "Ouvriers": 7.6,
      "Retraités": 26.6,
      "Autres inactifs": 13.7
    },
    "taux_emploi": 57.6
  },
  "47001": {
    "codgeo": "47001",
    "nom": "Agen",
    "taux_chomage": 8.7,
    "pop_active": 15089,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 7.8,
      "Prof. intermédiaires": 13.6,
      "Employés": 18.2,
      "Ouvriers": 13.3,
      "Retraités": 25.1,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 59.3
  },
  "93059": {
    "codgeo": "93059",
    "nom": "Pierrefitte-sur-Seine",
    "taux_chomage": 10.9,
    "pop_active": 13424,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 5.1,
      "Prof. intermédiaires": 11.8,
      "Employés": 19.9,
      "Ouvriers": 17.8,
      "Retraités": 12.3,
      "Autres inactifs": 30.3
    },
    "taux_emploi": 49.2
  },
  "88160": {
    "codgeo": "88160",
    "nom": "Épinal",
    "taux_chomage": 9.3,
    "pop_active": 15000,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.5,
      "Cadres": 7.9,
      "Prof. intermédiaires": 13.9,
      "Employés": 16.2,
      "Ouvriers": 9.7,
      "Retraités": 26.7,
      "Autres inactifs": 22.0
    },
    "taux_emploi": 58.9
  },
  "95063": {
    "codgeo": "95063",
    "nom": "Bezons",
    "taux_chomage": 6.8,
    "pop_active": 13888,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 14.3,
      "Prof. intermédiaires": 14.9,
      "Employés": 20.8,
      "Ouvriers": 11.8,
      "Retraités": 16.1,
      "Autres inactifs": 18.7
    },
    "taux_emploi": 58.5
  },
  "73008": {
    "codgeo": "73008",
    "nom": "Aix-les-Bains",
    "taux_chomage": 9.2,
    "pop_active": 15065,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 10.0,
      "Prof. intermédiaires": 15.9,
      "Employés": 14.5,
      "Ouvriers": 9.9,
      "Retraités": 33.0,
      "Autres inactifs": 12.9
    },
    "taux_emploi": 52.3
  },
  "78423": {
    "codgeo": "78423",
    "nom": "Montigny-le-Bretonneux",
    "taux_chomage": 5.0,
    "pop_active": 14210,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.7,
      "Cadres": 29.6,
      "Prof. intermédiaires": 16.6,
      "Employés": 12.1,
      "Ouvriers": 3.7,
      "Retraités": 20.7,
      "Autres inactifs": 15.6
    },
    "taux_emploi": 75
  },
  "95306": {
    "codgeo": "95306",
    "nom": "Herblay-sur-Seine",
    "taux_chomage": 5.0,
    "pop_active": 13510,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 17.4,
      "Prof. intermédiaires": 18.3,
      "Employés": 16.2,
      "Ouvriers": 7.5,
      "Retraités": 18.2,
      "Autres inactifs": 18.9
    },
    "taux_emploi": 70.5
  },
  "59122": {
    "codgeo": "59122",
    "nom": "Cambrai",
    "taux_chomage": 12.2,
    "pop_active": 14692,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.7,
      "Cadres": 5.5,
      "Prof. intermédiaires": 12.4,
      "Employés": 15.7,
      "Ouvriers": 13.7,
      "Retraités": 31.3,
      "Autres inactifs": 18.6
    },
    "taux_emploi": 47.0
  },
  "94038": {
    "codgeo": "94038",
    "nom": "L'Haÿ-les-Roses",
    "taux_chomage": 9.2,
    "pop_active": 13586,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 15.4,
      "Prof. intermédiaires": 15.0,
      "Employés": 16.8,
      "Ouvriers": 8.2,
      "Retraités": 22.4,
      "Autres inactifs": 19.3
    },
    "taux_emploi": 59.8
  },
  "78490": {
    "codgeo": "78490",
    "nom": "Plaisir",
    "taux_chomage": 6.9,
    "pop_active": 13757,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 16.0,
      "Prof. intermédiaires": 18.8,
      "Employés": 18.4,
      "Ouvriers": 8.0,
      "Retraités": 19.1,
      "Autres inactifs": 17.6
    },
    "taux_emploi": 63.7
  },
  "95500": {
    "codgeo": "95500",
    "nom": "Pontoise",
    "taux_chomage": 5.0,
    "pop_active": 13660,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 15.3,
      "Prof. intermédiaires": 17.3,
      "Employés": 18.0,
      "Ouvriers": 10.2,
      "Retraités": 16.8,
      "Autres inactifs": 20.2
    },
    "taux_emploi": 59.8
  },
  "86066": {
    "codgeo": "86066",
    "nom": "Châtellerault",
    "taux_chomage": 12.7,
    "pop_active": 14240,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.4,
      "Cadres": 5.6,
      "Prof. intermédiaires": 11.0,
      "Employés": 14.0,
      "Ouvriers": 14.0,
      "Retraités": 35.1,
      "Autres inactifs": 17.7
    },
    "taux_emploi": 53.7
  },
  "69286": {
    "codgeo": "69286",
    "nom": "Rillieux-la-Pape",
    "taux_chomage": 10.6,
    "pop_active": 13209,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.5,
      "Cadres": 7.5,
      "Prof. intermédiaires": 12.4,
      "Employés": 16.7,
      "Ouvriers": 14.0,
      "Retraités": 22.6,
      "Autres inactifs": 23.2
    },
    "taux_emploi": 53.5
  },
  "94073": {
    "codgeo": "94073",
    "nom": "Thiais",
    "taux_chomage": 5.2,
    "pop_active": 14071,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 14.6,
      "Prof. intermédiaires": 18.6,
      "Employés": 18.1,
      "Ouvriers": 9.5,
      "Retraités": 19.0,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 58.9
  },
  "38544": {
    "codgeo": "38544",
    "nom": "Vienne",
    "taux_chomage": 9.6,
    "pop_active": 14127,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 10.1,
      "Prof. intermédiaires": 16.4,
      "Employés": 14.2,
      "Ouvriers": 12.9,
      "Retraités": 24.5,
      "Autres inactifs": 18.4
    },
    "taux_emploi": 50.9
  },
  "91657": {
    "codgeo": "91657",
    "nom": "Vigneux-sur-Seine",
    "taux_chomage": 6.4,
    "pop_active": 13148,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 9.0,
      "Prof. intermédiaires": 16.5,
      "Employés": 21.0,
      "Ouvriers": 12.7,
      "Retraités": 18.0,
      "Autres inactifs": 19.9
    },
    "taux_emploi": 56.8
  },
  "91687": {
    "codgeo": "91687",
    "nom": "Viry-Châtillon",
    "taux_chomage": 9.0,
    "pop_active": 13119,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 9.7,
      "Prof. intermédiaires": 16.0,
      "Employés": 21.3,
      "Ouvriers": 12.7,
      "Retraités": 19.6,
      "Autres inactifs": 18.3
    },
    "taux_emploi": 52.0
  },
  "06123": {
    "codgeo": "06123",
    "nom": "Saint-Laurent-du-Var",
    "taux_chomage": 10.7,
    "pop_active": 14726,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.6,
      "Cadres": 9.9,
      "Prof. intermédiaires": 16.9,
      "Employés": 18.1,
      "Ouvriers": 8.6,
      "Retraités": 28.5,
      "Autres inactifs": 13.2
    },
    "taux_emploi": 54.9
  },
  "78158": {
    "codgeo": "78158",
    "nom": "Le Chesnay-Rocquencourt",
    "taux_chomage": 5.0,
    "pop_active": 14511,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 24.2,
      "Prof. intermédiaires": 14.2,
      "Employés": 10.5,
      "Ouvriers": 3.3,
      "Retraités": 28.8,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 75
  },
  "97103": {
    "codgeo": "97103",
    "nom": "Baie-Mahault",
    "taux_chomage": 12.2,
    "pop_active": 13997,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 4.9,
      "Cadres": 9.2,
      "Prof. intermédiaires": 17.0,
      "Employés": 20.5,
      "Ouvriers": 8.5,
      "Retraités": 17.6,
      "Autres inactifs": 22.1
    },
    "taux_emploi": 51.4
  },
  "28134": {
    "codgeo": "28134",
    "nom": "Dreux",
    "taux_chomage": 14.2,
    "pop_active": 13119,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.5,
      "Cadres": 5.6,
      "Prof. intermédiaires": 10.7,
      "Employés": 15.9,
      "Ouvriers": 16.1,
      "Retraités": 23.6,
      "Autres inactifs": 25.5
    },
    "taux_emploi": 48.7
  },
  "33039": {
    "codgeo": "33039",
    "nom": "Bègles",
    "taux_chomage": 5.9,
    "pop_active": 14121,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 14.0,
      "Prof. intermédiaires": 19.1,
      "Employés": 17.3,
      "Ouvriers": 9.2,
      "Retraités": 21.0,
      "Autres inactifs": 15.7
    },
    "taux_emploi": 57.9
  },
  "84031": {
    "codgeo": "84031",
    "nom": "Carpentras",
    "taux_chomage": 8.4,
    "pop_active": 13682,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 4.2,
      "Cadres": 4.6,
      "Prof. intermédiaires": 11.8,
      "Employés": 14.6,
      "Ouvriers": 15.2,
      "Retraités": 30.1,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 53.2
  },
  "95280": {
    "codgeo": "95280",
    "nom": "Goussainville",
    "taux_chomage": 9.5,
    "pop_active": 12879,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.0,
      "Cadres": 3.8,
      "Prof. intermédiaires": 11.4,
      "Employés": 19.6,
      "Ouvriers": 18.5,
      "Retraités": 15.9,
      "Autres inactifs": 27.8
    },
    "taux_emploi": 48.2
  },
  "40192": {
    "codgeo": "40192",
    "nom": "Mont-de-Marsan",
    "taux_chomage": 12.6,
    "pop_active": 14576,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.0,
      "Cadres": 6.6,
      "Prof. intermédiaires": 14.2,
      "Employés": 17.9,
      "Ouvriers": 10.7,
      "Retraités": 28.5,
      "Autres inactifs": 18.9
    },
    "taux_emploi": 49.4
  },
  "94079": {
    "codgeo": "94079",
    "nom": "Villiers-sur-Marne",
    "taux_chomage": 5.7,
    "pop_active": 13723,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 16.2,
      "Prof. intermédiaires": 16.1,
      "Employés": 18.3,
      "Ouvriers": 9.0,
      "Retraités": 19.2,
      "Autres inactifs": 18.4
    },
    "taux_emploi": 60.2
  },
  "94016": {
    "codgeo": "94016",
    "nom": "Cachan",
    "taux_chomage": 5.0,
    "pop_active": 13802,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 21.9,
      "Prof. intermédiaires": 14.4,
      "Employés": 14.0,
      "Ouvriers": 5.3,
      "Retraités": 17.1,
      "Autres inactifs": 24.9
    },
    "taux_emploi": 67.1
  },
  "77445": {
    "codgeo": "77445",
    "nom": "Savigny-le-Temple",
    "taux_chomage": 8.5,
    "pop_active": 12764,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 7.9,
      "Prof. intermédiaires": 18.7,
      "Employés": 22.3,
      "Ouvriers": 13.2,
      "Retraités": 14.6,
      "Autres inactifs": 21.3
    },
    "taux_emploi": 51.1
  },
  "06083": {
    "codgeo": "06083",
    "nom": "Menton",
    "taux_chomage": 11.7,
    "pop_active": 14146,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.2,
      "Cadres": 5.9,
      "Prof. intermédiaires": 12.7,
      "Employés": 21.5,
      "Ouvriers": 9.8,
      "Retraités": 31.5,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 46.9
  },
  "93077": {
    "codgeo": "93077",
    "nom": "Villemomble",
    "taux_chomage": 6.8,
    "pop_active": 13336,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 15.0,
      "Prof. intermédiaires": 17.5,
      "Employés": 16.5,
      "Ouvriers": 9.9,
      "Retraités": 18.2,
      "Autres inactifs": 19.2
    },
    "taux_emploi": 60.7
  },
  "92046": {
    "codgeo": "92046",
    "nom": "Malakoff",
    "taux_chomage": 5.0,
    "pop_active": 14113,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 22.0,
      "Prof. intermédiaires": 16.8,
      "Employés": 16.5,
      "Ouvriers": 6.7,
      "Retraités": 18.4,
      "Autres inactifs": 16.8
    },
    "taux_emploi": 63.8
  },
  "62510": {
    "codgeo": "62510",
    "nom": "Liévin",
    "taux_chomage": 13.5,
    "pop_active": 13297,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.8,
      "Cadres": 2.9,
      "Prof. intermédiaires": 10.5,
      "Employés": 17.2,
      "Ouvriers": 17.1,
      "Retraités": 24.2,
      "Autres inactifs": 26.1
    },
    "taux_emploi": 45.4
  },
  "92035": {
    "codgeo": "92035",
    "nom": "La Garenne-Colombes",
    "taux_chomage": 5.0,
    "pop_active": 13660,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.0,
      "Cadres": 32.4,
      "Prof. intermédiaires": 17.1,
      "Employés": 11.9,
      "Ouvriers": 4.0,
      "Retraités": 17.1,
      "Autres inactifs": 13.4
    },
    "taux_emploi": 73.8
  },
  "91521": {
    "codgeo": "91521",
    "nom": "Ris-Orangis",
    "taux_chomage": 7.0,
    "pop_active": 12348,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 7.7,
      "Prof. intermédiaires": 15.8,
      "Employés": 19.4,
      "Ouvriers": 13.8,
      "Retraités": 18.0,
      "Autres inactifs": 22.3
    },
    "taux_emploi": 53.5
  },
  "92009": {
    "codgeo": "92009",
    "nom": "Bois-Colombes",
    "taux_chomage": 5.0,
    "pop_active": 13182,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 32.4,
      "Prof. intermédiaires": 17.5,
      "Employés": 11.3,
      "Ouvriers": 4.3,
      "Retraités": 14.9,
      "Autres inactifs": 16.0
    },
    "taux_emploi": 75
  },
  "93014": {
    "codgeo": "93014",
    "nom": "Clichy-sous-Bois",
    "taux_chomage": 13.9,
    "pop_active": 12080,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 3.0,
      "Prof. intermédiaires": 9.6,
      "Employés": 17.6,
      "Ouvriers": 16.1,
      "Retraités": 12.4,
      "Autres inactifs": 38.0
    },
    "taux_emploi": 53.0
  },
  "69275": {
    "codgeo": "69275",
    "nom": "Décines-Charpieu",
    "taux_chomage": 8.6,
    "pop_active": 13169,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 7.8,
      "Prof. intermédiaires": 16.1,
      "Employés": 17.3,
      "Ouvriers": 13.4,
      "Retraités": 23.8,
      "Autres inactifs": 18.2
    },
    "taux_emploi": 56.5
  },
  "92064": {
    "codgeo": "92064",
    "nom": "Saint-Cloud",
    "taux_chomage": 5.0,
    "pop_active": 13241,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.2,
      "Cadres": 36.7,
      "Prof. intermédiaires": 12.8,
      "Employés": 8.1,
      "Ouvriers": 1.6,
      "Retraités": 19.6,
      "Autres inactifs": 17.0
    },
    "taux_emploi": 75
  },
  "78146": {
    "codgeo": "78146",
    "nom": "Chatou",
    "taux_chomage": 5.0,
    "pop_active": 13470,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.2,
      "Cadres": 28.3,
      "Prof. intermédiaires": 15.2,
      "Employés": 12.2,
      "Ouvriers": 3.8,
      "Retraités": 21.6,
      "Autres inactifs": 15.7
    },
    "taux_emploi": 75
  },
  "38053": {
    "codgeo": "38053",
    "nom": "Bourgoin-Jallieu",
    "taux_chomage": 11.5,
    "pop_active": 13136,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 7.8,
      "Prof. intermédiaires": 15.1,
      "Employés": 17.1,
      "Ouvriers": 15.9,
      "Retraités": 23.2,
      "Autres inactifs": 17.8
    },
    "taux_emploi": 46.7
  },
  "54547": {
    "codgeo": "54547",
    "nom": "Vandœuvre-lès-Nancy",
    "taux_chomage": 10.2,
    "pop_active": 13937,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 8.9,
      "Prof. intermédiaires": 10.9,
      "Employés": 12.3,
      "Ouvriers": 8.2,
      "Retraités": 21.9,
      "Autres inactifs": 35.7
    },
    "taux_emploi": 55.4
  },
  "24322": {
    "codgeo": "24322",
    "nom": "Périgueux",
    "taux_chomage": 10.2,
    "pop_active": 14328,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.5,
      "Cadres": 7.3,
      "Prof. intermédiaires": 13.7,
      "Employés": 17.7,
      "Ouvriers": 10.6,
      "Retraités": 28.1,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 52.5
  },
  "94018": {
    "codgeo": "94018",
    "nom": "Charenton-le-Pont",
    "taux_chomage": 5.0,
    "pop_active": 13211,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 26.3,
      "Prof. intermédiaires": 18.2,
      "Employés": 12.4,
      "Ouvriers": 3.3,
      "Retraités": 19.8,
      "Autres inactifs": 16.2
    },
    "taux_emploi": 73.1
  },
  "31557": {
    "codgeo": "31557",
    "nom": "Tournefeuille",
    "taux_chomage": 5.0,
    "pop_active": 13237,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 23.9,
      "Prof. intermédiaires": 16.1,
      "Employés": 12.2,
      "Ouvriers": 7.4,
      "Retraités": 24.2,
      "Autres inactifs": 13.7
    },
    "taux_emploi": 70.7
  },
  "78297": {
    "codgeo": "78297",
    "nom": "Guyancourt",
    "taux_chomage": 5.0,
    "pop_active": 12482,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.8,
      "Cadres": 21.6,
      "Prof. intermédiaires": 19.0,
      "Employés": 17.1,
      "Ouvriers": 7.7,
      "Retraités": 15.6,
      "Autres inactifs": 17.1
    },
    "taux_emploi": 68.2
  },
  "92060": {
    "codgeo": "92060",
    "nom": "Le Plessis-Robinson",
    "taux_chomage": 5.0,
    "pop_active": 12852,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 25.9,
      "Prof. intermédiaires": 18.0,
      "Employés": 14.9,
      "Ouvriers": 4.1,
      "Retraités": 20.6,
      "Autres inactifs": 13.4
    },
    "taux_emploi": 71.6
  },
  "91201": {
    "codgeo": "91201",
    "nom": "Draveil",
    "taux_chomage": 7.1,
    "pop_active": 12761,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 13.3,
      "Prof. intermédiaires": 16.5,
      "Employés": 16.8,
      "Ouvriers": 7.0,
      "Retraités": 27.0,
      "Autres inactifs": 16.2
    },
    "taux_emploi": 54.9
  },
  "34003": {
    "codgeo": "34003",
    "nom": "Agde",
    "taux_chomage": 14.4,
    "pop_active": 13884,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 5.4,
      "Cadres": 3.9,
      "Prof. intermédiaires": 9.1,
      "Employés": 15.7,
      "Ouvriers": 7.1,
      "Retraités": 42.5,
      "Autres inactifs": 16.2
    },
    "taux_emploi": 50.2
  },
  "59392": {
    "codgeo": "59392",
    "nom": "Maubeuge",
    "taux_chomage": 11.4,
    "pop_active": 12812,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.8,
      "Cadres": 3.6,
      "Prof. intermédiaires": 9.8,
      "Employés": 14.4,
      "Ouvriers": 15.2,
      "Retraités": 24.5,
      "Autres inactifs": 30.7
    },
    "taux_emploi": 49.9
  },
  "95219": {
    "codgeo": "95219",
    "nom": "Ermont",
    "taux_chomage": 8.6,
    "pop_active": 12615,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 16.6,
      "Prof. intermédiaires": 17.5,
      "Employés": 17.0,
      "Ouvriers": 7.9,
      "Retraités": 22.2,
      "Autres inactifs": 16.5
    },
    "taux_emploi": 64.3
  },
  "76681": {
    "codgeo": "76681",
    "nom": "Sotteville-lès-Rouen",
    "taux_chomage": 11.6,
    "pop_active": 12789,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 7.7,
      "Prof. intermédiaires": 14.7,
      "Employés": 17.5,
      "Ouvriers": 11.5,
      "Retraités": 28.9,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 53.8
  },
  "84087": {
    "codgeo": "84087",
    "nom": "Orange",
    "taux_chomage": 10.6,
    "pop_active": 13006,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.6,
      "Cadres": 5.8,
      "Prof. intermédiaires": 11.5,
      "Employés": 17.1,
      "Ouvriers": 12.9,
      "Retraités": 28.1,
      "Autres inactifs": 20.7
    },
    "taux_emploi": 50.9
  },
  "95680": {
    "codgeo": "95680",
    "nom": "Villiers-le-Bel",
    "taux_chomage": 10.8,
    "pop_active": 11858,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 3.4,
      "Prof. intermédiaires": 12.2,
      "Employés": 21.7,
      "Ouvriers": 17.1,
      "Retraités": 14.5,
      "Autres inactifs": 28.1
    },
    "taux_emploi": 44.7
  },
  "94034": {
    "codgeo": "94034",
    "nom": "Fresnes",
    "taux_chomage": 5.0,
    "pop_active": 12626,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 13.2,
      "Prof. intermédiaires": 16.2,
      "Employés": 19.2,
      "Ouvriers": 6.9,
      "Retraités": 15.6,
      "Autres inactifs": 26.7
    },
    "taux_emploi": 63.6
  },
  "02722": {
    "codgeo": "02722",
    "nom": "Soissons",
    "taux_chomage": 14.3,
    "pop_active": 12773,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.3,
      "Cadres": 6.1,
      "Prof. intermédiaires": 10.6,
      "Employés": 14.5,
      "Ouvriers": 14.4,
      "Retraités": 29.5,
      "Autres inactifs": 22.4
    },
    "taux_emploi": 49.3
  },
  "91691": {
    "codgeo": "91691",
    "nom": "Yerres",
    "taux_chomage": 8.0,
    "pop_active": 12480,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 18.3,
      "Prof. intermédiaires": 18.8,
      "Employés": 14.7,
      "Ouvriers": 6.5,
      "Retraités": 25.3,
      "Autres inactifs": 13.7
    },
    "taux_emploi": 57.2
  },
  "76575": {
    "codgeo": "76575",
    "nom": "Saint-Étienne-du-Rouvray",
    "taux_chomage": 11.6,
    "pop_active": 12568,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 3.8,
      "Prof. intermédiaires": 11.6,
      "Employés": 15.4,
      "Ouvriers": 15.3,
      "Retraités": 24.9,
      "Autres inactifs": 27.0
    },
    "taux_emploi": 49.6
  },
  "76217": {
    "codgeo": "76217",
    "nom": "Dieppe",
    "taux_chomage": 14.0,
    "pop_active": 13429,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.2,
      "Cadres": 4.8,
      "Prof. intermédiaires": 9.0,
      "Employés": 15.1,
      "Ouvriers": 12.4,
      "Retraités": 37.7,
      "Autres inactifs": 18.8
    },
    "taux_emploi": 48.8
  },
  "44190": {
    "codgeo": "44190",
    "nom": "Saint-Sébastien-sur-Loire",
    "taux_chomage": 5.0,
    "pop_active": 12945,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 15.6,
      "Prof. intermédiaires": 18.4,
      "Employés": 14.2,
      "Ouvriers": 8.2,
      "Retraités": 27.8,
      "Autres inactifs": 12.8
    },
    "taux_emploi": 52.9
  },
  "06155": {
    "codgeo": "06155",
    "nom": "Vallauris",
    "taux_chomage": 8.6,
    "pop_active": 13099,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 5.1,
      "Cadres": 7.0,
      "Prof. intermédiaires": 10.5,
      "Employés": 16.8,
      "Ouvriers": 10.0,
      "Retraités": 34.5,
      "Autres inactifs": 16.0
    },
    "taux_emploi": 53.6
  },
  "92075": {
    "codgeo": "92075",
    "nom": "Vanves",
    "taux_chomage": 5.0,
    "pop_active": 12769,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 29.1,
      "Prof. intermédiaires": 15.9,
      "Employés": 11.8,
      "Ouvriers": 4.1,
      "Retraités": 19.9,
      "Autres inactifs": 16.3
    },
    "taux_emploi": 74.6
  },
  "94044": {
    "codgeo": "94044",
    "nom": "Limeil-Brévannes",
    "taux_chomage": 9.5,
    "pop_active": 11705,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.7,
      "Cadres": 9.8,
      "Prof. intermédiaires": 20.8,
      "Employés": 20.6,
      "Ouvriers": 10.4,
      "Retraités": 13.9,
      "Autres inactifs": 20.7
    },
    "taux_emploi": 55.9
  },
  "93047": {
    "codgeo": "93047",
    "nom": "Montfermeil",
    "taux_chomage": 6.6,
    "pop_active": 11557,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.5,
      "Cadres": 7.0,
      "Prof. intermédiaires": 14.8,
      "Employés": 17.6,
      "Ouvriers": 13.2,
      "Retraités": 18.2,
      "Autres inactifs": 24.6
    },
    "taux_emploi": 52.2
  },
  "44114": {
    "codgeo": "44114",
    "nom": "Orvault",
    "taux_chomage": 5.0,
    "pop_active": 12461,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.1,
      "Cadres": 17.3,
      "Prof. intermédiaires": 15.8,
      "Employés": 12.8,
      "Ouvriers": 6.6,
      "Retraités": 28.1,
      "Autres inactifs": 16.1
    },
    "taux_emploi": 63.8
  },
  "94071": {
    "codgeo": "94071",
    "nom": "Sucy-en-Brie",
    "taux_chomage": 5.0,
    "pop_active": 12249,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.0,
      "Cadres": 16.0,
      "Prof. intermédiaires": 17.0,
      "Employés": 14.5,
      "Ouvriers": 7.2,
      "Retraités": 24.5,
      "Autres inactifs": 16.9
    },
    "taux_emploi": 57.8
  },
  "97309": {
    "codgeo": "97309",
    "nom": "Remire-Montjoly",
    "taux_chomage": 5.0,
    "pop_active": 11790,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 4.2,
      "Cadres": 13.3,
      "Prof. intermédiaires": 19.3,
      "Employés": 16.1,
      "Ouvriers": 6.4,
      "Retraités": 10.6,
      "Autres inactifs": 30.0
    },
    "taux_emploi": 58.2
  },
  "91286": {
    "codgeo": "91286",
    "nom": "Grigny",
    "taux_chomage": 12.3,
    "pop_active": 11161,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 3.0,
      "Prof. intermédiaires": 9.4,
      "Employés": 18.7,
      "Ouvriers": 19.8,
      "Retraités": 12.2,
      "Autres inactifs": 34.7
    },
    "taux_emploi": 47.9
  },
  "97113": {
    "codgeo": "97113",
    "nom": "Le Gosier",
    "taux_chomage": 12.7,
    "pop_active": 12706,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 6.9,
      "Cadres": 8.7,
      "Prof. intermédiaires": 14.8,
      "Employés": 17.5,
      "Ouvriers": 7.8,
      "Retraités": 23.3,
      "Autres inactifs": 20.6
    },
    "taux_emploi": 53.7
  },
  "59328": {
    "codgeo": "59328",
    "nom": "Lambersart",
    "taux_chomage": 5.0,
    "pop_active": 12156,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 22.2,
      "Prof. intermédiaires": 16.6,
      "Employés": 11.8,
      "Ouvriers": 6.2,
      "Retraités": 23.8,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 65.6
  },
  "67218": {
    "codgeo": "67218",
    "nom": "Illkirch-Graffenstaden",
    "taux_chomage": 10.0,
    "pop_active": 12646,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 11.8,
      "Prof. intermédiaires": 15.3,
      "Employés": 17.3,
      "Ouvriers": 10.8,
      "Retraités": 25.9,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 58.3
  },
  "91103": {
    "codgeo": "91103",
    "nom": "Brétigny-sur-Orge",
    "taux_chomage": 6.6,
    "pop_active": 11677,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 14.8,
      "Prof. intermédiaires": 19.1,
      "Employés": 18.5,
      "Ouvriers": 11.5,
      "Retraités": 18.1,
      "Autres inactifs": 16.0
    },
    "taux_emploi": 58.7
  },
  "89387": {
    "codgeo": "89387",
    "nom": "Sens",
    "taux_chomage": 9.0,
    "pop_active": 11998,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.7,
      "Cadres": 6.3,
      "Prof. intermédiaires": 11.3,
      "Employés": 14.9,
      "Ouvriers": 15.9,
      "Retraités": 30.1,
      "Autres inactifs": 18.6
    },
    "taux_emploi": 48.5
  },
  "95607": {
    "codgeo": "95607",
    "nom": "Taverny",
    "taux_chomage": 8.9,
    "pop_active": 11889,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 12.8,
      "Prof. intermédiaires": 19.4,
      "Employés": 17.4,
      "Ouvriers": 9.0,
      "Retraités": 20.9,
      "Autres inactifs": 17.3
    },
    "taux_emploi": 61.9
  },
  "77514": {
    "codgeo": "77514",
    "nom": "Villeparisis",
    "taux_chomage": 11.4,
    "pop_active": 11570,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 7.5,
      "Prof. intermédiaires": 18.4,
      "Employés": 21.4,
      "Ouvriers": 13.8,
      "Retraités": 17.2,
      "Autres inactifs": 18.8
    },
    "taux_emploi": 51.1
  },
  "78517": {
    "codgeo": "78517",
    "nom": "Rambouillet",
    "taux_chomage": 5.0,
    "pop_active": 12355,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 19.5,
      "Prof. intermédiaires": 16.3,
      "Employés": 13.4,
      "Ouvriers": 6.5,
      "Retraités": 28.3,
      "Autres inactifs": 13.9
    },
    "taux_emploi": 62.1
  },
  "33119": {
    "codgeo": "33119",
    "nom": "Cenon",
    "taux_chomage": 14.5,
    "pop_active": 12230,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 7.3,
      "Prof. intermédiaires": 15.0,
      "Employés": 17.3,
      "Ouvriers": 12.7,
      "Retraités": 21.5,
      "Autres inactifs": 22.5
    },
    "taux_emploi": 57.1
  },
  "95582": {
    "codgeo": "95582",
    "nom": "Sannois",
    "taux_chomage": 5.0,
    "pop_active": 11657,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 14.1,
      "Prof. intermédiaires": 18.3,
      "Employés": 17.7,
      "Ouvriers": 9.6,
      "Retraités": 19.7,
      "Autres inactifs": 17.8
    },
    "taux_emploi": 52.7
  },
  "95176": {
    "codgeo": "95176",
    "nom": "Cormeilles-en-Parisis",
    "taux_chomage": 5.0,
    "pop_active": 11530,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.4,
      "Cadres": 20.1,
      "Prof. intermédiaires": 20.0,
      "Employés": 13.8,
      "Ouvriers": 7.0,
      "Retraités": 20.9,
      "Autres inactifs": 14.8
    },
    "taux_emploi": 65.5
  },
  "77058": {
    "codgeo": "77058",
    "nom": "Bussy-Saint-Georges",
    "taux_chomage": 5.0,
    "pop_active": 11595,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 22.8,
      "Prof. intermédiaires": 19.8,
      "Employés": 18.5,
      "Ouvriers": 6.3,
      "Retraités": 11.7,
      "Autres inactifs": 17.7
    },
    "taux_emploi": 68.1
  },
  "33529": {
    "codgeo": "33529",
    "nom": "La Teste-de-Buch",
    "taux_chomage": 11.7,
    "pop_active": 13121,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 5.0,
      "Cadres": 7.1,
      "Prof. intermédiaires": 12.3,
      "Employés": 16.4,
      "Ouvriers": 8.0,
      "Retraités": 38.7,
      "Autres inactifs": 12.2
    },
    "taux_emploi": 53.9
  },
  "91223": {
    "codgeo": "91223",
    "nom": "Étampes",
    "taux_chomage": 10.7,
    "pop_active": 11370,
    "categories_sociopro": {
      "Agriculteurs": 0.4,
      "Artisans/commerçants": 2.7,
      "Cadres": 7.1,
      "Prof. intermédiaires": 13.8,
      "Employés": 21.6,
      "Ouvriers": 15.9,
      "Retraités": 17.8,
      "Autres inactifs": 20.8
    },
    "taux_emploi": 51.2
  },
  "31069": {
    "codgeo": "31069",
    "nom": "Blagnac",
    "taux_chomage": 5.0,
    "pop_active": 11999,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 22.0,
      "Prof. intermédiaires": 18.1,
      "Employés": 14.3,
      "Ouvriers": 7.9,
      "Retraités": 20.5,
      "Autres inactifs": 14.5
    },
    "taux_emploi": 69.5
  },
  "13063": {
    "codgeo": "13063",
    "nom": "Miramas",
    "taux_chomage": 9.1,
    "pop_active": 11507,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 3.7,
      "Prof. intermédiaires": 13.0,
      "Employés": 15.8,
      "Ouvriers": 17.0,
      "Retraités": 25.4,
      "Autres inactifs": 22.1
    },
    "taux_emploi": 51.5
  },
  "24037": {
    "codgeo": "24037",
    "nom": "Bergerac",
    "taux_chomage": 10.1,
    "pop_active": 12736,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.1,
      "Cadres": 4.5,
      "Prof. intermédiaires": 11.1,
      "Employés": 14.9,
      "Ouvriers": 10.3,
      "Retraités": 41.2,
      "Autres inactifs": 14.8
    },
    "taux_emploi": 51.7
  },
  "49328": {
    "codgeo": "49328",
    "nom": "Saumur",
    "taux_chomage": 13.2,
    "pop_active": 12197,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.2,
      "Cadres": 6.8,
      "Prof. intermédiaires": 11.7,
      "Employés": 14.1,
      "Ouvriers": 12.2,
      "Retraités": 35.6,
      "Autres inactifs": 16.1
    },
    "taux_emploi": 52.3
  },
  "34145": {
    "codgeo": "34145",
    "nom": "Lunel",
    "taux_chomage": 12.9,
    "pop_active": 11942,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 4.1,
      "Cadres": 5.5,
      "Prof. intermédiaires": 12.6,
      "Employés": 15.9,
      "Ouvriers": 13.5,
      "Retraités": 27.3,
      "Autres inactifs": 20.7
    },
    "taux_emploi": 48.8
  },
  "78208": {
    "codgeo": "78208",
    "nom": "Élancourt",
    "taux_chomage": 5.9,
    "pop_active": 11499,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 17.1,
      "Prof. intermédiaires": 20.9,
      "Employés": 17.5,
      "Ouvriers": 8.4,
      "Retraités": 17.7,
      "Autres inactifs": 16.1
    },
    "taux_emploi": 59.9
  },
  "62427": {
    "codgeo": "62427",
    "nom": "Hénin-Beaumont",
    "taux_chomage": 11.4,
    "pop_active": 11549,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.3,
      "Cadres": 4.8,
      "Prof. intermédiaires": 13.6,
      "Employés": 18.0,
      "Ouvriers": 16.8,
      "Retraités": 22.3,
      "Autres inactifs": 22.1
    },
    "taux_emploi": 51.6
  },
  "44215": {
    "codgeo": "44215",
    "nom": "Vertou",
    "taux_chomage": 5.0,
    "pop_active": 11735,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.4,
      "Cadres": 17.4,
      "Prof. intermédiaires": 17.9,
      "Employés": 12.5,
      "Ouvriers": 7.9,
      "Retraités": 28.8,
      "Autres inactifs": 11.9
    },
    "taux_emploi": 64.3
  },
  "76322": {
    "codgeo": "76322",
    "nom": "Le Grand-Quevilly",
    "taux_chomage": 15.8,
    "pop_active": 12060,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.5,
      "Cadres": 3.4,
      "Prof. intermédiaires": 13.4,
      "Employés": 19.5,
      "Ouvriers": 14.4,
      "Retraités": 32.6,
      "Autres inactifs": 15.1
    },
    "taux_emploi": 50.6
  },
  "95277": {
    "codgeo": "95277",
    "nom": "Gonesse",
    "taux_chomage": 8.8,
    "pop_active": 11189,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 5.2,
      "Prof. intermédiaires": 14.5,
      "Employés": 21.0,
      "Ouvriers": 15.0,
      "Retraités": 16.8,
      "Autres inactifs": 24.4
    },
    "taux_emploi": 48.4
  },
  "84035": {
    "codgeo": "84035",
    "nom": "Cavaillon",
    "taux_chomage": 9.4,
    "pop_active": 11566,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 4.3,
      "Cadres": 4.9,
      "Prof. intermédiaires": 10.4,
      "Employés": 13.7,
      "Ouvriers": 18.3,
      "Retraités": 27.6,
      "Autres inactifs": 20.2
    },
    "taux_emploi": 50.2
  },
  "83062": {
    "codgeo": "83062",
    "nom": "La Garde",
    "taux_chomage": 7.7,
    "pop_active": 12131,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.1,
      "Cadres": 7.5,
      "Prof. intermédiaires": 13.9,
      "Employés": 17.1,
      "Ouvriers": 7.5,
      "Retraités": 28.8,
      "Autres inactifs": 22.0
    },
    "taux_emploi": 49.4
  },
  "33192": {
    "codgeo": "33192",
    "nom": "Gradignan",
    "taux_chomage": 5.0,
    "pop_active": 12129,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 13.8,
      "Prof. intermédiaires": 13.9,
      "Employés": 13.7,
      "Ouvriers": 6.8,
      "Retraités": 27.9,
      "Autres inactifs": 21.3
    },
    "taux_emploi": 61.2
  },
  "15014": {
    "codgeo": "15014",
    "nom": "Aurillac",
    "taux_chomage": 13.7,
    "pop_active": 12564,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 2.6,
      "Cadres": 5.7,
      "Prof. intermédiaires": 13.0,
      "Employés": 15.6,
      "Ouvriers": 11.7,
      "Retraités": 33.9,
      "Autres inactifs": 17.3
    },
    "taux_emploi": 50.0
  },
  "49301": {
    "codgeo": "49301",
    "nom": "Sèvremoine",
    "taux_chomage": 8.7,
    "pop_active": 13223,
    "categories_sociopro": {
      "Agriculteurs": 1.8,
      "Artisans/commerçants": 3.8,
      "Cadres": 5.4,
      "Prof. intermédiaires": 16.4,
      "Employés": 15.0,
      "Ouvriers": 22.0,
      "Retraités": 26.2,
      "Autres inactifs": 9.3
    },
    "taux_emploi": 41.6
  },
  "03310": {
    "codgeo": "03310",
    "nom": "Vichy",
    "taux_chomage": 10.5,
    "pop_active": 12788,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.7,
      "Cadres": 4.8,
      "Prof. intermédiaires": 8.3,
      "Employés": 13.3,
      "Ouvriers": 9.0,
      "Retraités": 42.9,
      "Autres inactifs": 18.8
    },
    "taux_emploi": 50.8
  },
  "64122": {
    "codgeo": "64122",
    "nom": "Biarritz",
    "taux_chomage": 12.2,
    "pop_active": 12837,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 6.5,
      "Cadres": 10.5,
      "Prof. intermédiaires": 12.3,
      "Employés": 11.1,
      "Ouvriers": 5.2,
      "Retraités": 40.1,
      "Autres inactifs": 14.2
    },
    "taux_emploi": 55.5
  },
  "77083": {
    "codgeo": "77083",
    "nom": "Champs-sur-Marne",
    "taux_chomage": 5.0,
    "pop_active": 11003,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 14.2,
      "Prof. intermédiaires": 17.1,
      "Employés": 18.9,
      "Ouvriers": 8.6,
      "Retraités": 17.0,
      "Autres inactifs": 21.3
    },
    "taux_emploi": 56.9
  },
  "59017": {
    "codgeo": "59017",
    "nom": "Armentières",
    "taux_chomage": 11.7,
    "pop_active": 11428,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.6,
      "Cadres": 5.5,
      "Prof. intermédiaires": 13.7,
      "Employés": 19.4,
      "Ouvriers": 16.3,
      "Retraités": 22.1,
      "Autres inactifs": 21.4
    },
    "taux_emploi": 50.2
  },
  "25388": {
    "codgeo": "25388",
    "nom": "Montbéliard",
    "taux_chomage": 11.5,
    "pop_active": 11004,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 7.4,
      "Prof. intermédiaires": 10.0,
      "Employés": 13.5,
      "Ouvriers": 15.9,
      "Retraités": 26.8,
      "Autres inactifs": 24.1
    },
    "taux_emploi": 50.9
  },
  "61001": {
    "codgeo": "61001",
    "nom": "Alençon",
    "taux_chomage": 9.6,
    "pop_active": 12043,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 5.8,
      "Prof. intermédiaires": 10.9,
      "Employés": 14.4,
      "Ouvriers": 12.4,
      "Retraités": 31.1,
      "Autres inactifs": 22.9
    },
    "taux_emploi": 50.6
  },
  "17415": {
    "codgeo": "17415",
    "nom": "Saintes",
    "taux_chomage": 9.4,
    "pop_active": 12400,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.6,
      "Cadres": 7.3,
      "Prof. intermédiaires": 13.3,
      "Employés": 14.1,
      "Ouvriers": 9.9,
      "Retraités": 36.1,
      "Autres inactifs": 15.5
    },
    "taux_emploi": 48.8
  },
  "91114": {
    "codgeo": "91114",
    "nom": "Brunoy",
    "taux_chomage": 7.1,
    "pop_active": 11249,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 18.0,
      "Prof. intermédiaires": 17.3,
      "Employés": 14.2,
      "Ouvriers": 6.9,
      "Retraités": 26.2,
      "Autres inactifs": 14.6
    },
    "taux_emploi": 60.6
  },
  "95203": {
    "codgeo": "95203",
    "nom": "Eaubonne",
    "taux_chomage": 5.0,
    "pop_active": 11078,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 19.9,
      "Prof. intermédiaires": 17.4,
      "Employés": 15.2,
      "Ouvriers": 6.1,
      "Retraités": 22.2,
      "Autres inactifs": 16.1
    },
    "taux_emploi": 62.6
  },
  "92078": {
    "codgeo": "92078",
    "nom": "Villeneuve-la-Garenne",
    "taux_chomage": 12.8,
    "pop_active": 10859,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 7.3,
      "Prof. intermédiaires": 13.9,
      "Employés": 20.2,
      "Ouvriers": 12.8,
      "Retraités": 15.4,
      "Autres inactifs": 27.4
    },
    "taux_emploi": 50.7
  },
  "18279": {
    "codgeo": "18279",
    "nom": "Vierzon",
    "taux_chomage": 15.3,
    "pop_active": 11798,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 2.6,
      "Cadres": 4.0,
      "Prof. intermédiaires": 8.3,
      "Employés": 14.9,
      "Ouvriers": 14.9,
      "Retraités": 35.7,
      "Autres inactifs": 19.3
    },
    "taux_emploi": 54.6
  },
  "91692": {
    "codgeo": "91692",
    "nom": "Les Ulis",
    "taux_chomage": 8.0,
    "pop_active": 10849,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.6,
      "Cadres": 11.9,
      "Prof. intermédiaires": 15.0,
      "Employés": 19.4,
      "Ouvriers": 11.4,
      "Retraités": 17.6,
      "Autres inactifs": 23.0
    },
    "taux_emploi": 57.0
  },
  "31395": {
    "codgeo": "31395",
    "nom": "Muret",
    "taux_chomage": 9.2,
    "pop_active": 11408,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.1,
      "Cadres": 7.7,
      "Prof. intermédiaires": 14.6,
      "Employés": 17.0,
      "Ouvriers": 11.6,
      "Retraités": 26.6,
      "Autres inactifs": 19.1
    },
    "taux_emploi": 54.9
  },
  "95572": {
    "codgeo": "95572",
    "nom": "Saint-Ouen-l'Aumône",
    "taux_chomage": 10.3,
    "pop_active": 10840,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 9.8,
      "Prof. intermédiaires": 19.7,
      "Employés": 20.0,
      "Ouvriers": 12.2,
      "Retraités": 15.4,
      "Autres inactifs": 20.1
    },
    "taux_emploi": 53.6
  },
  "62119": {
    "codgeo": "62119",
    "nom": "Béthune",
    "taux_chomage": 12.8,
    "pop_active": 11487,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 7.5,
      "Prof. intermédiaires": 13.4,
      "Employés": 15.6,
      "Ouvriers": 12.1,
      "Retraités": 23.9,
      "Autres inactifs": 25.0
    },
    "taux_emploi": 58.3
  },
  "34057": {
    "codgeo": "34057",
    "nom": "Castelnau-le-Lez",
    "taux_chomage": 5.0,
    "pop_active": 11790,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.1,
      "Cadres": 16.3,
      "Prof. intermédiaires": 17.8,
      "Employés": 15.8,
      "Ouvriers": 5.4,
      "Retraités": 23.6,
      "Autres inactifs": 17.0
    },
    "taux_emploi": 60.9
  },
  "92032": {
    "codgeo": "92032",
    "nom": "Fontenay-aux-Roses",
    "taux_chomage": 5.0,
    "pop_active": 10650,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 23.1,
      "Prof. intermédiaires": 15.7,
      "Employés": 15.3,
      "Ouvriers": 4.5,
      "Retraités": 20.8,
      "Autres inactifs": 18.3
    },
    "taux_emploi": 72.4
  },
  "97304": {
    "codgeo": "97304",
    "nom": "Kourou",
    "taux_chomage": 14.2,
    "pop_active": 9604,
    "categories_sociopro": {
      "Agriculteurs": 0.4,
      "Artisans/commerçants": 3.7,
      "Cadres": 7.3,
      "Prof. intermédiaires": 13.2,
      "Employés": 19.0,
      "Ouvriers": 11.6,
      "Retraités": 6.6,
      "Autres inactifs": 38.3
    },
    "taux_emploi": 53.9
  },
  "33243": {
    "codgeo": "33243",
    "nom": "Libourne",
    "taux_chomage": 9.2,
    "pop_active": 10975,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 3.6,
      "Cadres": 8.5,
      "Prof. intermédiaires": 13.3,
      "Employés": 14.8,
      "Ouvriers": 12.6,
      "Retraités": 29.6,
      "Autres inactifs": 17.1
    },
    "taux_emploi": 55.6
  },
  "27681": {
    "codgeo": "27681",
    "nom": "Vernon",
    "taux_chomage": 9.0,
    "pop_active": 10959,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.7,
      "Cadres": 11.2,
      "Prof. intermédiaires": 13.4,
      "Employés": 13.8,
      "Ouvriers": 11.7,
      "Retraités": 26.3,
      "Autres inactifs": 20.8
    },
    "taux_emploi": 58.6
  },
  "94054": {
    "codgeo": "94054",
    "nom": "Orly",
    "taux_chomage": 10.9,
    "pop_active": 10213,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 7.0,
      "Prof. intermédiaires": 14.6,
      "Employés": 21.8,
      "Ouvriers": 13.9,
      "Retraités": 17.9,
      "Autres inactifs": 22.1
    },
    "taux_emploi": 51.0
  },
  "94043": {
    "codgeo": "94043",
    "nom": "Le Kremlin-Bicêtre",
    "taux_chomage": 5.0,
    "pop_active": 11182,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 21.2,
      "Prof. intermédiaires": 16.9,
      "Employés": 17.8,
      "Ouvriers": 5.7,
      "Retraités": 16.6,
      "Autres inactifs": 19.3
    },
    "taux_emploi": 63.9
  },
  "33162": {
    "codgeo": "33162",
    "nom": "Eysines",
    "taux_chomage": 8.8,
    "pop_active": 10927,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.3,
      "Cadres": 12.7,
      "Prof. intermédiaires": 18.3,
      "Employés": 17.5,
      "Ouvriers": 10.6,
      "Retraités": 22.2,
      "Autres inactifs": 14.3
    },
    "taux_emploi": 58.8
  },
  "33069": {
    "codgeo": "33069",
    "nom": "Le Bouscat",
    "taux_chomage": 5.0,
    "pop_active": 11217,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 5.2,
      "Cadres": 18.2,
      "Prof. intermédiaires": 16.6,
      "Employés": 12.9,
      "Ouvriers": 5.5,
      "Retraités": 26.9,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 63.2
  },
  "97420": {
    "codgeo": "97420",
    "nom": "Sainte-Suzanne",
    "taux_chomage": 8.8,
    "pop_active": 10532,
    "categories_sociopro": {
      "Agriculteurs": 0.8,
      "Artisans/commerçants": 3.0,
      "Cadres": 4.3,
      "Prof. intermédiaires": 13.3,
      "Employés": 21.5,
      "Ouvriers": 13.8,
      "Retraités": 12.8,
      "Autres inactifs": 30.6
    },
    "taux_emploi": 54.9
  },
  "97128": {
    "codgeo": "97128",
    "nom": "Sainte-Anne",
    "taux_chomage": 14.7,
    "pop_active": 10985,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 5.4,
      "Cadres": 5.0,
      "Prof. intermédiaires": 13.4,
      "Employés": 16.7,
      "Ouvriers": 10.3,
      "Retraités": 24.1,
      "Autres inactifs": 24.6
    },
    "taux_emploi": 53.5
  },
  "97118": {
    "codgeo": "97118",
    "nom": "Petit-Bourg",
    "taux_chomage": 10.3,
    "pop_active": 10731,
    "categories_sociopro": {
      "Agriculteurs": 0.4,
      "Artisans/commerçants": 5.9,
      "Cadres": 10.9,
      "Prof. intermédiaires": 15.3,
      "Employés": 15.6,
      "Ouvriers": 8.2,
      "Retraités": 21.4,
      "Autres inactifs": 22.3
    },
    "taux_emploi": 51.6
  },
  "12202": {
    "codgeo": "12202",
    "nom": "Rodez",
    "taux_chomage": 7.4,
    "pop_active": 11503,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.3,
      "Cadres": 9.0,
      "Prof. intermédiaires": 14.9,
      "Employés": 14.9,
      "Ouvriers": 9.6,
      "Retraités": 30.4,
      "Autres inactifs": 17.8
    },
    "taux_emploi": 55.9
  },
  "93057": {
    "codgeo": "93057",
    "nom": "Les Pavillons-sous-Bois",
    "taux_chomage": 11.5,
    "pop_active": 10255,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.8,
      "Cadres": 9.5,
      "Prof. intermédiaires": 17.2,
      "Employés": 19.0,
      "Ouvriers": 13.3,
      "Retraités": 17.3,
      "Autres inactifs": 18.9
    },
    "taux_emploi": 57.1
  },
  "02408": {
    "codgeo": "02408",
    "nom": "Laon",
    "taux_chomage": 9.5,
    "pop_active": 10947,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.0,
      "Cadres": 4.8,
      "Prof. intermédiaires": 10.4,
      "Employés": 16.0,
      "Ouvriers": 14.9,
      "Retraités": 26.5,
      "Autres inactifs": 25.3
    },
    "taux_emploi": 53.8
  },
  "83144": {
    "codgeo": "83144",
    "nom": "La Valette-du-Var",
    "taux_chomage": 10.3,
    "pop_active": 11156,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.5,
      "Cadres": 6.9,
      "Prof. intermédiaires": 16.1,
      "Employés": 18.9,
      "Ouvriers": 8.0,
      "Retraités": 30.8,
      "Autres inactifs": 14.8
    },
    "taux_emploi": 56.1
  },
  "34108": {
    "codgeo": "34108",
    "nom": "Frontignan",
    "taux_chomage": 16.7,
    "pop_active": 10957,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 4.3,
      "Cadres": 5.7,
      "Prof. intermédiaires": 14.3,
      "Employés": 17.6,
      "Ouvriers": 11.5,
      "Retraités": 30.0,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 54.6
  },
  "91421": {
    "codgeo": "91421",
    "nom": "Montgeron",
    "taux_chomage": 8.3,
    "pop_active": 10228,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.7,
      "Cadres": 15.9,
      "Prof. intermédiaires": 15.3,
      "Employés": 15.5,
      "Ouvriers": 8.0,
      "Retraités": 24.5,
      "Autres inactifs": 18.2
    },
    "taux_emploi": 58.0
  },
  "39198": {
    "codgeo": "39198",
    "nom": "Dole",
    "taux_chomage": 13.7,
    "pop_active": 10984,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 7.6,
      "Prof. intermédiaires": 12.9,
      "Employés": 13.4,
      "Ouvriers": 11.8,
      "Retraités": 34.0,
      "Autres inactifs": 17.3
    },
    "taux_emploi": 48.8
  },
  "49023": {
    "codgeo": "49023",
    "nom": "Beaupréau-en-Mauges",
    "taux_chomage": 12.0,
    "pop_active": 12337,
    "categories_sociopro": {
      "Agriculteurs": 2.2,
      "Artisans/commerçants": 3.1,
      "Cadres": 4.7,
      "Prof. intermédiaires": 13.7,
      "Employés": 15.5,
      "Ouvriers": 21.7,
      "Retraités": 29.0,
      "Autres inactifs": 10.2
    },
    "taux_emploi": 54.0
  },
  "93045": {
    "codgeo": "93045",
    "nom": "Les Lilas",
    "taux_chomage": 5.0,
    "pop_active": 10627,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.1,
      "Cadres": 20.5,
      "Prof. intermédiaires": 17.4,
      "Employés": 14.5,
      "Ouvriers": 6.3,
      "Retraités": 19.6,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 65.5
  },
  "33249": {
    "codgeo": "33249",
    "nom": "Lormont",
    "taux_chomage": 11.1,
    "pop_active": 10430,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.9,
      "Cadres": 4.6,
      "Prof. intermédiaires": 13.3,
      "Employés": 19.9,
      "Ouvriers": 18.1,
      "Retraités": 20.1,
      "Autres inactifs": 20.2
    },
    "taux_emploi": 50.8
  },
  "17299": {
    "codgeo": "17299",
    "nom": "Rochefort",
    "taux_chomage": 15.0,
    "pop_active": 11073,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 6.6,
      "Prof. intermédiaires": 11.6,
      "Employés": 15.5,
      "Ouvriers": 11.8,
      "Retraités": 35.5,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 54.7
  },
  "78358": {
    "codgeo": "78358",
    "nom": "Maisons-Laffitte",
    "taux_chomage": 5.0,
    "pop_active": 10344,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 33.2,
      "Prof. intermédiaires": 14.5,
      "Employés": 8.3,
      "Ouvriers": 3.1,
      "Retraités": 23.6,
      "Autres inactifs": 13.5
    },
    "taux_emploi": 75
  },
  "52448": {
    "codgeo": "52448",
    "nom": "Saint-Dizier",
    "taux_chomage": 13.3,
    "pop_active": 10690,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 4.8,
      "Prof. intermédiaires": 10.6,
      "Employés": 17.4,
      "Ouvriers": 13.6,
      "Retraités": 28.7,
      "Autres inactifs": 22.8
    },
    "taux_emploi": 45.7
  },
  "77390": {
    "codgeo": "77390",
    "nom": "Roissy-en-Brie",
    "taux_chomage": 5.0,
    "pop_active": 10003,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 10.9,
      "Prof. intermédiaires": 17.4,
      "Employés": 19.2,
      "Ouvriers": 12.6,
      "Retraités": 19.1,
      "Autres inactifs": 17.8
    },
    "taux_emploi": 55.5
  },
  "44047": {
    "codgeo": "44047",
    "nom": "Couëron",
    "taux_chomage": 7.8,
    "pop_active": 10134,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.4,
      "Cadres": 12.6,
      "Prof. intermédiaires": 19.4,
      "Employés": 17.0,
      "Ouvriers": 12.2,
      "Retraités": 22.7,
      "Autres inactifs": 12.3
    },
    "taux_emploi": 54.5
  },
  "32013": {
    "codgeo": "32013",
    "nom": "Auch",
    "taux_chomage": 8.5,
    "pop_active": 11041,
    "categories_sociopro": {
      "Agriculteurs": 0.4,
      "Artisans/commerçants": 2.9,
      "Cadres": 7.0,
      "Prof. intermédiaires": 13.5,
      "Employés": 15.1,
      "Ouvriers": 10.2,
      "Retraités": 32.7,
      "Autres inactifs": 18.1
    },
    "taux_emploi": 53.3
  },
  "56098": {
    "codgeo": "56098",
    "nom": "Lanester",
    "taux_chomage": 10.7,
    "pop_active": 10407,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 5.0,
      "Prof. intermédiaires": 13.8,
      "Employés": 17.7,
      "Ouvriers": 13.9,
      "Retraités": 30.7,
      "Autres inactifs": 16.0
    },
    "taux_emploi": 51.4
  },
  "59360": {
    "codgeo": "59360",
    "nom": "Loos",
    "taux_chomage": 8.8,
    "pop_active": 10100,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.1,
      "Cadres": 10.1,
      "Prof. intermédiaires": 15.0,
      "Employés": 18.0,
      "Ouvriers": 13.1,
      "Retraités": 18.8,
      "Autres inactifs": 22.8
    },
    "taux_emploi": 59.6
  },
  "04112": {
    "codgeo": "04112",
    "nom": "Manosque",
    "taux_chomage": 7.3,
    "pop_active": 10472,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.5,
      "Cadres": 9.6,
      "Prof. intermédiaires": 12.4,
      "Employés": 14.6,
      "Ouvriers": 11.5,
      "Retraités": 30.1,
      "Autres inactifs": 18.0
    },
    "taux_emploi": 56.9
  },
  "38169": {
    "codgeo": "38169",
    "nom": "Fontaine",
    "taux_chomage": 9.9,
    "pop_active": 10399,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 10.2,
      "Prof. intermédiaires": 14.3,
      "Employés": 17.1,
      "Ouvriers": 13.4,
      "Retraités": 25.2,
      "Autres inactifs": 16.7
    },
    "taux_emploi": 56.6
  },
  "45232": {
    "codgeo": "45232",
    "nom": "Olivet",
    "taux_chomage": 6.4,
    "pop_active": 10399,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 14.4,
      "Prof. intermédiaires": 16.9,
      "Employés": 12.8,
      "Ouvriers": 7.4,
      "Retraités": 27.7,
      "Autres inactifs": 17.8
    },
    "taux_emploi": 58.2
  },
  "77152": {
    "codgeo": "77152",
    "nom": "Dammarie-les-Lys",
    "taux_chomage": 9.5,
    "pop_active": 9763,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.4,
      "Cadres": 9.6,
      "Prof. intermédiaires": 14.9,
      "Employés": 18.4,
      "Ouvriers": 13.4,
      "Retraités": 19.3,
      "Autres inactifs": 22.0
    },
    "taux_emploi": 57.3
  },
  "78640": {
    "codgeo": "78640",
    "nom": "Vélizy-Villacoublay",
    "taux_chomage": 5.0,
    "pop_active": 10412,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 24.4,
      "Prof. intermédiaires": 17.6,
      "Employés": 17.1,
      "Ouvriers": 5.5,
      "Retraités": 20.4,
      "Autres inactifs": 12.6
    },
    "taux_emploi": 64.8
  },
  "68297": {
    "codgeo": "68297",
    "nom": "Saint-Louis",
    "taux_chomage": 9.3,
    "pop_active": 10131,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.1,
      "Cadres": 8.8,
      "Prof. intermédiaires": 11.8,
      "Employés": 16.9,
      "Ouvriers": 18.7,
      "Retraités": 21.1,
      "Autres inactifs": 20.6
    },
    "taux_emploi": 58.0
  },
  "69244": {
    "codgeo": "69244",
    "nom": "Tassin-la-Demi-Lune",
    "taux_chomage": 5.0,
    "pop_active": 10145,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.5,
      "Cadres": 19.4,
      "Prof. intermédiaires": 17.5,
      "Employés": 13.4,
      "Ouvriers": 5.5,
      "Retraités": 23.9,
      "Autres inactifs": 15.7
    },
    "taux_emploi": 66.6
  },
  "97117": {
    "codgeo": "97117",
    "nom": "Le Moule",
    "taux_chomage": 13.9,
    "pop_active": 10607,
    "categories_sociopro": {
      "Agriculteurs": 1.6,
      "Artisans/commerçants": 6.0,
      "Cadres": 4.6,
      "Prof. intermédiaires": 12.0,
      "Employés": 17.0,
      "Ouvriers": 10.6,
      "Retraités": 24.4,
      "Autres inactifs": 23.7
    },
    "taux_emploi": 51.9
  },
  "92072": {
    "codgeo": "92072",
    "nom": "Sèvres",
    "taux_chomage": 5.0,
    "pop_active": 10293,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 31.7,
      "Prof. intermédiaires": 15.3,
      "Employés": 11.5,
      "Ouvriers": 2.6,
      "Retraités": 21.2,
      "Autres inactifs": 14.5
    },
    "taux_emploi": 75
  },
  "95424": {
    "codgeo": "95424",
    "nom": "Montigny-lès-Cormeilles",
    "taux_chomage": 5.9,
    "pop_active": 9130,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 9.0,
      "Prof. intermédiaires": 16.9,
      "Employés": 21.0,
      "Ouvriers": 12.6,
      "Retraités": 16.5,
      "Autres inactifs": 20.8
    },
    "taux_emploi": 50.3
  },
  "80001": {
    "codgeo": "80001",
    "nom": "Abbeville",
    "taux_chomage": 13.7,
    "pop_active": 10491,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.6,
      "Cadres": 4.6,
      "Prof. intermédiaires": 9.0,
      "Employés": 16.7,
      "Ouvriers": 14.6,
      "Retraités": 32.3,
      "Autres inactifs": 20.1
    },
    "taux_emploi": 49.7
  },
  "95197": {
    "codgeo": "95197",
    "nom": "Deuil-la-Barre",
    "taux_chomage": 5.0,
    "pop_active": 10036,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.3,
      "Cadres": 17.9,
      "Prof. intermédiaires": 18.4,
      "Employés": 16.0,
      "Ouvriers": 7.0,
      "Retraités": 20.1,
      "Autres inactifs": 17.2
    },
    "taux_emploi": 67.9
  },
  "85047": {
    "codgeo": "85047",
    "nom": "Challans",
    "taux_chomage": 7.0,
    "pop_active": 10690,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.6,
      "Cadres": 4.4,
      "Prof. intermédiaires": 11.4,
      "Employés": 14.5,
      "Ouvriers": 12.6,
      "Retraités": 41.9,
      "Autres inactifs": 11.1
    },
    "taux_emploi": 51.7
  },
  "59368": {
    "codgeo": "59368",
    "nom": "La Madeleine",
    "taux_chomage": 5.0,
    "pop_active": 10439,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 23.0,
      "Prof. intermédiaires": 17.1,
      "Employés": 13.0,
      "Ouvriers": 7.2,
      "Retraités": 22.2,
      "Autres inactifs": 14.9
    },
    "taux_emploi": 67.7
  },
  "77468": {
    "codgeo": "77468",
    "nom": "Torcy",
    "taux_chomage": 13.3,
    "pop_active": 9855,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 11.3,
      "Prof. intermédiaires": 18.0,
      "Employés": 21.3,
      "Ouvriers": 11.0,
      "Retraités": 16.7,
      "Autres inactifs": 19.3
    },
    "taux_emploi": 55.4
  },
  "33199": {
    "codgeo": "33199",
    "nom": "Gujan-Mestras",
    "taux_chomage": 6.1,
    "pop_active": 10682,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 5.4,
      "Cadres": 9.0,
      "Prof. intermédiaires": 12.8,
      "Employés": 15.5,
      "Ouvriers": 7.9,
      "Retraités": 36.3,
      "Autres inactifs": 12.5
    },
    "taux_emploi": 55.9
  },
  "91272": {
    "codgeo": "91272",
    "nom": "Gif-sur-Yvette",
    "taux_chomage": 5.0,
    "pop_active": 10093,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 29.0,
      "Prof. intermédiaires": 12.2,
      "Employés": 7.7,
      "Ouvriers": 2.9,
      "Retraités": 21.5,
      "Autres inactifs": 24.0
    },
    "taux_emploi": 69.7
  },
  "01283": {
    "codgeo": "01283",
    "nom": "Oyonnax",
    "taux_chomage": 12.6,
    "pop_active": 9521,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 4.2,
      "Prof. intermédiaires": 10.0,
      "Employés": 10.1,
      "Ouvriers": 25.5,
      "Retraités": 24.5,
      "Autres inactifs": 22.3
    },
    "taux_emploi": 47.7
  },
  "77305": {
    "codgeo": "77305",
    "nom": "Montereau-Fault-Yonne",
    "taux_chomage": 16.7,
    "pop_active": 9021,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 2.8,
      "Prof. intermédiaires": 9.6,
      "Employés": 17.8,
      "Ouvriers": 16.6,
      "Retraités": 18.3,
      "Autres inactifs": 32.0
    },
    "taux_emploi": 43.7
  },
  "77122": {
    "codgeo": "77122",
    "nom": "Combs-la-Ville",
    "taux_chomage": 8.5,
    "pop_active": 9878,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 10.8,
      "Prof. intermédiaires": 17.4,
      "Employés": 19.1,
      "Ouvriers": 11.5,
      "Retraités": 23.5,
      "Autres inactifs": 15.6
    },
    "taux_emploi": 59.9
  },
  "14327": {
    "codgeo": "14327",
    "nom": "Hérouville-Saint-Clair",
    "taux_chomage": 9.9,
    "pop_active": 10293,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.3,
      "Cadres": 6.2,
      "Prof. intermédiaires": 12.7,
      "Employés": 17.7,
      "Ouvriers": 12.8,
      "Retraités": 24.3,
      "Autres inactifs": 24.0
    },
    "taux_emploi": 51.0
  },
  "13071": {
    "codgeo": "13071",
    "nom": "Les Pennes-Mirabeau",
    "taux_chomage": 12.1,
    "pop_active": 10289,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.6,
      "Cadres": 10.8,
      "Prof. intermédiaires": 16.6,
      "Employés": 15.8,
      "Ouvriers": 8.0,
      "Retraités": 28.6,
      "Autres inactifs": 15.5
    },
    "taux_emploi": 55.2
  },
  "51230": {
    "codgeo": "51230",
    "nom": "Épernay",
    "taux_chomage": 8.4,
    "pop_active": 10260,
    "categories_sociopro": {
      "Agriculteurs": 0.8,
      "Artisans/commerçants": 3.0,
      "Cadres": 5.8,
      "Prof. intermédiaires": 13.1,
      "Employés": 14.8,
      "Ouvriers": 18.0,
      "Retraités": 29.1,
      "Autres inactifs": 15.4
    },
    "taux_emploi": 44.6
  },
  "95428": {
    "codgeo": "95428",
    "nom": "Montmorency",
    "taux_chomage": 5.0,
    "pop_active": 9768,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.3,
      "Cadres": 19.5,
      "Prof. intermédiaires": 15.3,
      "Employés": 14.1,
      "Ouvriers": 6.6,
      "Retraités": 23.5,
      "Autres inactifs": 16.6
    },
    "taux_emploi": 63.2
  },
  "69202": {
    "codgeo": "69202",
    "nom": "Sainte-Foy-lès-Lyon",
    "taux_chomage": 5.0,
    "pop_active": 9989,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 4.1,
      "Cadres": 17.5,
      "Prof. intermédiaires": 14.0,
      "Employés": 11.8,
      "Ouvriers": 5.2,
      "Retraités": 33.2,
      "Autres inactifs": 14.1
    },
    "taux_emploi": 62.0
  },
  "57480": {
    "codgeo": "57480",
    "nom": "Montigny-lès-Metz",
    "taux_chomage": 10.9,
    "pop_active": 10074,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.0,
      "Cadres": 10.2,
      "Prof. intermédiaires": 14.7,
      "Employés": 17.6,
      "Ouvriers": 11.8,
      "Retraités": 27.8,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 54.9
  },
  "62178": {
    "codgeo": "62178",
    "nom": "Bruay-la-Buissière",
    "taux_chomage": 13.8,
    "pop_active": 9693,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 1.4,
      "Cadres": 2.8,
      "Prof. intermédiaires": 9.5,
      "Employés": 18.6,
      "Ouvriers": 18.1,
      "Retraités": 24.6,
      "Autres inactifs": 25.0
    },
    "taux_emploi": 51.3
  },
  "76498": {
    "codgeo": "76498",
    "nom": "Le Petit-Quevilly",
    "taux_chomage": 12.3,
    "pop_active": 9615,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.2,
      "Cadres": 6.8,
      "Prof. intermédiaires": 15.3,
      "Employés": 18.5,
      "Ouvriers": 14.5,
      "Retraités": 22.1,
      "Autres inactifs": 20.4
    },
    "taux_emploi": 50.6
  },
  "12145": {
    "codgeo": "12145",
    "nom": "Millau",
    "taux_chomage": 12.4,
    "pop_active": 10186,
    "categories_sociopro": {
      "Agriculteurs": 0.7,
      "Artisans/commerçants": 4.6,
      "Cadres": 5.5,
      "Prof. intermédiaires": 12.9,
      "Employés": 17.6,
      "Ouvriers": 10.9,
      "Retraités": 33.9,
      "Autres inactifs": 14.0
    },
    "taux_emploi": 50.6
  },
  "45284": {
    "codgeo": "45284",
    "nom": "Saint-Jean-de-Braye",
    "taux_chomage": 11.7,
    "pop_active": 9396,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 9.3,
      "Prof. intermédiaires": 16.8,
      "Employés": 16.4,
      "Ouvriers": 14.6,
      "Retraités": 23.1,
      "Autres inactifs": 17.2
    },
    "taux_emploi": 57.6
  },
  "52121": {
    "codgeo": "52121",
    "nom": "Chaumont",
    "taux_chomage": 12.4,
    "pop_active": 10338,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.3,
      "Cadres": 7.0,
      "Prof. intermédiaires": 13.2,
      "Employés": 19.6,
      "Ouvriers": 11.9,
      "Retraités": 30.6,
      "Autres inactifs": 15.4
    },
    "taux_emploi": 53.2
  },
  "47323": {
    "codgeo": "47323",
    "nom": "Villeneuve-sur-Lot",
    "taux_chomage": 12.2,
    "pop_active": 10279,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.0,
      "Cadres": 4.2,
      "Prof. intermédiaires": 10.3,
      "Employés": 14.6,
      "Ouvriers": 12.9,
      "Retraités": 36.8,
      "Autres inactifs": 17.9
    },
    "taux_emploi": 51.0
  },
  "06079": {
    "codgeo": "06079",
    "nom": "Mandelieu-la-Napoule",
    "taux_chomage": 11.5,
    "pop_active": 10050,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 6.0,
      "Cadres": 8.1,
      "Prof. intermédiaires": 12.4,
      "Employés": 16.5,
      "Ouvriers": 7.1,
      "Retraités": 38.2,
      "Autres inactifs": 11.5
    },
    "taux_emploi": 52.2
  },
  "94003": {
    "codgeo": "94003",
    "nom": "Arcueil",
    "taux_chomage": 5.0,
    "pop_active": 9766,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.5,
      "Cadres": 21.0,
      "Prof. intermédiaires": 16.1,
      "Employés": 16.8,
      "Ouvriers": 7.3,
      "Retraités": 16.4,
      "Autres inactifs": 19.9
    },
    "taux_emploi": 65.0
  },
  "59295": {
    "codgeo": "59295",
    "nom": "Hazebrouck",
    "taux_chomage": 12.0,
    "pop_active": 9702,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 2.7,
      "Cadres": 5.1,
      "Prof. intermédiaires": 13.1,
      "Employés": 17.0,
      "Ouvriers": 15.2,
      "Retraités": 30.5,
      "Autres inactifs": 16.1
    },
    "taux_emploi": 46.9
  },
  "13002": {
    "codgeo": "13002",
    "nom": "Allauch",
    "taux_chomage": 5.2,
    "pop_active": 9761,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 5.2,
      "Cadres": 12.3,
      "Prof. intermédiaires": 16.9,
      "Employés": 14.2,
      "Ouvriers": 6.1,
      "Retraités": 31.7,
      "Autres inactifs": 13.6
    },
    "taux_emploi": 58.3
  },
  "59410": {
    "codgeo": "59410",
    "nom": "Mons-en-Barœul",
    "taux_chomage": 5.9,
    "pop_active": 9425,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 13.4,
      "Prof. intermédiaires": 13.4,
      "Employés": 16.0,
      "Ouvriers": 11.6,
      "Retraités": 20.7,
      "Autres inactifs": 22.5
    },
    "taux_emploi": 58.6
  },
  "45147": {
    "codgeo": "45147",
    "nom": "Fleury-les-Aubrais",
    "taux_chomage": 10.8,
    "pop_active": 9350,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.1,
      "Cadres": 9.4,
      "Prof. intermédiaires": 14.0,
      "Employés": 17.7,
      "Ouvriers": 14.3,
      "Retraités": 26.4,
      "Autres inactifs": 16.1
    },
    "taux_emploi": 55.5
  },
  "91570": {
    "codgeo": "91570",
    "nom": "Saint-Michel-sur-Orge",
    "taux_chomage": 8.1,
    "pop_active": 9309,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 11.4,
      "Prof. intermédiaires": 17.5,
      "Employés": 19.3,
      "Ouvriers": 11.3,
      "Retraités": 21.5,
      "Autres inactifs": 16.5
    },
    "taux_emploi": 53.2
  },
  "93049": {
    "codgeo": "93049",
    "nom": "Neuilly-Plaisance",
    "taux_chomage": 5.6,
    "pop_active": 9547,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.9,
      "Cadres": 17.5,
      "Prof. intermédiaires": 18.7,
      "Employés": 15.7,
      "Ouvriers": 8.1,
      "Retraités": 20.1,
      "Autres inactifs": 16.0
    },
    "taux_emploi": 58.8
  },
  "49092": {
    "codgeo": "49092",
    "nom": "Chemillé-en-Anjou",
    "taux_chomage": 13.1,
    "pop_active": 11003,
    "categories_sociopro": {
      "Agriculteurs": 3.0,
      "Artisans/commerçants": 3.5,
      "Cadres": 4.5,
      "Prof. intermédiaires": 14.5,
      "Employés": 14.9,
      "Ouvriers": 20.9,
      "Retraités": 27.6,
      "Autres inactifs": 11.1
    },
    "taux_emploi": 50.4
  },
  "60463": {
    "codgeo": "60463",
    "nom": "Nogent-sur-Oise",
    "taux_chomage": 14.1,
    "pop_active": 8939,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.3,
      "Cadres": 5.0,
      "Prof. intermédiaires": 12.3,
      "Employés": 18.1,
      "Ouvriers": 15.7,
      "Retraités": 19.7,
      "Autres inactifs": 27.0
    },
    "taux_emploi": 46.7
  },
  "78362": {
    "codgeo": "78362",
    "nom": "Mantes-la-Ville",
    "taux_chomage": 10.3,
    "pop_active": 8967,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.9,
      "Cadres": 10.0,
      "Prof. intermédiaires": 15.5,
      "Employés": 18.7,
      "Ouvriers": 13.9,
      "Retraités": 20.5,
      "Autres inactifs": 19.5
    },
    "taux_emploi": 47.9
  },
  "78005": {
    "codgeo": "78005",
    "nom": "Achères",
    "taux_chomage": 9.6,
    "pop_active": 9275,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.9,
      "Cadres": 16.5,
      "Prof. intermédiaires": 18.2,
      "Employés": 19.8,
      "Ouvriers": 10.3,
      "Retraités": 16.7,
      "Autres inactifs": 16.6
    },
    "taux_emploi": 64.2
  },
  "40088": {
    "codgeo": "40088",
    "nom": "Dax",
    "taux_chomage": 13.8,
    "pop_active": 10436,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.7,
      "Cadres": 5.5,
      "Prof. intermédiaires": 11.6,
      "Employés": 15.3,
      "Ouvriers": 12.1,
      "Retraités": 36.8,
      "Autres inactifs": 14.9
    },
    "taux_emploi": 47.6
  },
  "97222": {
    "codgeo": "97222",
    "nom": "Le Robert",
    "taux_chomage": 11.3,
    "pop_active": 10019,
    "categories_sociopro": {
      "Agriculteurs": 0.4,
      "Artisans/commerçants": 4.3,
      "Cadres": 4.6,
      "Prof. intermédiaires": 12.7,
      "Employés": 20.0,
      "Ouvriers": 12.6,
      "Retraités": 25.1,
      "Autres inactifs": 20.3
    },
    "taux_emploi": 52.0
  },
  "94067": {
    "codgeo": "94067",
    "nom": "Saint-Mandé",
    "taux_chomage": 5.0,
    "pop_active": 9664,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 4.2,
      "Cadres": 32.1,
      "Prof. intermédiaires": 15.1,
      "Employés": 9.4,
      "Ouvriers": 2.2,
      "Retraités": 23.1,
      "Autres inactifs": 13.9
    },
    "taux_emploi": 75
  },
  "77243": {
    "codgeo": "77243",
    "nom": "Lagny-sur-Marne",
    "taux_chomage": 5.3,
    "pop_active": 9613,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 14.8,
      "Prof. intermédiaires": 17.6,
      "Employés": 17.8,
      "Ouvriers": 9.7,
      "Retraités": 23.4,
      "Autres inactifs": 13.8
    },
    "taux_emploi": 57.5
  },
  "13041": {
    "codgeo": "13041",
    "nom": "Gardanne",
    "taux_chomage": 13.1,
    "pop_active": 9399,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.9,
      "Cadres": 7.8,
      "Prof. intermédiaires": 17.6,
      "Employés": 17.3,
      "Ouvriers": 12.1,
      "Retraités": 24.9,
      "Autres inactifs": 17.2
    },
    "taux_emploi": 55.9
  },
  "57227": {
    "codgeo": "57227",
    "nom": "Forbach",
    "taux_chomage": 15.0,
    "pop_active": 9559,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 4.0,
      "Prof. intermédiaires": 9.1,
      "Employés": 14.6,
      "Ouvriers": 15.9,
      "Retraités": 25.2,
      "Autres inactifs": 28.8
    },
    "taux_emploi": 47.6
  },
  "94077": {
    "codgeo": "94077",
    "nom": "Villeneuve-le-Roi",
    "taux_chomage": 7.7,
    "pop_active": 9258,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 9.8,
      "Prof. intermédiaires": 15.5,
      "Employés": 18.4,
      "Ouvriers": 14.3,
      "Retraités": 20.1,
      "Autres inactifs": 18.7
    },
    "taux_emploi": 58.7
  },
  "78545": {
    "codgeo": "78545",
    "nom": "Saint-Cyr-l'École",
    "taux_chomage": 5.0,
    "pop_active": 9013,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.6,
      "Cadres": 26.4,
      "Prof. intermédiaires": 17.1,
      "Employés": 16.7,
      "Ouvriers": 6.6,
      "Retraités": 15.8,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 70.9
  },
  "69204": {
    "codgeo": "69204",
    "nom": "Saint-Genis-Laval",
    "taux_chomage": 10.2,
    "pop_active": 9443,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 13.8,
      "Prof. intermédiaires": 15.5,
      "Employés": 12.4,
      "Ouvriers": 8.5,
      "Retraités": 29.2,
      "Autres inactifs": 16.7
    },
    "taux_emploi": 52.2
  },
  "38563": {
    "codgeo": "38563",
    "nom": "Voiron",
    "taux_chomage": 7.5,
    "pop_active": 9616,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.2,
      "Cadres": 11.6,
      "Prof. intermédiaires": 15.8,
      "Employés": 14.1,
      "Ouvriers": 11.1,
      "Retraités": 29.7,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 57.9
  },
  "95555": {
    "codgeo": "95555",
    "nom": "Saint-Gratien",
    "taux_chomage": 5.8,
    "pop_active": 9058,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 16.2,
      "Prof. intermédiaires": 15.5,
      "Employés": 16.6,
      "Ouvriers": 8.3,
      "Retraités": 22.9,
      "Autres inactifs": 17.2
    },
    "taux_emploi": 59.4
  },
  "59646": {
    "codgeo": "59646",
    "nom": "Wasquehal",
    "taux_chomage": 5.0,
    "pop_active": 9399,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 18.7,
      "Prof. intermédiaires": 16.7,
      "Employés": 14.8,
      "Ouvriers": 7.7,
      "Retraités": 24.3,
      "Autres inactifs": 14.5
    },
    "taux_emploi": 64.8
  },
  "59279": {
    "codgeo": "59279",
    "nom": "Halluin",
    "taux_chomage": 12.9,
    "pop_active": 9089,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 2.5,
      "Cadres": 7.0,
      "Prof. intermédiaires": 14.2,
      "Employés": 18.2,
      "Ouvriers": 17.7,
      "Retraités": 22.9,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 51.8
  },
  "92014": {
    "codgeo": "92014",
    "nom": "Bourg-la-Reine",
    "taux_chomage": 5.0,
    "pop_active": 9501,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.0,
      "Cadres": 31.7,
      "Prof. intermédiaires": 12.9,
      "Employés": 10.2,
      "Ouvriers": 3.5,
      "Retraités": 22.3,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 75
  },
  "91434": {
    "codgeo": "91434",
    "nom": "Morsang-sur-Orge",
    "taux_chomage": 5.9,
    "pop_active": 9060,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.2,
      "Cadres": 11.6,
      "Prof. intermédiaires": 19.2,
      "Employés": 17.1,
      "Ouvriers": 10.6,
      "Retraités": 20.6,
      "Autres inactifs": 17.7
    },
    "taux_emploi": 55.7
  },
  "59163": {
    "codgeo": "59163",
    "nom": "Croix",
    "taux_chomage": 8.4,
    "pop_active": 9334,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.9,
      "Cadres": 16.4,
      "Prof. intermédiaires": 17.2,
      "Employés": 14.6,
      "Ouvriers": 8.3,
      "Retraités": 22.1,
      "Autres inactifs": 18.6
    },
    "taux_emploi": 63.6
  },
  "59155": {
    "codgeo": "59155",
    "nom": "Coudekerque-Branche",
    "taux_chomage": 14.0,
    "pop_active": 9393,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.6,
      "Cadres": 3.9,
      "Prof. intermédiaires": 15.2,
      "Employés": 18.7,
      "Ouvriers": 15.4,
      "Retraités": 27.6,
      "Autres inactifs": 17.5
    },
    "taux_emploi": 52.2
  },
  "71153": {
    "codgeo": "71153",
    "nom": "Le Creusot",
    "taux_chomage": 13.1,
    "pop_active": 9769,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.2,
      "Cadres": 5.1,
      "Prof. intermédiaires": 10.6,
      "Employés": 13.6,
      "Ouvriers": 12.7,
      "Retraités": 35.3,
      "Autres inactifs": 20.5
    },
    "taux_emploi": 53.6
  },
  "77350": {
    "codgeo": "77350",
    "nom": "Ozoir-la-Ferrière",
    "taux_chomage": 7.1,
    "pop_active": 9268,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 13.7,
      "Prof. intermédiaires": 17.6,
      "Employés": 15.9,
      "Ouvriers": 11.2,
      "Retraités": 22.5,
      "Autres inactifs": 15.6
    },
    "taux_emploi": 60.3
  },
  "69091": {
    "codgeo": "69091",
    "nom": "Givors",
    "taux_chomage": 14.5,
    "pop_active": 8675,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.0,
      "Cadres": 4.5,
      "Prof. intermédiaires": 12.8,
      "Employés": 17.3,
      "Ouvriers": 16.8,
      "Retraités": 23.7,
      "Autres inactifs": 21.8
    },
    "taux_emploi": 48.0
  },
  "35115": {
    "codgeo": "35115",
    "nom": "Fougères",
    "taux_chomage": 11.3,
    "pop_active": 9706,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.1,
      "Cadres": 5.6,
      "Prof. intermédiaires": 13.0,
      "Employés": 13.4,
      "Ouvriers": 16.3,
      "Retraités": 34.0,
      "Autres inactifs": 14.6
    },
    "taux_emploi": 47.9
  },
  "59172": {
    "codgeo": "59172",
    "nom": "Denain",
    "taux_chomage": 14.1,
    "pop_active": 8713,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.1,
      "Cadres": 1.9,
      "Prof. intermédiaires": 8.3,
      "Employés": 15.8,
      "Ouvriers": 19.6,
      "Retraités": 17.1,
      "Autres inactifs": 35.1
    },
    "taux_emploi": 37.8
  },
  "77294": {
    "codgeo": "77294",
    "nom": "Mitry-Mory",
    "taux_chomage": 7.2,
    "pop_active": 8743,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 8.9,
      "Prof. intermédiaires": 18.4,
      "Employés": 19.0,
      "Ouvriers": 14.0,
      "Retraités": 18.6,
      "Autres inactifs": 17.9
    },
    "taux_emploi": 51.8
  },
  "57631": {
    "codgeo": "57631",
    "nom": "Sarreguemines",
    "taux_chomage": 15.4,
    "pop_active": 9710,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.8,
      "Cadres": 6.3,
      "Prof. intermédiaires": 11.4,
      "Employés": 15.6,
      "Ouvriers": 14.6,
      "Retraités": 27.9,
      "Autres inactifs": 21.1
    },
    "taux_emploi": 53.9
  },
  "91345": {
    "codgeo": "91345",
    "nom": "Longjumeau",
    "taux_chomage": 7.8,
    "pop_active": 9060,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.1,
      "Cadres": 12.5,
      "Prof. intermédiaires": 17.4,
      "Employés": 18.9,
      "Ouvriers": 10.5,
      "Retraités": 22.1,
      "Autres inactifs": 16.6
    },
    "taux_emploi": 54.4
  },
  "29039": {
    "codgeo": "29039",
    "nom": "Concarneau",
    "taux_chomage": 12.3,
    "pop_active": 9972,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.6,
      "Cadres": 7.1,
      "Prof. intermédiaires": 12.2,
      "Employés": 13.5,
      "Ouvriers": 10.8,
      "Retraités": 40.1,
      "Autres inactifs": 12.5
    },
    "taux_emploi": 44.8
  },
  "85146": {
    "codgeo": "85146",
    "nom": "Montaigu-Vendée",
    "taux_chomage": 6.2,
    "pop_active": 10039,
    "categories_sociopro": {
      "Agriculteurs": 0.7,
      "Artisans/commerçants": 4.1,
      "Cadres": 8.5,
      "Prof. intermédiaires": 17.7,
      "Employés": 13.5,
      "Ouvriers": 19.0,
      "Retraités": 25.4,
      "Autres inactifs": 11.1
    },
    "taux_emploi": 52.8
  },
  "44026": {
    "codgeo": "44026",
    "nom": "Carquefou",
    "taux_chomage": 5.3,
    "pop_active": 9359,
    "categories_sociopro": {
      "Agriculteurs": 0.3,
      "Artisans/commerçants": 3.6,
      "Cadres": 18.1,
      "Prof. intermédiaires": 15.9,
      "Employés": 12.5,
      "Ouvriers": 7.2,
      "Retraités": 25.3,
      "Autres inactifs": 17.1
    },
    "taux_emploi": 64.1
  },
  "92071": {
    "codgeo": "92071",
    "nom": "Sceaux",
    "taux_chomage": 5.0,
    "pop_active": 9230,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.3,
      "Cadres": 29.1,
      "Prof. intermédiaires": 12.6,
      "Employés": 9.6,
      "Ouvriers": 2.6,
      "Retraités": 23.0,
      "Autres inactifs": 19.8
    },
    "taux_emploi": 75
  },
  "78126": {
    "codgeo": "78126",
    "nom": "La Celle-Saint-Cloud",
    "taux_chomage": 5.0,
    "pop_active": 9010,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.9,
      "Cadres": 22.0,
      "Prof. intermédiaires": 15.3,
      "Employés": 13.3,
      "Ouvriers": 5.5,
      "Retraités": 21.8,
      "Autres inactifs": 18.1
    },
    "taux_emploi": 66.8
  },
  "94042": {
    "codgeo": "94042",
    "nom": "Joinville-le-Pont",
    "taux_chomage": 5.0,
    "pop_active": 9075,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.4,
      "Cadres": 22.0,
      "Prof. intermédiaires": 16.7,
      "Employés": 14.9,
      "Ouvriers": 4.7,
      "Retraités": 21.0,
      "Autres inactifs": 17.4
    },
    "taux_emploi": 68.5
  },
  "44020": {
    "codgeo": "44020",
    "nom": "Bouguenais",
    "taux_chomage": 7.1,
    "pop_active": 9064,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.6,
      "Cadres": 11.2,
      "Prof. intermédiaires": 18.9,
      "Employés": 16.5,
      "Ouvriers": 10.8,
      "Retraités": 24.5,
      "Autres inactifs": 14.4
    },
    "taux_emploi": 51.0
  },
  "22113": {
    "codgeo": "22113",
    "nom": "Lannion",
    "taux_chomage": 7.9,
    "pop_active": 9657,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.1,
      "Cadres": 11.0,
      "Prof. intermédiaires": 11.9,
      "Employés": 13.0,
      "Ouvriers": 9.8,
      "Retraités": 32.3,
      "Autres inactifs": 18.7
    },
    "taux_emploi": 54.5
  },
  "31157": {
    "codgeo": "31157",
    "nom": "Cugnaux",
    "taux_chomage": 6.0,
    "pop_active": 8780,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.7,
      "Cadres": 14.5,
      "Prof. intermédiaires": 17.4,
      "Employés": 16.0,
      "Ouvriers": 10.4,
      "Retraités": 21.4,
      "Autres inactifs": 16.4
    },
    "taux_emploi": 61.9
  },
  "44035": {
    "codgeo": "44035",
    "nom": "La Chapelle-sur-Erdre",
    "taux_chomage": 5.0,
    "pop_active": 9068,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.0,
      "Cadres": 20.9,
      "Prof. intermédiaires": 17.0,
      "Employés": 12.5,
      "Ouvriers": 6.3,
      "Retraités": 26.8,
      "Autres inactifs": 13.3
    },
    "taux_emploi": 65.9
  },
  "59271": {
    "codgeo": "59271",
    "nom": "Grande-Synthe",
    "taux_chomage": 14.0,
    "pop_active": 8595,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 1.2,
      "Cadres": 1.6,
      "Prof. intermédiaires": 11.5,
      "Employés": 16.9,
      "Ouvriers": 17.9,
      "Retraités": 20.5,
      "Autres inactifs": 30.3
    },
    "taux_emploi": 48.8
  },
  "94021": {
    "codgeo": "94021",
    "nom": "Chevilly-Larue",
    "taux_chomage": 9.6,
    "pop_active": 8955,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.6,
      "Cadres": 11.0,
      "Prof. intermédiaires": 15.2,
      "Employés": 19.4,
      "Ouvriers": 12.1,
      "Retraités": 20.7,
      "Autres inactifs": 19.0
    },
    "taux_emploi": 59.4
  },
  "67267": {
    "codgeo": "67267",
    "nom": "Lingolsheim",
    "taux_chomage": 8.2,
    "pop_active": 9288,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.1,
      "Cadres": 9.9,
      "Prof. intermédiaires": 15.2,
      "Employés": 15.6,
      "Ouvriers": 13.0,
      "Retraités": 26.3,
      "Autres inactifs": 16.9
    },
    "taux_emploi": 55.3
  },
  "94059": {
    "codgeo": "94059",
    "nom": "Le Plessis-Trévise",
    "taux_chomage": 6.4,
    "pop_active": 8809,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 3.8,
      "Cadres": 13.3,
      "Prof. intermédiaires": 17.7,
      "Employés": 17.1,
      "Ouvriers": 9.7,
      "Retraités": 21.8,
      "Autres inactifs": 16.6
    },
    "taux_emploi": 57.4
  },
  "33075": {
    "codgeo": "33075",
    "nom": "Bruges",
    "taux_chomage": 5.0,
    "pop_active": 9083,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 3.9,
      "Cadres": 14.4,
      "Prof. intermédiaires": 22.8,
      "Employés": 17.8,
      "Ouvriers": 9.2,
      "Retraités": 18.3,
      "Autres inactifs": 13.6
    },
    "taux_emploi": 64.8
  },
  "77285": {
    "codgeo": "77285",
    "nom": "Le Mée-sur-Seine",
    "taux_chomage": 12.0,
    "pop_active": 8431,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.4,
      "Cadres": 5.2,
      "Prof. intermédiaires": 14.5,
      "Employés": 21.4,
      "Ouvriers": 13.4,
      "Retraités": 21.6,
      "Autres inactifs": 21.5
    },
    "taux_emploi": 49.3
  },
  "63124": {
    "codgeo": "63124",
    "nom": "Cournon-d'Auvergne",
    "taux_chomage": 11.3,
    "pop_active": 9233,
    "categories_sociopro": {
      "Agriculteurs": 0.1,
      "Artisans/commerçants": 2.5,
      "Cadres": 8.5,
      "Prof. intermédiaires": 15.2,
      "Employés": 15.1,
      "Ouvriers": 10.0,
      "Retraités": 34.5,
      "Autres inactifs": 14.1
    },
    "taux_emploi": 54.6
  },
  "46042": {
    "codgeo": "46042",
    "nom": "Cahors",
    "taux_chomage": 10.4,
    "pop_active": 9685,
    "categories_sociopro": {
      "Agriculteurs": 0.2,
      "Artisans/commerçants": 3.7,
      "Cadres": 7.1,
      "Prof. intermédiaires": 13.6,
      "Employés": 15.5,
      "Ouvriers": 10.0,
      "Retraités": 34.2,
      "Autres inactifs": 15.8
    },
    "taux_emploi": 49.7
  },
  "76451": {
    "codgeo": "76451",
    "nom": "Mont-Saint-Aignan",
    "taux_chomage": 5.0,
    "pop_active": 9573,
    "categories_sociopro": {
      "Agriculteurs": 0.0,
      "Artisans/commerçants": 2.8,
      "Cadres": 16.8,
      "Prof. intermédiaires": 13.0,
      "Employés": 10.4,
      "Ouvriers": 3.8,
      "Retraités": 26.9,
      "Autres inactifs": 26.2
    },
    "taux_emploi": 58.4
  },
  "21054": {
    "codgeo": "21054",
    "nom": "Beaune",
    "taux_chomage": 11.3,
    "pop_active": 9669,
    "categories_sociopro": {
      "Agriculteurs": 0.6,
      "Artisans/commerçants": 4.8,
      "Cadres": 7.5,
      "Prof. intermédiaires": 12.4,
      "Employés": 16.0,
      "Ouvriers": 15.1,
      "Retraités": 30.3,
      "Autres inactifs": 13.4
    },
    "taux_emploi": 51.4
  },
  "84089": {
    "codgeo": "84089",
    "nom": "Pertuis",
    "taux_chomage": 7.4,
    "pop_active": 9279,
    "categories_sociopro": {
      "Agriculteurs": 0.5,
      "Artisans/commerçants": 4.4,
      "Cadres": 11.5,
      "Prof. intermédiaires": 16.2,
      "Employés": 16.5,
      "Ouvriers": 9.6,
      "Retraités": 26.5,
      "Autres inactifs": 14.7
    },
    "taux_emploi": 54.2
  }
};
