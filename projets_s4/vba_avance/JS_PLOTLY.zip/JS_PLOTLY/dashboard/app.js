/**
 * @AI_SPACE
 * @purpose : Orchestrateur principal de l'application (Dashboard).
 * @logic : Gère l'état global, les dropdowns, la navigation par onglets et délègue le rendu aux modules spécialisés.
 * @decisions : centralisation du routage dans _renderActiveTab pour une maintenance simplifiée.
 * @references : https://developer.mozilla.org/fr/docs/Web/API/Document_Object_Model
 */
/* ============================================================
   app.js — Point d'entrée de l'application (v2)
   
   Nouveautés v2 :
     - Rendu KPI Cards avant chaque onglet
     - Routage vers les nouveaux modules JS séparés
     - Onglet 'tab-cars' → CarsChart.renderAccidents()
     - Carte enrichie → MapChart.renderMap() avec données emploi/culture
   
   Modules chargés (via <script> dans index.html) :
     DataService → dataService.js
     KPI         → js/kpi.js
     MapChart    → js/map.js
     GeneralChart→ js/general.js
     EmploiChart → js/emploi.js
     LogementChart→ js/logement.js
     WeatherChart → js/weather.js
     CultureChart → js/culture.js
     CarsChart   → js/cars.js
============================================================ */

'use strict';

/* ── Démarrage après parsing HTML ─────────────────────────── */
document.addEventListener('DOMContentLoaded', () => { App.init(); });

/* ── Objet Application ──────────────────────────────────────── */
const App = {

  /* ── État ─────────────────────────────────────────────────── */
  state: {
    villes:     [],
    codgeoA:    null,
    codgeoB:    null,
    activeTab:  'tab-map',
    dataLoaded: false,
  },

  /* Villes affichées par défaut */
  DEFAULT_CITY_A: '75056',   // Paris
  DEFAULT_CITY_B: '69123',   // Lyon

  /* ── init() ─────────────────────────────────────────────────── */
  async init() {
    this._showLoader(true);
    this._setStatus('loading', 'Chargement des données…');
    try {
      await DataService.loadAll();
      this.state.villes     = DataService.getVilles();
      this.state.dataLoaded = true;

      this._populateDropdowns();
      this._setCity('a', this.DEFAULT_CITY_A);
      this._setCity('b', this.DEFAULT_CITY_B);
      this._initTabs();
      
      // Le rendu peut maintenant se faire directement de manière synchrone car le DOM est prêt
      // et la résolution des Promesses est terminée.
      this._renderActiveTab();

      this._setStatus('ok', `${this.state.villes.length} villes chargées`);
    } catch (err) {
      this._showError(`Erreur critique : ${err.message}`);
      this._setStatus('error', 'Erreur de chargement');
      console.error('[App] Erreur fatale :', err);
    } finally {
      this._showLoader(false);
    }
  },

  /* ── DROPDOWNS ──────────────────────────────────────────────── */
  _populateDropdowns() {
    const selectA = document.getElementById('select-city-a');
    const selectB = document.getElementById('select-city-b');
    if (!selectA || !selectB) throw new Error('Éléments select introuvables.');

    // Tri alphabétique (localeCompare respecte les accents)
    const sorted = [...this.state.villes].sort((a, b) =>
      a.nom.localeCompare(b.nom, 'fr', { sensitivity: 'base' })
    );

    // DocumentFragment → 1 seul reflow DOM
    const fragA = document.createDocumentFragment();
    const fragB = document.createDocumentFragment();
    sorted.forEach(ville => {
      const opt = document.createElement('option');
      opt.value       = ville.codgeo;
      opt.textContent = `${ville.nom} (${ville.population.toLocaleString('fr-FR')} hab.)`;
      fragA.appendChild(opt);
      fragB.appendChild(opt.cloneNode(true));
    });

    selectA.appendChild(fragA);
    selectB.appendChild(fragB);

    selectA.addEventListener('change', (e) => this._onCityChange('a', e.target.value));
    selectB.addEventListener('change', (e) => this._onCityChange('b', e.target.value));
  },

  _setCity(side, codgeo) {
    this.state[`codgeo${side.toUpperCase()}`] = codgeo;
    const select = document.getElementById(`select-city-${side}`);
    if (select) select.value = codgeo;
    const ville = this.state.villes.find(v => v.codgeo === codgeo);
    const badge = document.getElementById(`badge-city-${side}`);
    if (badge && ville) badge.textContent = ville.nom;
  },

  _onCityChange(side, newCodgeo) {
    const otherKey    = side === 'a' ? 'codgeoB' : 'codgeoA';
    const otherCodgeo = this.state[otherKey];
    if (newCodgeo === otherCodgeo) {
      this._showError('Veuillez sélectionner deux villes différentes.');
      const select = document.getElementById(`select-city-${side}`);
      if (select) select.value = this.state[`codgeo${side.toUpperCase()}`];
      return;
    }
    this._hideError();
    this._setCity(side, newCodgeo);
    this._renderActiveTab();
  },

  /* ── ONGLETS ─────────────────────────────────────────────────── */
  _initTabs() {
    const nav = document.getElementById('tab-nav');
    if (!nav) return;
    /*
     * Délégation d'événement : un seul listener sur le parent.
     * event.target.closest('.tab-btn') remonte jusqu'au bouton
     * même si on clique sur l'emoji enfant.
     */
    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.tab-btn');
      if (!btn || btn.dataset.tab === this.state.activeTab) return;
      this._switchTab(btn.dataset.tab);
    });
  },

  _switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    const btn   = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
    const panel = document.getElementById(tabId);
    if (btn)   btn.classList.add('active');
    if (panel) panel.classList.add('active');
    this.state.activeTab = tabId;
    
    // Double requestAnimationFrame garantit que le navigateur a repeint l'UI
    // et que la div a une largeur/hauteur réelle (>0)
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        this._renderActiveTab();
        window.dispatchEvent(new Event('resize'));
      });
    });
  },

  /* ── RENDU ───────────────────────────────────────────────────── */
  /**
   * _renderActiveTab()
   * Routeur principal : délègue au module correspondant.
   * Avant chaque rendu, injecte les KPI Cards via KPI.render().
   */
  _renderActiveTab() {
    if (!this.state.dataLoaded || !this.state.codgeoA || !this.state.codgeoB) return;

    const { cityA, cityB } = DataService.getCities(this.state.codgeoA, this.state.codgeoB);

    switch (this.state.activeTab) {

      case 'tab-map':
        // Carte enrichie : passe les données emploi/culture pour la colorscale
        MapChart.renderMap(
          this.state.villes,
          this.state.codgeoA,
          this.state.codgeoB,
          DataService.getAllEmploi(),
          DataService.getAllCulture(),
          DataService.getAllLogement(),
          DataService.getAllMeteo(),
          DataService.getAllAccidents()
        );
        break;

      case 'tab-general':
        KPI.render('kpi-general', KPI.buildGeneralMetrics(cityA, cityB));
        GeneralChart.renderGeneral(cityA, cityB);
        break;

      case 'tab-emploi':
        KPI.render('kpi-emploi', KPI.buildEmploiMetrics(cityA, cityB));
        EmploiChart.renderEmploi(cityA, cityB);
        break;

      case 'tab-logement':
        KPI.render('kpi-logement', KPI.buildLogementMetrics(cityA, cityB));
        LogementChart.renderLogement(cityA, cityB);
        break;

      case 'tab-meteo':
        KPI.render('kpi-meteo', KPI.buildMeteoMetrics(cityA, cityB));
        WeatherChart.renderMeteo(cityA, cityB);
        break;

      case 'tab-culture':
        KPI.render('kpi-culture', KPI.buildCultureMetrics(cityA, cityB));
        CultureChart.renderCulture(cityA, cityB);
        break;

      case 'tab-cars':
        KPI.render('kpi-cars', KPI.buildCarsMetrics(
          cityA, cityB,
          DataService.getAccidents(this.state.codgeoA),
          DataService.getAccidents(this.state.codgeoB),
        ));
        CarsChart.renderAccidents(cityA, cityB, DataService.getAllAccidents());
        break;

      default:
        console.warn('[App] Onglet inconnu :', this.state.activeTab);
    }
  },

  /* ── UTILITAIRES UI ──────────────────────────────────────────── */
  _showLoader(visible) {
    const el = document.getElementById('app-loader');
    if (el) el.style.display = visible ? 'flex' : 'none';
  },

  _setStatus(type, text) {
    const el = document.getElementById('app-status');
    if (!el) return;
    el.className = type;
    el.querySelector('.status-text').textContent = text;
  },

  _showError(msg) {
    const el = document.getElementById('app-error');
    if (el) { el.textContent = msg; el.style.display = 'flex'; }
  },

  _hideError() {
    const el = document.getElementById('app-error');
    if (el) el.style.display = 'none';
  },
};

window.App = App;
