/**
 * @AI_SPACE
 * @purpose : Gestionnaire des graphiques de l'onglet Culture & Tourisme.
 * @logic : Rendu de diagrammes en barres et radars polaires via Plotly.react.
 * @decisions : centralisation du layout et usage de react pour une navigation fluide entre les profils culturels des villes.
 * @references : https://plotly.com/javascript/radar-charts/
 */

/* ============================================================
   js/culture.js — Onglet Culture & Tourisme
============================================================ */

'use strict';

function renderCulture(cityA, cityB) {
  const cA = cityA.culture, cB = cityB.culture;
  if (!cA || !cB) return;
  const nomA = cityA.base.nom, nomB = cityB.base.nom;

  // ── Équipements culturels (barres) ───────────────────────────
  const equipLabels = ['Musées','Théâtres','Bibliothèques','Cinémas'];
  Plotly.react('chart-cul-equip', [
    {
      type: 'bar', name: nomA, x: equipLabels,
      y: [cA.musees, cA.theatres, cA.bibliotheques, cA.cinemas],
      marker: { color: COLOR_A },
      hovertemplate: '<b>%{x}</b><br>' + nomA + ' : %{y}<extra></extra>',
    },
    {
      type: 'bar', name: nomB, x: equipLabels,
      y: [cB.musees, cB.theatres, cB.bibliotheques, cB.cinemas],
      marker: { color: COLOR_B },
      hovertemplate: '<b>%{x}</b><br>' + nomB + ' : %{y}<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', hovermode: 'x unified',
    yaxis: { ..._baseLayout().yaxis, type: 'linear', title: { text: 'Nombre', font: { size: 11 } } },
  }), PLOTLY_CFG);

  // ── Radar multi-axial ────────────────────────────────────────
  const maxVals = [10,
    Math.max(cA.evenements_annuels, cB.evenements_annuels, 1),
    Math.max(cA.restaurants, cB.restaurants, 1),
    Math.max(cA.musees, cB.musees, 1), 10,
    Math.max(cA.hotels, cB.hotels, 1)];
  const radarAxes  = ['Tourisme','Événements','Restaurants','Musées','Qualité de vie','Hôtels'];
  const normalize  = (vals) => vals.map((v, i) => (v / maxVals[i]) * 10);
  const valsA = normalize([cA.note_tourisme || 0, cA.evenements_annuels || 0, cA.restaurants || 0, cA.musees || 0, cA.score_qualite_vie || 0, cA.hotels || 0]);
  const valsB = normalize([cB.note_tourisme || 0, cB.evenements_annuels || 0, cB.restaurants || 0, cB.musees || 0, cB.score_qualite_vie || 0, cB.hotels || 0]);

  try {
    const elRadar = document.getElementById('chart-cul-radar');
    if (elRadar) {
      Plotly.react(elRadar, [
        {
          type: 'scatterpolar', name: nomA,
          r: [...valsA, valsA[0]], theta: [...radarAxes, radarAxes[0]],
          fill: 'toself', fillcolor: COLOR_A_FILL,
          line: { color: COLOR_A, width: 2 },
          hovertemplate: '<b>%{theta}</b><br>' + nomA + ' : %{r:.1f}/10<extra></extra>',
        },
        {
          type: 'scatterpolar', name: nomB,
          r: [...valsB, valsB[0]], theta: [...radarAxes, radarAxes[0]],
          fill: 'toself', fillcolor: COLOR_B_FILL,
          line: { color: COLOR_B, width: 2 },
          hovertemplate: '<b>%{theta}</b><br>' + nomB + ' : %{r:.1f}/10<extra></extra>',
        },
      ], _baseLayout({
        polar: {
          bgcolor: 'rgba(255, 255, 255, 0.02)',
          radialaxis: { range: [0, 10], tickfont: { size: 9, color: '#94a3b8' }, gridcolor: 'rgba(255, 255, 255, 0.1)' },
          angularaxis: { gridcolor: 'rgba(255, 255, 255, 0.1)', tickfont: { size: 10, color: '#94a3b8' } },
        },
        legend: { orientation: 'h', y: -0.15 },
        margin: { t: 30, r: 40, b: 60, l: 40 },
      }), PLOTLY_CFG);
    }
  } catch (err) { console.error('[CultureChart] Radar error:', err); }

  // ── Scores synthétiques (barres) ──────────────────────────────
  try {
    const elScores = document.getElementById('chart-cul-scores');
    if (elScores) {
      Plotly.react(elScores, [
        {
          type: 'bar', orientation: 'h', name: nomA,
          y: ['Attractivité touristique','Qualité de vie'],
          x: [cA.note_tourisme, cA.score_qualite_vie],
          marker: { color: COLOR_A },
          hovertemplate: '<b>%{y}</b><br>' + nomA + ' : %{x:.1f}/10<extra></extra>',
        },
        {
          type: 'bar', orientation: 'h', name: nomB,
          y: ['Attractivité touristique','Qualité de vie'],
          x: [cB.note_tourisme, cB.score_qualite_vie],
          marker: { color: COLOR_B },
          hovertemplate: '<b>%{y}</b><br>' + nomB + ' : %{x:.1f}/10<extra></extra>',
        },
      ], _baseLayout({
        barmode: 'group', hovermode: 'y unified',
        margin: { t: 30, r: 20, b: 40, l: 180 },
        xaxis: { ..._baseLayout().xaxis, type: 'linear', range: [0, 11], title: { text: 'Score /10', font: { size: 11 } } },
      }), PLOTLY_CFG);
    }
  } catch (err) { console.error('[CultureChart] Scores error:', err); }
}

window.CultureChart = { renderCulture };
