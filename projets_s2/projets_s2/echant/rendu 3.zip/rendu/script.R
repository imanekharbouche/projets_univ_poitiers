#installer les packages des librairies si elles n'eistent pas 
install.packages("stringr")
install.packages("sampling")

# Charger les données depuis le fichier csv
library(stringr)
library(sampling)



#######################################################################

# Partie 1 : Estimation du nombre d'habitants d'une région de france  

#######################################################################

# Charger les données depuis le fichier CSV
table <- read.csv("C:\\Users\\ikharbou\\OneDrive - Université de Poitiers\\BUT1\\S2\\SAE\\ECHANTILLONNAGE\\sae\\population_francaise_communes.csv", sep = ";", dec = ",", header = TRUE,  fileEncoding = "latin1")
# Filtrer les données pour obtenir uniquement les communes de la région Occitanie
donnees <- subset(table, Nom.de.la.région == "Occitanie", select = c("Code.département", "Commune", "Population.totale"))

#_______________________________________________________________________
# Partie 1.1 : Estimation du nombre d'habitants d'une région de france  
#_______________________________________________________________________

# Supprimer les espaces dans les chiffres de la population et convertir en numérique
donnees$Population.totale <- as.numeric(str_remove_all(donnees$Population.totale, " "))

#Variables U avec les communes
U <- donnees$Commune
head(U)
U

# Calculer le nombre total de communes dans U
N<- length(U)
N

# Calculer le nombre total d'habitants de la région Occitanie
T <- sum(donnees$Population.totale)
T

# Définir la taille de l'échantillon
n <- 100

# Répéter le processus d'échantillonnage, d'estimation et de calcul d'IDC pour plusieurs échantillons
nombre_echantillons <- 100
resultats <- data.frame(PopulationEst = numeric(nombre_echantillons),
                        marge = numeric(nombre_echantillons),
                        IDC = character(nombre_echantillons),
                        populationreel = numeric(nombre_echantillons))

for (i in 1:nombre_echantillons) {
  # Échantillonnage
  E <- sample(U, n)
  
  # Sélection des données d'échantillon
  donnees1 <- donnees[donnees$Commune %in% E, ]
  donnees2 <- subset(donnees1, select = c(Commune, Population.totale))
  
  # Moyenne de l’échantillon
  xbar <- mean(donnees2$Population.totale)
  
  # Intervalle de confiance
  idcmoy <- t.test(donnees2$Population.totale)$conf.int
  
  # Estimation totale
  T_est <- N * xbar
  
  # IDC pour le total
  idcT <- idcmoy * N
  
  # Marge d’erreur
  marge <- (idcT[2] - idcT[1]) / 2
  
  # Stocker les résultats
  resultats[i, ] <- list(T_est, marge, paste(round(idcT[1]), "-", round(idcT[2])), T)
}


#valeurs 
xbar
idcmoy
T_est
idcT
marge


# Écriture des résultats dans un fichier CSV
write.csv2(resultats, file = "C:\\Users\\ikharbou\\OneDrive - Université de Poitiers\\BUT1\\S2\\SAE\\ECHANTILLONNAGE\\sae\\resultat.csv", row.names = FALSE)


#_______________________________________________________________________
# Partie 1.2 : Echantillonnage aléatoire stratifié   
#_______________________________________________________________________

#Echantillonage stratifié
quantiles<-summary(donnees$Population.totale)
quantiles

# strates : <137, entre 137 et 308,entre 308 et 1369 entre 1369 et 503020, plus de 503020
donnees$Strate=cut(donnees$Population.totale, breaks=c(0,137, 308,1369,503020), labels=c(1,2,3,4))
donneesstrat=donnees[ ,c("Commune", "Population.totale", "Strate")]
head(donneesstrat)

# effectif des strates
data = donneesstrat[order(donneesstrat$Strate), ]
Nh=table(data$Strate)
Nh
sum(Nh)

# Tirage d’un echantillon stratifie de taille n=100
n=100
nh=c(25,25,25,25)
# Répéter le processus d'échantillonnage, d'estimation et de calcul d'IDC pour plusieurs échantillons
nombre_echantillons <- 10

resultatsstrat <- data.frame(PopulationEst = numeric(nombre_echantillons),marge = numeric(nombre_echantillons),IDC = character(nombre_echantillons),populationreel = T)
for (i in 1:nombre_echantillons) {
  # sondage strat (sans remise dans les strates)
  st = strata(data, stratanames = c("Strate"), size = nh, method = "srswr")
  data1=getdata(data, st)
  head(data1)
  length((data1$Commune))
  
  # Poids des strates
  gh=Nh/N
  gh
  # taux de sondage  des strates
  fh=nh/Nh
  fh
  
  #dEFINIR LES QUATRES STRATES
  ech1=data1[data1$Strate==1, ]
  ech1
  ech2=data1[data1$Strate==2, ]
  ech3=data1[data1$Strate==3, ]
  ech4=data1[data1$Strate==4, ]
  
  # Moyennes des 4 \’echantillons
  m1=mean(ech1$Population.totale)
  m2=mean(ech2$Population.totale)
  m3=mean(ech3$Population.totale)
  m4=mean(ech4$Population.totale)
  
  
  # Variances des 4 \’echantillons
  var1=var(ech1$Population.totale)
  var2=var(ech2$Population.totale)
  var3=var(ech3$Population.totale)
  var4=var(ech4$Population.totale)
  
  
  # Moyenne g\’en\’erale (des 3 \’echant r\’eunis)
  Xbarst= (Nh[1]*m1 + Nh[2]*m2 + Nh[3]*m3 + Nh[4]*m4)/N
  
  # estimation de la variance de Xbarst
  varXbarst= ((gh[1])^2)*(1-fh[1])*var1/(nh[1]) + ((gh[2])^2)*(1-fh[2])*var2/(nh[2]) +((gh[3])^2)*(1-fh[3])*var3/(nh[3]) + ((gh[4])^2)*(1-fh[4])*var4/(nh[4])
  
  # idc pour mu \‘a 95%
  alpha=0.05
  binf = Xbarst - qnorm(1-alpha/2)*sqrt(varXbarst)
  bsup = Xbarst + qnorm(1-alpha/2)*sqrt(varXbarst)
  idcmoy=c(binf, bsup)
  # estim du total T
  Tstr= N*Xbarst
  Tstr
  # Estimation par IDC du total T
  binf = idcmoy[1]*N
  bsup= idcmoy[2]*N
  idcT=c(binf, bsup)
  idcT
  
  # marge d’erreur
  marge=(idcT[2]-idcT[1])/2
  marge
  resultatsstrat[i, ] <- list(Tstr, marge, paste(idcT[2], "-", idcT[1]), T)
  
}

# Écriture des résultats dans un fichier CSV
write.csv2(resultatsstrat, file = "resultat des strates3.csv", row.names = FALSE)

#On compose 10 strates à partir des déciles 

# Calcul des déciles
deciles <- quantile(donnees$Population.totale , probs = seq(0.1, 0.9, by = 0.1))
deciles

# strates : 
donnees$Strate=cut(donnees$Population.totale, breaks=c(0,72.3, 113., 164.0,  226.0 , 308.0,  444.0,  667.3, 1141.4, 2425.2, 503020 ), labels=c(1,2,3,4,5,6,7,8,9,10))
donneesStrat=donnees[ ,c("Commune", "Population.totale", "Strate")]
head(donneesStrat)

# effectif des strates
data = donneesStrat[order(donneesStrat$Strate), ]
Nh=table(data$Strate)
Nh
sum(Nh)


# Tirage d’un \’echantillon stratifi\’e de taille n=100
n=100
nh=c(10,10,10,10,10,10,10,10,10,10)
# Répéter le processus d'échantillonnage, d'estimation et de calcul d'IDC pour plusieurs échantillons
nombre_echantillons <- 10

resultatsStrat <- data.frame(PopulationEst = numeric(nombre_echantillons),marge = numeric(nombre_echantillons),IDC = character(nombre_echantillons),populationreel = T)



for (i in 1:nombre_echantillons) {
  # sondage strat (sans remise dans les strates)
  st = strata(data, stratanames = c("Strate"), size = nh, method = "srswr")
  data1=getdata(data, st)
  head(data1)
  length((data1$Commune))
  
  # Poids des strates
  gh=Nh/N
  gh
  # taux de sondage  des strates
  fh=nh/Nh
  fh
  
  #dEFINIR LES QUATRES STRATES
  ech1=data1[data1$Strate==1, ]
  ech1
  ech2=data1[data1$Strate==2, ]
  ech3=data1[data1$Strate==3, ]
  ech4=data1[data1$Strate==4, ]
  ech5=data1[data1$Strate==5, ]
  ech6=data1[data1$Strate==6, ]
  ech7=data1[data1$Strate==7, ]
  ech8=data1[data1$Strate==8, ]
  ech9=data1[data1$Strate==9, ]
  ech10=data1[data1$Strate==10, ]
  
  # Moyennes des 10 \’echantillons
  m1=mean(ech1$Population.totale)
  m2=mean(ech2$Population.totale)
  m3=mean(ech3$Population.totale)
  m4=mean(ech4$Population.totale)
  m5=mean(ech5$Population.totale)
  m6=mean(ech6$Population.totale)
  m7=mean(ech7$Population.totale)
  m8=mean(ech8$Population.totale)
  m9=mean(ech9$Population.totale)
  m10=mean(ech10$Population.totale)
  
  # Variances des 10 \’echantillons
  var1=var(ech1$Population.totale)
  var2=var(ech2$Population.totale)
  var3=var(ech3$Population.totale)
  var4=var(ech4$Population.totale)
  var5=var(ech5$Population.totale)
  var6=var(ech6$Population.totale)
  var7=var(ech7$Population.totale)
  var8=var(ech8$Population.totale)
  var9=var(ech9$Population.totale)
  var10=var(ech10$Population.totale)
  
  # Moyenne g\’en\’erale (des 3 \’echant r\’eunis)
  Xbarst= (Nh[1]*m1 + Nh[2]*m2 + Nh[3]*m3 + Nh[4]*m4+ Nh[5]*m5+ Nh[6]*m6+ Nh[7]*m7+ Nh[8]*m8+ Nh[9]*m9+ Nh[10]*m10)/N
  
  # estimation de la variance de Xbarst
  varXbarst= ((gh[1])^2)*(1-fh[1])*var1/(nh[1]) + ((gh[2])^2)*(1-fh[2])*var2/(nh[2]) +((gh[3])^2)*(1-fh[3])*var3/(nh[3]) + ((gh[4])^2)*(1-fh[4])*var4/(nh[4])+((gh[10])^2)*(1-fh[10])*var10/(nh[10])+((gh[5])^2)*(1-fh[5])*var5/(nh[5])+((gh[6])^2)*(1-fh[6])*var6/(nh[6])+((gh[7])^2)*(1-fh[7])*var7/(nh[7])+((gh[8])^2)*(1-fh[8])*var8/(nh[8])+((gh[9])^2)*(1-fh[9])*var9/(nh[9])
  
  # idc pour mu \‘a 95%
  alpha=0.05
  binf = Xbarst - qnorm(1-alpha/2)*sqrt(varXbarst)
  bsup = Xbarst + qnorm(1-alpha/2)*sqrt(varXbarst)
  idcmoy=c(binf, bsup)
  # estim du total T
  Tstr= N*Xbarst
  Tstr
  # Estimation par IDC du total T
  binf = idcmoy[1]*N
  bsup= idcmoy[2]*N
  idcT=c(binf, bsup)
  idcT
  
  # marge d’erreur
  marge=(idcT[2]-idcT[1])/2
  marge
  resultatsStrat[i, ] <- list(Tstr, marge, paste(idcT[2], "-", idcT[1]), T)
  
}

# Écriture des résultats dans un fichier CSV
write.csv2(resultatsStrat, file = "resultat des 10 strates.csv", row.names = FALSE)


#######################################################################
# Partie 2 : Traitement de données d'enquête  
#######################################################################

# Importation du fichier CSV
enquete_sport <- read.csv("C:\\Users\\ikharbou\\OneDrive - Université de Poitiers\\BUT1\\S2\\SAE\\ECHANTILLONNAGE\\sae\\EnqueteSportEtudiant2024.csv",
                          sep = ";", dec = ",", header = TRUE, encoding = "latin1")

# Affichage des 6 premières lignes
head(enquete_sport)
n <- nrow(enquete_sport)
cat("Nombre d'observations :", n, "\n")

# Variables qualitatives à tester contre "sport"
vars <- c("sexe", "deptformation", "niveau", "alternant", "bourse", 
          "logement", "fumer", "alimentation", "sante", "sportavant", "reussite")

# Initialisation des vecteurs pour stocker les résultats
p_values <- c()
v_cramers <- c()
significatifs <- c()

# Boucle sur chaque variable
for (var in vars) {
  # Table de contingence
  tab_sport <- table(enquete_sport[[var]], enquete_sport$sport)
  
  # Test du Chi-2
  test_khi2 <- chisq.test(tab_sport)
  p_val <- test_khi2$p.value
  p_values <- c(p_values, p_val)
  
  # Si le test est significatif, calcul du V de Cramer
  if (p_val < 0.05) {
    p <- nrow(tab_sport)
    q <- ncol(tab_sport)
    m <- min(p - 1, q - 1)
    V <- sqrt(test_khi2$statistic / (n * m))
    v_cramers <- c(v_cramers, V)
    significatifs <- c(significatifs, var)
  } else {
    v_cramers <- c(v_cramers, NA)
  }
  
  # Affichage des résultats pour chaque variable
  cat("\nVariable :", var, "\n")
  print(tab_sport)
  print(test_khi2)
  if (!is.na(v_cramers[length(v_cramers)])) {
    cat("V de Cramer :", round(V, 4), "\n")
  }
}

# Résumé des résultats
res <- data.frame(
  Variable = vars,
  P_value = round(p_values, 4),
  V_de_Cramer = round(v_cramers, 4)
)

# Affichage du tableau final
cat("\nRésumé des tests :\n")
print(res)

# Identifier la liaison la plus forte
max_v <- max(res$V_de_Cramer, na.rm = TRUE)

# Filtrer les lignes où V_de_Cramer == max_v
plus_forte_liaison <- res[!is.na(res$V_de_Cramer) & res$V_de_Cramer == max_v, "Variable"]

# Affichage lisible
cat("\nLa liaison la plus forte avec 'sport' est :", 
    paste(plus_forte_liaison, collapse = ", "), 
    "avec un V de Cramer de", round(max_v, 4), "\n")

