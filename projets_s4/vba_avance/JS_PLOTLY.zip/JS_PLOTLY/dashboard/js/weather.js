/**
 * @AI_SPACE
 * @purpose : Gestionnaire des graphiques de l'onglet Météo.
 * @logic : Rendu de séries temporelles (scatter) et de matrices thermiques (heatmap) via Plotly.react.
 * @decisions : centralisation du layout et usage de react pour des mises à jour climatiques fluides et cohérentes.
 * @references : https://plotly.com/javascript/heatmaps/
 */

/* ============================================================
   js/weather.js — Onglet Météo
   
   Graphiques produits :
     1. Températures mensuelles (lignes synchronisées)
     2. Précipitations mensuelles (barres groupées)
     3. Ensoleillement (aire remplie)
     4. NOUVEAU : Heatmap mois × ville (température)
   
   Pour le QCM :
     - type:'heatmap' → matrice de valeurs colorées
     - z : tableau 2D [ligne][colonne] des valeurs
     - colorscale : palette prédéfinie ou personnalisée
     - hovermode:'x unified' → tooltip commun à plusieurs traces
============================================================ */

'use strict';

/* ── Constante partagée : mois en français ─────────────────── */
const MOIS_FR = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];

/* ── 1. Températures mensuelles (lignes) ──────────────────── */
function _renderTemperatures(mA, mB, nomA, nomB) {
  Plotly.react('chart-met-temp', [
    {
      type: 'scatter', mode: 'markers+lines', name: nomA,
      x: MOIS_FR, y: mA.temperatures,
      line: { color: COLOR_A, width: 2.5 }, marker: { size: 5 },
      hovertemplate: '<b>%{x}</b><br>' + nomA + ' : %{y:.1f}°C<extra></extra>',
    },
    {
      type: 'scatter', mode: 'markers+lines', name: nomB,
      x: MOIS_FR, y: mB.temperatures,
      line: { color: COLOR_B, width: 2.5 }, marker: { size: 5 },
      hovertemplate: '<b>%{x}</b><br>' + nomB + ' : %{y:.1f}°C<extra></extra>',
    },
  ], _baseLayout({
    hovermode: 'x unified',
    yaxis: { ..._baseLayout().yaxis, title: { text: '°C', font: { size: 11 } } },
  }), PLOTLY_CFG);
}

/* ── 2. Précipitations mensuelles (barres) ─────────────────── */
function _renderPrecipitations(mA, mB, nomA, nomB) {
  Plotly.react('chart-met-precip', [
    {
      type: 'bar', name: nomA,
      x: MOIS_FR, y: mA.precipitations,
      marker: { color: COLOR_A, opacity: 0.8 },
      hovertemplate: '<b>%{x}</b><br>' + nomA + ' : %{y:.1f} mm<extra></extra>',
    },
    {
      type: 'bar', name: nomB,
      x: MOIS_FR, y: mB.precipitations,
      marker: { color: COLOR_B, opacity: 0.8 },
      hovertemplate: '<b>%{x}</b><br>' + nomB + ' : %{y:.1f} mm<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', hovermode: 'x unified',
    yaxis: { ..._baseLayout().yaxis, type: 'linear', title: { text: 'mm', font: { size: 11 } } },
  }), PLOTLY_CFG);
}

/* ── 3. Ensoleillement (aire) ──────────────────────────────── */
function _renderEnsoleillement(mA, mB, nomA, nomB) {
  Plotly.react('chart-met-soleil', [
    {
      type: 'scatter', mode: 'lines', name: nomA,
      x: MOIS_FR, y: mA.ensoleillement,
      fill: 'tozeroy', fillcolor: COLOR_A_FILL,
      line: { color: COLOR_A, width: 1.5 },
      hovertemplate: '<b>%{x}</b><br>' + nomA + ' : %{y}h<extra></extra>',
    },
    {
      type: 'scatter', mode: 'lines', name: nomB,
      x: MOIS_FR, y: mB.ensoleillement,
      fill: 'tozeroy', fillcolor: COLOR_B_FILL,
      line: { color: COLOR_B, width: 1.5 },
      hovertemplate: '<b>%{x}</b><br>' + nomB + ' : %{y}h<extra></extra>',
    },
  ], _baseLayout({
    hovermode: 'x unified',
    yaxis: { ..._baseLayout().yaxis, type: 'linear', title: { text: 'Heures', font: { size: 11 } } },
  }), PLOTLY_CFG);
}

/**
 * _renderTempBars()
 * Alternative robuste à la heatmap : graphique en barres groupées
 */
function _renderTempBars(mA, mB, nomA, nomB) {
  const containerId = 'chart-met-heatmap-v2';
  const el = document.getElementById(containerId);
  if (!el) return;

  try {
    const dataA = (mA.temperatures || []).map(v => Number(v) || 0);
    const dataB = (mB.temperatures || []).map(v => Number(v) || 0);

    const traceA = {
      x: MOIS_FR,
      y: dataA,
      name: nomA,
      type: 'bar',
      marker: { color: COLOR_A }
    };

    const traceB = {
      x: MOIS_FR,
      y: dataB,
      name: nomB,
      type: 'bar',
      marker: { color: COLOR_B }
    };

    const layout = _baseLayout({
      barmode: 'group',
      yaxis: { title: 'Température (°C)' },
      margin: { t: 30, r: 20, b: 40, l: 50 }
    });

    Plotly.react(el, [traceA, traceB], layout, PLOTLY_CFG);
  } catch (err) {
    console.error('[WeatherChart] TempBars chart error:', err);
  }
}

/**
 * Helper: Convert Open-Meteo weathercode to emoji
 */
function _getWeatherEmoji(code) {
  if (code === 0) return '☀️';
  if ([1, 2].includes(code)) return '🌤️';
  if (code === 3) return '☁️';
  if ([45, 48].includes(code)) return '🌫️';
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return '🌧️';
  if ([71, 73, 75, 77, 85, 86].includes(code)) return '❄️';
  if ([95, 96, 99].includes(code)) return '⛈️';
  return '☁️';
}

/**
 * _renderForecast()
 * Fetches 5-day forecast (temps, prep, weathercode) from Open-Meteo for both cities and renders it.
 */
async function _renderForecast(cityA, cityB) {
  const containerId = 'chart-met-forecast';
  const el = document.getElementById(containerId);
  if (!el) return;

  try {
    el.innerHTML = '<div class="alert info">Chargement des prévisions (5 jours)...</div>';

    // 1. Endpoint: Use coordinates from city.base
    const latA = cityA.base.lat;
    const lonA = cityA.base.lon;
    const latB = cityB.base.lat;
    const lonB = cityB.base.lon;

    const urlA = `https://api.open-meteo.com/v1/forecast?latitude=${latA}&longitude=${lonA}&daily=temperature_2m_max,precipitation_sum,weathercode&timezone=Europe%2FParis`;
    const urlB = `https://api.open-meteo.com/v1/forecast?latitude=${latB}&longitude=${lonB}&daily=temperature_2m_max,precipitation_sum,weathercode&timezone=Europe%2FParis`;

    // 2. Fetch data (parallel)
    const [resA, resB] = await Promise.all([ fetch(urlA), fetch(urlB) ]);
    if (!resA.ok || !resB.ok) {
      throw new Error("Erreur réseau API Open-Meteo");
    }

    const dataA = await resA.json();
    const dataB = await resB.json();

    const dates = dataA.daily.time; // Both use same 7-day projection array natively

    // Generate Emoji texts
    const emojisA = dataA.daily.weathercode.map(_getWeatherEmoji);
    const emojisB = dataB.daily.weathercode.map(_getWeatherEmoji);

    // Clear loader
    el.innerHTML = '';

    const nomA = cityA.base.nom;
    const nomB = cityB.base.nom;

    // 3. Traces: Temperatures (lines) and Precipitation (bars on y2)
    const traceA_Temp = {
      x: dates, 
      y: dataA.daily.temperature_2m_max,
      text: emojisA,
      name: nomA + ' (Max)', 
      type: 'scatter', 
      mode: 'lines+markers+text',
      textposition: 'top center',
      textfont: { size: 16 },
      line: { color: COLOR_A, width: 3 },
      marker: { size: 6 }
    };
    
    const traceB_Temp = {
      x: dates, 
      y: dataB.daily.temperature_2m_max,
      text: emojisB,
      name: nomB + ' (Max)', 
      type: 'scatter', 
      mode: 'lines+markers+text',
      textposition: 'bottom center',
      textfont: { size: 16 },
      line: { color: COLOR_B, width: 3 },
      marker: { size: 6 }
    };

    const traceA_Precip = {
      x: dates,
      y: dataA.daily.precipitation_sum,
      name: nomA + ' (Précip.)',
      type: 'bar',
      yaxis: 'y2',
      marker: { color: COLOR_A, opacity: 0.3 }
    };

    const traceB_Precip = {
      x: dates,
      y: dataB.daily.precipitation_sum,
      name: nomB + ' (Précip.)',
      type: 'bar',
      yaxis: 'y2',
      marker: { color: COLOR_B, opacity: 0.3 }
    };

    // 4. Layout: Secondary Y Axis for precipitation
    const baseL = _baseLayout();
    const layout = {
      ...baseL,
      hovermode: 'x unified',
      xaxis: { title: 'Date' },
      yaxis: { 
        ...baseL.yaxis,
        title: 'Température (°C)',
      },
      yaxis2: {
        title: 'Précipitations (mm)',
        overlaying: 'y',
        side: 'right',
        showgrid: false,
        zeroline: false,
        tickfont: { color: 'rgba(255,255,255,0.6)' }
      },
      barmode: 'group',
      margin: { t: 30, r: 50, b: 40, l: 50 },
      showlegend: true
    };

    Plotly.react(containerId, [traceA_Precip, traceB_Precip, traceA_Temp, traceB_Temp], layout, PLOTLY_CFG);

  } catch (err) {
    console.error('[WeatherChart] Forecast fetch error:', err);
    el.innerHTML = `<div class="alert error">Erreur lors du chargement des prévisions.</div>`;
  }
}

/** Fonction principale */
function renderMeteo(cityA, cityB) {
  const mA = cityA?.meteo, mB = cityB?.meteo;
  if (!mA || !mA.temperatures || !mB || !mB.temperatures) {
    console.warn('[WeatherChart] Données météo manquantes pour une des villes.');
    // On essaye quand même de vider pour ne pas laisser de vieux restes
    ['chart-met-temp', 'chart-met-precip', 'chart-met-soleil', 'chart-met-heatmap-v2'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.innerHTML = `<div class="alert info">Données météo non disponibles.</div>`;
    });
    return;
  }

  const nomA = cityA.base.nom, nomB = cityB.base.nom;

  // 5. Integration: Call the forecast inside a dedicated try/catch
  try {
    _renderForecast(cityA, cityB);
  } catch(err) {
    console.error('[WeatherChart] Forecast crashed but gracefully caught:', err);
  }

  try {
    _renderTemperatures(mA, mB, nomA, nomB);
    _renderPrecipitations(mA, mB, nomA, nomB);
    _renderEnsoleillement(mA, mB, nomA, nomB);
    _renderTempBars(mA, mB, nomA, nomB);
  } catch (err) {
    console.error('[WeatherChart] Erreur globale rendu météo:', err);
  }
}

window.WeatherChart = { renderMeteo };
