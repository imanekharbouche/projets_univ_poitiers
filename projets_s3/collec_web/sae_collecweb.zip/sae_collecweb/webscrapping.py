import time 
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait  # Pour attendre des conditions spécifiques
from selenium.webdriver.support import expected_conditions as EC # Pour définir des conditions d'attente

# ==========================================
# CONFIGURATION DU NAVIGATEUR CHROME
# ==========================================

options = webdriver.ChromeOptions()  # Objet pour définir les options de Chrome
service = Service(ChromeDriverManager().install())  # Télécharge et installe automatiquement ChromeDriver
driver = webdriver.Chrome(service=service, options=options)  # Crée l'instance du navigateur Chrome

# URL du site à scraper (base de données des Superchargeurs Tesla)
url = "https://supercharge.info/data"

# ==========================================
# FONCTION D'ATTENTE INTELLIGENTE
# ==========================================

def attendre_fin_chargement_tableau(driver, timeout=30):
    """
    Attend que le tableau soit complètement chargé en vérifiant la stabilité du nombre de lignes.
    
    Principe : Le tableau se charge dynamiquement via JavaScript. On ne peut pas simplement
    attendre un temps fixe car cela dépend de la connexion. On vérifie donc que le nombre 
    de lignes reste stable pendant 3 vérifications consécutives.
    
    Args:
        driver: Instance du navigateur Selenium
        timeout (int): Temps maximum d'attente en secondes (par défaut 30s)
    
    Returns:
        bool: True si le tableau est stabilisé, False si timeout atteint
    """
    print("⏳ Attente de la fin du chargement du tableau...")
    
    # Pause initiale pour laisser le JavaScript commencer à s'exécuter
    time.sleep(2)
    
    # Variables pour vérifier la stabilité du nombre de lignes
    tentatives = 0  # Compteur de secondes écoulées
    nb_lignes_stable = 0  # Compteur de vérifications consécutives avec le même nombre de lignes
    dernier_compte = 0  # Mémorisation du nombre de lignes à la vérification précédente
    
    # Boucle d'attente avec timeout
    while tentatives < timeout:
        # Parse le HTML actuel de la page
        soup = BeautifulSoup(driver.page_source, "html.parser")
        tables = soup.find_all('table')  # Récupère tous les tableaux de la page
        
        if tables:
            # Sélectionne le plus grand tableau (celui avec le plus de lignes)
            big_table = max(tables, key=lambda t: len(t.find_all('tr')))
            nb_lignes = len(big_table.find_all('tr'))  # Compte les lignes <tr>
            
            # Vérifie si le nombre de lignes est stable
            if nb_lignes == dernier_compte and nb_lignes > 10:
                nb_lignes_stable += 1
                # Si stable pendant 3 vérifications consécutives, le tableau est prêt
                if nb_lignes_stable >= 3:
                    print(f"✓ Tableau stabilisé avec {nb_lignes} lignes")
                    return True
            else:
                # Le nombre a changé, on réinitialise le compteur de stabilité
                nb_lignes_stable = 0
            
            dernier_compte = nb_lignes
        
        time.sleep(1)  # Attente d'1 seconde avant la prochaine vérification
        tentatives += 1
    
    # Si on sort de la boucle, c'est que le timeout est atteint
    print(f"⚠️ Timeout atteint - on continue avec {dernier_compte} lignes")
    return False

# ==========================================
# BLOC PRINCIPAL D'EXÉCUTION
# ==========================================

try:
    # --- ÉTAPE 1 : CHARGEMENT DE LA PAGE ---
    print(f"Connexion à {url}...")
    driver.get(url)  # Charge l'URL dans le navigateur
    driver.maximize_window()  # Met le navigateur en plein écran (aide à voir tous les éléments)

    # Pause de sécurité pour laisser la page et le JavaScript se charger complètement
    print("Pause initiale pour laisser la page se charger...")
    time.sleep(8)

    # --- ÉTAPE 2 : AFFICHER TOUTES LES LIGNES DU TABLEAU ---
    try:
        print("Recherche du menu pour afficher toutes les lignes...")
        # Récupère tous les menus déroulants <select> de la page
        selects = driver.find_elements(By.TAG_NAME, "select")
        
        menu_trouve = False
        # Parcourt tous les menus pour trouver celui qui contrôle le nombre de lignes affichées
        for select_element in selects:
            # Vérifie si le menu contient "100" ou "All" (options typiques pour afficher toutes les lignes)
            if "100" in select_element.text or "All" in select_element.text:
                select_obj = Select(select_element)  # Crée un objet Select pour manipuler le menu
                # Sélectionne la dernière option (généralement "All" ou le nombre maximum)
                select_obj.select_by_index(len(select_obj.options) - 1)
                print(">>> Menu trouvé et réglé sur MAX !")
                menu_trouve = True
                
                # CRUCIAL : Attend que le tableau se recharge avec toutes les lignes
                attendre_fin_chargement_tableau(driver)
                break
        
        if not menu_trouve:
            print("Menu non trouvé, on fera avec les lignes visibles.")
            
    except Exception as e:
        print(f"Erreur menu : {e}")

    # --- ÉTAPE 3 : FILTRER LES STATIONS EN FRANCE ---
    try:
        print("Recherche de la barre de recherche...")
        # Récupère tous les champs de saisie <input> de la page
        inputs = driver.find_elements(By.TAG_NAME, "input")
        
        filtre_applique = False
        # Parcourt tous les inputs pour trouver la barre de recherche/filtre
        for inp in inputs:
            # Vérifie si c'est un champ de type "search" ou "text"
            if inp.get_attribute("type") in ["search", "text"]:
                try:
                    inp.clear()  # Vide le champ au cas où il contient déjà du texte
                    inp.send_keys("France")  # Tape "France" dans le champ
                    print(">>> Filtre 'France' appliqué !")
                    filtre_applique = True
                    
                    # CRUCIAL : Attend que le tableau soit filtré et rechargé
                    attendre_fin_chargement_tableau(driver)
                    break
                except:
                    continue  # Si erreur sur cet input, passe au suivant
        
        if not filtre_applique:
            print("⚠️ Impossible d'appliquer le filtre France")
            
    except Exception as e:
        print(f"Erreur filtre : {e}")

    # --- ÉTAPE 4 : RÉCUPÉRATION ET PARSING DU TABLEAU ---
    print("Analyse du code HTML final...")
    # Parse le code source HTML complet de la page
    soup = BeautifulSoup(driver.page_source, "html.parser")
    
    # Récupère tous les tableaux HTML <table>
    all_tables = soup.find_all('table')
    if not all_tables:
        print("ERREUR FATALE : Aucun tableau visible sur la page.")
        exit()
    
    # Sélectionne le plus grand tableau (celui avec le plus de lignes <tr>)
    big_table = max(all_tables, key=lambda t: len(t.find_all('tr')))
    rows = big_table.find_all('tr')  # Récupère toutes les lignes du tableau
    
    print(f"{len(rows)} lignes trouvées dans le HTML !")

    # Liste pour stocker les données de chaque station
    data_stations = []
    
    # --- ÉTAPE 5 : EXTRACTION DES DONNÉES ---
    # Détermine la ligne de départ (1 si la première ligne contient des en-têtes <th>, sinon 0)
    start_row = 1 if rows[0].find('th') else 0

    # Parcourt chaque ligne du tableau (sauf les en-têtes)
    for row in rows[start_row:]:
        cols = row.find_all('td')  # Récupère toutes les cellules <td> de la ligne

        # Vérifie qu'il y a au moins 10 colonnes (pour éviter les lignes incomplètes)
        if len(cols) >= 10:
            try:
                # Extraction des données selon l'index des colonnes
                # (Les index correspondent à l'ordre des colonnes dans le tableau du site)
                nom = cols[2].get_text(strip=True)  # Colonne 3 : Nom de la station
                adresse = cols[1].get_text(strip=True)  # Colonne 2 : Adresse
                ville = cols[3].get_text(strip=True)  # Colonne 4 : Ville
                zip_code = cols[5].get_text(strip=True)  # Colonne 6 : Code postal
                pays = cols[6].get_text(strip=True)  # Colonne 7 : Pays
                gps = cols[7].get_text(strip=True)  # Colonne 8 : Coordonnées GPS
                
                # Colonne 11 : Puissance (avec gestion si la colonne n'existe pas)
                puissance = cols[10].get_text(strip=True) if len(cols) > 10 else "N/A"
                
                # Vérification explicite : ne garde que les stations en France
                # (Le filtre web peut ne pas être parfait, donc double vérification)
                if "France" in pays or "France" in nom or "France" in ville:
                    # Création d'un lien Google Maps avec les coordonnées GPS
                    url_map = f"http://maps.google.com/maps?q={gps}"

                    # Ajout des données de la station dans la liste
                    data_stations.append({
                        "Nom": nom,
                        "Ville": ville,
                        "Adresse": adresse,
                        "Code_Postal": zip_code,
                        "GPS": gps,
                        "Puissance": puissance,
                        "Lien_Map": url_map
                    })
            except Exception as e:
                # Si erreur sur une ligne, on continue avec les autres (robustesse)
                continue

    # --- ÉTAPE 6 : SAUVEGARDE EN CSV ---
    # Conversion de la liste de dictionnaires en DataFrame pandas
    df = pd.DataFrame(data_stations)
    
    # Récupère le chemin du dossier où se trouve le script Python
    dossier_du_script = os.path.dirname(os.path.abspath(__file__))
    # Construit le chemin complet du fichier CSV de sortie
    final_path = os.path.join(dossier_du_script, "resultat_tesla_france_final.csv")
    
    # Export en CSV avec :
    # - index=False : pas de colonne d'index numérique
    # - encoding='utf-8-sig' : pour gérer les caractères français + compatibilité Excel
    df.to_csv(final_path, index=False, encoding='utf-8-sig')
    
    # Affichage du résumé
    print("\n" + "="*60)
    print(f"{len(df)} stations récupérées.")
    print("="*60)
    
    # Alerte si aucune station n'a été trouvée (problème possible)
    if df.empty:
        print("⚠️ ATTENTION : Aucune station France trouvée !")

# Gestion des erreurs globales
except Exception as e:
    print(f"Erreur technique : {e}")
    import traceback
    traceback.print_exc()  # Affiche la trace complète de l'erreur pour le débogage

# Bloc finally : s'exécute TOUJOURS, même en cas d'erreur
finally:
    driver.quit()  # Ferme proprement le navigateur Chrome pour libérer les ressources