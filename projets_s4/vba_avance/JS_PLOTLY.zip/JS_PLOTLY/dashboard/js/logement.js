/**
 * @AI_SPACE
 * @purpose : Gestionnaire des graphiques de l'onglet Logement.
 * @logic : Visualise les prix, statuts d'occupation et distributions via Plotly.react. Utilise une simulation log-normale pour le Violin Plot.
 * @decisions : centralisation du layout et usage de react pour la fluidité des transitions immobilières.
 * @references : https://plotly.com/javascript/violin-plots/
 */

/* ============================================================
   js/logement.js — Onglet Logement
   
   Graphiques produits :
     1. Loyer & prix au m² (barres groupées)
     2. Statut d'occupation (donut charts)
     3. Types de logements (barres)
     4. NOUVEAU : Violin plot simulé des prix au m²
        (distribution de prix dans la région de chaque ville)
============================================================ */

'use strict';

/* ── 1. Loyer & prix ────────────────────────────────────────── */
function _renderPrix(lA, lB, nomA, nomB) {
  const metriques = ['Loyer moy. (€/m²)', 'Prix achat (€/100m²)'];
  Plotly.react('chart-log-prix', [
    {
      type: 'bar', name: nomA,
      x: metriques, y: [lA.loyer_moyen_m2, lA.prix_moyen_m2 / 100],
      marker: { color: COLOR_A },
      hovertemplate: '<b>%{x}</b><br>' + nomA + ' : %{y:.2f}<extra></extra>',
    },
    {
      type: 'bar', name: nomB,
      x: metriques, y: [lB.loyer_moyen_m2, lB.prix_moyen_m2 / 100],
      marker: { color: COLOR_B },
      hovertemplate: '<b>%{x}</b><br>' + nomB + ' : %{y:.2f}<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', hovermode: 'x unified',
    yaxis: { ..._baseLayout().yaxis, type: 'linear' },
  }), PLOTLY_CFG);
}

/* ── 2. Statut d'occupation ─────────────────────────────────── */
function _renderOccupation(lA, lB, nomA, nomB) {
  const makePie = (l, nom, column, color) => ({
    type: 'pie', hole: 0.3,
    labels: ['Propriétaires', 'Locataires', 'Autres'],
    values: [l.taux_proprietaires, l.taux_locataires,
             Math.max(0, 100 - l.taux_proprietaires - l.taux_locataires)],
    domain: { column },
    marker: { colors: [color, '#E2E8F0', '#F8FAFC'] },
    textinfo: 'label+percent',
    hovertemplate: '%{label} : %{percent}<extra>' + nom + '</extra>',
    title: { text: nom, font: { size: 12 } },
  });
  Plotly.react('chart-log-statut', [
    makePie(lA, nomA, 0, COLOR_A),
    makePie(lB, nomB, 1, COLOR_B),
  ], _baseLayout({
    grid: { rows: 1, columns: 2 },
    margin: { t: 40, r: 20, b: 20, l: 20 },
    legend: { orientation: 'h', y: -0.1 },
  }), PLOTLY_CFG);
}

/* ── 3. Types de logements ──────────────────────────────────── */
function _renderTypes(lA, lB, nomA, nomB) {
  Plotly.react('chart-log-types', [
    {
      type: 'bar', name: nomA,
      x: ['Maisons', 'Appartements'],
      y: [lA.part_maisons, lA.part_appartements],
      marker: { color: COLOR_A },
      hovertemplate: '<b>%{x}</b><br>' + nomA + ' : %{y:.1f}%<extra></extra>',
    },
    {
      type: 'bar', name: nomB,
      x: ['Maisons', 'Appartements'],
      y: [lB.part_maisons, lB.part_appartements],
      marker: { color: COLOR_B },
      hovertemplate: '<b>%{x}</b><br>' + nomB + ' : %{y:.1f}%<extra></extra>',
    },
  ], _baseLayout({
    barmode: 'group', hovermode: 'x unified',
    yaxis: { ..._baseLayout().yaxis, type: 'linear', title: { text: '%', font: { size: 11 } } },
  }), PLOTLY_CFG);
}

/* ── 4. NOUVEAU : Violin plot (distribution prix m²) ─────────── */
function _renderViolin(lA, lB, nomA, nomB) {
  const lognormalSample = (meanPrice, n, seed) => {
    let s = Math.abs(seed);
    const rand = () => { s = (s * 9301 + 49297) % 233280; return (s / 233280) || 0.0001; };
    const sigma = 0.2;
    const mu    = Math.log(meanPrice) - sigma * sigma / 2;
    const samples = [];
    for (let i = 0; i < n; i++) {
        const u1 = rand(), u2 = rand();
        const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
        samples.push(Math.exp(mu + sigma * z));
    }
    return samples;
  };

  const N = 200;
  Plotly.react('chart-log-violin', [
    {
      type: 'violin', name: nomA, y: lognormalSample(lA.prix_moyen_m2, N, 42),
      side: 'negative', marker: { color: COLOR_A }, line: { color: COLOR_A },
      fillcolor: COLOR_A_FILL, meanline: { visible: true, color: COLOR_A, width: 2 },
      box: { visible: true }, points: 'outliers',
      hovertemplate: nomA + '<br>Prix : %{y:.0f} €/m²<extra></extra>',
    },
    {
      type: 'violin', name: nomB, y: lognormalSample(lB.prix_moyen_m2, N, 99),
      side: 'positive', marker: { color: COLOR_B }, line: { color: COLOR_B },
      fillcolor: COLOR_B_FILL, meanline: { visible: true, color: COLOR_B, width: 2 },
      box: { visible: true }, points: 'outliers',
      hovertemplate: nomB + '<br>Prix : %{y:.0f} €/m²<extra></extra>',
    },
  ], _baseLayout({
    violinmode: 'overlay', showlegend: true,
    xaxis: { zeroline: false, showticklabels: false },
    yaxis: { ..._baseLayout().yaxis, type: 'linear', title: { text: 'Prix (€/m²)', font: { size: 11 } } },
  }), PLOTLY_CFG);
}

/* ── Orchestrateur ──────────────────────────────────────────── */
function renderLogement(cityA, cityB) {
  const lA = cityA.logement, lB = cityB.logement;
  if (!lA || !lB) return;
  const nomA = cityA.base.nom, nomB = cityB.base.nom;
  try { _renderPrix(lA, lB, nomA, nomB); } catch (e) { console.error('[Logement] Prix error:', e); }
  try { _renderOccupation(lA, lB, nomA, nomB); } catch (e) { console.error('[Logement] Occupation error:', e); }
  try { _renderTypes(lA, lB, nomA, nomB); } catch (e) { console.error('[Logement] Types error:', e); }
  try { _renderViolin(lA, lB, nomA, nomB); } catch (e) { console.error('[Logement] Violin error:', e); }
}

window.LogementChart = { renderLogement };
