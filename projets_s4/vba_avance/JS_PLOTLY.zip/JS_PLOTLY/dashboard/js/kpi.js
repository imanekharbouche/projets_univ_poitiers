/* ============================================================
   js/kpi.js — Cartes KPI (Key Performance Indicators)
   
   Ce module est partagé entre tous les onglets.
   Il génère dynamiquement une rangée de cartes KPI
   affichant des métriques clés pour les deux villes.
   
   API publique :
     KPI.render(containerId, metricsArray)
   
   Pour le QCM :
     - innerHTML = '' → vide le conteneur avant de reconstruire
     - document.createElement() → création d'éléments DOM
     - template literals → string interpolation avec ${}
     - Math.abs() → valeur absolue du delta
============================================================ */

'use strict';

/* ── Labels des KPI (constantes DRY) ───────────────────────── */

/*
 * POURQUOI DES CONSTANTES SÉPARÉES ?
 * Évite les chaînes dupliquées en dur dans plusieurs fonctions.
 * Facile à traduire ou modifier en un seul endroit.
 */
const KPI_ICONS = {
  population:     '👥',
  chomage:        '📉',
  loyer:          '🏷️',
  prix_m2:        '💰',
  accidents:      '🚗',
  tourisme:       '⭐',
  temp_juillet:   '🌡️',
  etudiants:      '🎓',
};

/* ── Module KPI ─────────────────────────────────────────────── */

const KPI = {

  /**
   * render(containerId, metrics)
   * Vide le conteneur et injecte les cartes KPI.
   *
   * @param {string} containerId - ID du div destinataire
   * @param {Array<{
   *   label:  string,      // Libellé affiché sous la valeur
   *   icon?:  string,      // Emoji optionnel
   *   valA:   number|string, // Valeur ville A
   *   valB:   number|string, // Valeur ville B
   *   unit?:  string,      // Unité affichée (€, %, hab., …)
   *   higherIsBetter?: boolean  // true → ↑ est positif (vert)
   * }>} metrics - Tableau de métriques à afficher
   */
  render(containerId, metrics) {
    const container = document.getElementById(containerId);
    if (!container) {
      console.warn(`[KPI] Conteneur introuvable : #${containerId}`);
      return;
    }

    // 1. Vider le conteneur (évite les doublons au changement de ville)
    container.innerHTML = '';

    // 2. Créer la rangée de cartes
    metrics.forEach(m => {
      const card = this._createCard(m);
      container.appendChild(card);
    });
  },

  /**
   * _createCard(metric)
   * Crée un élément DOM représentant une carte KPI.
   * Calcule automatiquement le delta entre valA et valB.
   *
   * @param {Object} metric
   * @returns {HTMLElement}
   */
  _createCard(metric) {
    const { label, icon = '', valA, valB, unit = '', higherIsBetter = true } = metric;

    // ── Calcul du delta ────────────────────────────────────────
    /*
     * On ne calcule le delta que si les deux valeurs sont des nombres.
     * Pour les chaînes (ex: noms de régions), on n'affiche pas de delta.
     */
    const numA = parseFloat(valA);
    const numB = parseFloat(valB);
    const hasNumericDelta = !isNaN(numA) && !isNaN(numB);

    let deltaClass = '';
    let deltaText  = '';

    if (hasNumericDelta) {
      const diff = numA - numB;
      const absDiff = Math.abs(diff).toLocaleString('fr-FR', { maximumFractionDigits: 1 });

      if (diff === 0) {
        deltaClass = 'kpi-delta equal';
        deltaText  = '= égal';
      } else if (diff > 0) {
        // Ville A > Ville B
        const isGood = higherIsBetter;
        deltaClass = `kpi-delta ${isGood ? 'positive' : 'negative'}`;
        deltaText  = `A > B (+${absDiff}${unit})`;
      } else {
        // Ville A < Ville B
        const isGood = !higherIsBetter;
        deltaClass = `kpi-delta ${isGood ? 'positive' : 'negative'}`;
        deltaText  = `A < B (−${absDiff}${unit})`;
      }
    }

    // ── Formatage des valeurs affichées ────────────────────────
    const fmtVal = (v) => {
      const n = parseFloat(v);
      if (isNaN(n)) return String(v);
      return n.toLocaleString('fr-FR', { maximumFractionDigits: 1 });
    };

    // ── Construction du HTML (template literal) ────────────────
    const card = document.createElement('div');
    card.className = 'kpi-card';
    card.innerHTML = `
      <div class="kpi-header">
        <span class="kpi-icon" aria-hidden="true">${icon}</span>
        <span class="kpi-label">${label}</span>
      </div>
      <div class="kpi-values">
        <div class="kpi-val city-a">
          <span class="kpi-dot dot-a" aria-hidden="true"></span>
          <span>${fmtVal(valA)}${unit ? '<small> ' + unit + '</small>' : ''}</span>
        </div>
        <div class="kpi-val city-b">
          <span class="kpi-dot dot-b" aria-hidden="true"></span>
          <span>${fmtVal(valB)}${unit ? '<small> ' + unit + '</small>' : ''}</span>
        </div>
      </div>
      ${hasNumericDelta ? `<div class="${deltaClass}">${deltaText}</div>` : ''}
    `;

    return card;
  },

  /**
   * buildGeneralMetrics(cityA, cityB)
   * Retourne les métriques KPI pour l'onglet Général.
   *
   * @param {Object} cityA - { base, emploi, logement, meteo, culture }
   * @param {Object} cityB
   * @returns {Array}
   */
  buildGeneralMetrics(cityA, cityB) {
    const A = cityA.base, B = cityB.base;
    return [
      { icon: '👥', label: 'Population',   valA: A.population,    valB: B.population,    unit: ' hab.', higherIsBetter: false },
      { icon: '⚧',  label: '% Femmes',     valA: A.pop_femmes ? +(A.pop_femmes/A.population*100).toFixed(1) : 'N/A',
                                             valB: B.pop_femmes ? +(B.pop_femmes/B.population*100).toFixed(1) : 'N/A', unit: '%', higherIsBetter: false },
      { icon: '🎓', label: '% Jeunes 15-29', valA: A.tranches_age?.['15-29'] ?? 'N/A',
                                               valB: B.tranches_age?.['15-29'] ?? 'N/A',   unit: '%', higherIsBetter: false },
      { icon: '👴', label: '% 60+',         valA: +(  (A.tranches_age?.['60-74'] || 0) + (A.tranches_age?.['75-89'] || 0) + (A.tranches_age?.['90+'] || 0)).toFixed(1),
                                             valB: +(  (B.tranches_age?.['60-74'] || 0) + (B.tranches_age?.['75-89'] || 0) + (B.tranches_age?.['90+'] || 0)).toFixed(1), unit: '%', higherIsBetter: false },
    ];
  },

  buildEmploiMetrics(cityA, cityB) {
    const eA = cityA.emploi || {}, eB = cityB.emploi || {};
    return [
      { icon: '📉', label: 'Taux chômage',   valA: eA.taux_chomage,  valB: eB.taux_chomage,  unit: '%', higherIsBetter: false },
      { icon: '👷', label: 'Taux emploi',    valA: eA.taux_emploi,   valB: eB.taux_emploi,   unit: '%', higherIsBetter: true },
      { icon: '👔', label: 'Pop. active',    valA: eA.pop_active,    valB: eB.pop_active,    unit: ' pers.', higherIsBetter: true },
      { icon: '🏢', label: '% Cadres',       valA: +(eA.categories_sociopro?.['Cadres'] ?? 0).toFixed(1),
                                              valB: +(eB.categories_sociopro?.['Cadres'] ?? 0).toFixed(1), unit: '%', higherIsBetter: true },
    ];
  },

  buildLogementMetrics(cityA, cityB) {
    const lA = cityA.logement || {}, lB = cityB.logement || {};
    return [
      { icon: '🏷️',  label: 'Loyer moy.',       valA: lA.loyer_moyen_m2,    valB: lB.loyer_moyen_m2,    unit: ' €/m²', higherIsBetter: false },
      { icon: '💰',  label: 'Prix achat moy.',   valA: lA.prix_moyen_m2,     valB: lB.prix_moyen_m2,     unit: ' €/m²', higherIsBetter: false },
      { icon: '🔑',  label: '% Propriétaires',   valA: lA.taux_proprietaires, valB: lB.taux_proprietaires, unit: '%', higherIsBetter: true },
      { icon: '🏠',  label: '% Maisons',         valA: lA.part_maisons,      valB: lB.part_maisons,      unit: '%', higherIsBetter: false },
    ];
  },

  buildMeteoMetrics(cityA, cityB) {
    const mA = cityA.meteo || {}, mB = cityB.meteo || {};
    const tempMax  = (temps) => temps ? Math.max(...temps) : 'N/A';
    const precipTot = (p) => p ? Math.round(p.reduce((a, b) => a+b, 0)) : 'N/A';
    return [
      { icon: '🌡️', label: 'Temp. max (été)',   valA: tempMax(mA.temperatures),  valB: tempMax(mB.temperatures),  unit: '°C',  higherIsBetter: null },
      { icon: '❄️', label: 'Temp. min (hiver)', valA: mA.temperatures ? mA.temperatures[0] : 'N/A',
                                                 valB: mB.temperatures ? mB.temperatures[0] : 'N/A', unit: '°C', higherIsBetter: null },
      { icon: '🌧️', label: 'Précip. annuelles', valA: precipTot(mA.precipitations), valB: precipTot(mB.precipitations), unit: ' mm', higherIsBetter: false },
      { icon: '☀️', label: 'Ensoleillement mai', valA: mA.ensoleillement ? mA.ensoleillement[4] : 'N/A',
                                                  valB: mB.ensoleillement ? mB.ensoleillement[4] : 'N/A', unit: 'h', higherIsBetter: true },
    ];
  },

  buildCultureMetrics(cityA, cityB) {
    const cA = cityA.culture || {}, cB = cityB.culture || {};
    return [
      { icon: '⭐',  label: 'Note tourisme',     valA: cA.note_tourisme,       valB: cB.note_tourisme,       unit: '/10', higherIsBetter: true },
      { icon: '🎨',  label: 'Musées',            valA: cA.musees,              valB: cB.musees,              unit: '',    higherIsBetter: true },
      { icon: '🎭',  label: 'Théâtres',          valA: cA.theatres,            valB: cB.theatres,            unit: '',    higherIsBetter: true },
      { icon: '🏨',  label: 'Hôtels',            valA: cA.hotels,              valB: cB.hotels,              unit: '',    higherIsBetter: true },
    ];
  },

  buildCarsMetrics(cityA, cityB, accA, accB) {
    const nbA = accA?.nb_total ?? 0;
    const nbB = accB?.nb_total ?? 0;
    const tuesA = accA?.gravites?.['Tué'] ?? 0;
    const tuesB = accB?.gravites?.['Tué'] ?? 0;
    return [
      { icon: '🚗', label: 'Accidents totaux',  valA: nbA,  valB: nbB,  unit: '', higherIsBetter: false },
      { icon: '💀', label: 'Décès',             valA: tuesA, valB: tuesB, unit: '', higherIsBetter: false },
      { icon: '🏥', label: 'Hospitalisés',      valA: accA?.gravites?.['Blessé hospitalisé'] ?? 0,
                                                 valB: accB?.gravites?.['Blessé hospitalisé'] ?? 0, unit: '', higherIsBetter: false },
      { icon: '📊', label: 'Acc. / 10k hab.',   valA: cityA.base ? +(nbA/cityA.base.population*10000).toFixed(1) : 'N/A',
                                                 valB: cityB.base ? +(nbB/cityB.base.population*10000).toFixed(1) : 'N/A', unit: '', higherIsBetter: false },
    ];
  },
};

window.KPI = KPI;
