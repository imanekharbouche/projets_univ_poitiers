/**
 * @AI_SPACE
 * @purpose : Service de gestion des données (Version 100% Client-Side).
 * @logic : Utilise les variables globales DATA_... injectées par les scripts de données pour contourner les restrictions CORS du protocole file://.
 * @decisions : Remplacement de fetch() par l'accès direct aux variables window.DATA_...
 * @references : https://developer.mozilla.org/fr/docs/Web/API/Fetch_API/Using_Fetch (Obsolète ici pour file://)
 */

/* ============================================================
   dataService.js — Service de données (Version No-CORS)
============================================================ */

'use strict';

/** Cache interne */
let _cache = null;

const DataService = {

  /**
   * loadAll()
   * Simule le chargement en récupérant les données globales.
   */
  async loadAll() {
    if (_cache !== null) return _cache;

    // On récupère les données injectées par les balises <script> dans index.html
    const dataset = {
      villes:    window.DATA_VILLES    || [],
      emploi:    window.DATA_EMPLOI    || {},
      logement:  window.DATA_LOGEMENT  || {},
      meteo:     window.DATA_METEO     || {},
      culture:   window.DATA_CULTURE   || {},
      accidents: window.DATA_ACCIDENTS || {}
    };

    console.log('[dataService] Données chargées depuis les variables globales JS.');
    _cache = dataset;
    return dataset;
  },

  /** Retourne la liste des villes (tableau). */
  getVilles() {
    if (!_cache) throw new Error('[dataService] Données non chargées.');
    return _cache.villes;
  },

  /**
   * getCity(codgeo)
   */
  getCity(codgeo) {
    if (!_cache) throw new Error('[dataService] Données non chargées.');
    const base = _cache.villes.find(v => v.codgeo === codgeo) || null;
    return {
      base,
      emploi:    _cache.emploi[codgeo]    || null,
      logement:  _cache.logement[codgeo]  || null,
      meteo:     _cache.meteo[codgeo]     || null,
      culture:   _cache.culture[codgeo]   || null,
      accidents: _cache.accidents[codgeo] || null
    };
  },

  /** Raccourci pour les deux villes sélectionnées. */
  getCities(codgeoA, codgeoB) {
    return {
      cityA: this.getCity(codgeoA),
      cityB: this.getCity(codgeoB),
    };
  },

  /**
   * getAccidents(codgeo)
   */
  getAccidents(codgeo) {
    if (!_cache) return null;
    return _cache.accidents?.[codgeo] ?? null;
  },

  /**
   * getAllAccidents()
   */
  getAllAccidents() {
    return _cache?.accidents || {};
  },

  /**
   * Accès aux dictionnaires complets pour la carte enrichie.
   */
  getAllEmploi()   { return _cache?.emploi    || {}; },
  getAllCulture()  { return _cache?.culture   || {}; },
  getAllLogement() { return _cache?.logement  || {}; },
  getAllMeteo()    { return _cache?.meteo     || {}; },

  /** Vide le cache. */
  clearCache() { _cache = null; },
};

window.DataService = DataService;
