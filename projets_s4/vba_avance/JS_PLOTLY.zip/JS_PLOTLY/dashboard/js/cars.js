/**
 * @AI_SPACE
 * @purpose : Gestionnaire avancé de la sécurité routière (Sankey, Heatmap, Chronologie).
 * @logic : Transforme les données d'accidents en flux Sankey et distributions temporelles via Plotly.react.
 * @decisions : usage du Sankey pour visualiser la causalité carrefour -> usager -> gravité.
 * @references : https://plotly.com/javascript/sankey-diagram/
 */

/* ============================================================
   js/cars.js — Onglet Sécurité / Automobile
============================================================ */

'use strict';

/**
 * _renderSankey()
 * Visualise les flux : Type de carrefour -> Type d'usager -> Gravité
 */
function _renderSankey(aA, aB, nomA, nomB) {
  // On utilise les données pré-calculées si disponibles, sinon un fallback sécurisé
  const sA = aA.sankey || { nodes: [], sources: [], targets: [], values: [], node_colors: [] };
  const sB = aB.sankey || { nodes: [], sources: [], targets: [], values: [], node_colors: [] };

  // Fusion des deux villes dans un seul graphique Sankey
  // Ville A (Bleu)
  const traceA = {
    type: "sankey",
    domain: { x: [0, 0.48] },
    node: {
      pad: 15, thickness: 15,
      line: { color: "black", width: 0.5 },
      label: sA.nodes,
      color: sA.node_colors || "rgba(29, 78, 216, 0.6)"
    },
    link: {
      source: sA.sources,
      target: sA.targets,
      value: sA.values,
      color: "rgba(29, 78, 216, 0.2)"
    }
  };

  // Ville B (Orange)
  const traceB = {
    type: "sankey",
    domain: { x: [0.52, 1] },
    node: {
      pad: 15, thickness: 15,
      line: { color: "black", width: 0.5 },
      label: sB.nodes,
      color: sB.node_colors || "rgba(249, 115, 22, 0.6)"
    },
    link: {
      source: sB.sources,
      target: sB.targets,
      value: sB.values,
      color: "rgba(249, 115, 22, 0.2)"
    }
  };

  Plotly.react('chart-cars-sankey', [traceA, traceB], _baseLayout({
    margin: { t: 20, r: 10, b: 20, l: 10 },
    annotations: [
      { text: nomA, x: 0.25, xref: 'paper', y: 1.05, yref: 'paper', showarrow: false, font: { weight: 700 } },
      { text: nomB, x: 0.75, xref: 'paper', y: 1.05, yref: 'paper', showarrow: false, font: { weight: 700 } }
    ]
  }), PLOTLY_CFG);
}

/**
 * _renderHeatmap()
 * Répartition des accidents par heure.
 */
function _renderHeatmap(aA, aB, nomA, nomB) {
  const heures = Array.from({ length: 24 }, (_, i) => `${i}h`);

  // On utilise les données réelles par heure
  const distA = aA.par_heure || new Array(24).fill(0);
  const distB = aB.par_heure || new Array(24).fill(0);

  Plotly.react('chart-cars-heatmap', [{
    type: 'heatmap',
    z: [distA, distB],
    x: heures,
    y: [nomA, nomB],
    colorscale: 'YlOrRd',
    showscale: false,
    hovertemplate: '%{y} à %{x}<br>Accidents : %{z}<extra></extra>'
  }], _baseLayout({
    margin: { t: 0, r: 10, b: 40, l: 100 },
    height: 150, // On garde une hauteur réduite pour la heatmap temporelle
    xaxis: { tickangle: 0, fixedrange: true },
    yaxis: { fixedrange: true }
  }), PLOTLY_CFG);
}

/**
 * _renderMois()
 * Courbes temporelles mensuelles.
 */
function _renderMois(aA, aB, nomA, nomB) {
  const mois = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
  const valuesA = aA.par_mois || new Array(12).fill(0);
  const valuesB = aB.par_mois || new Array(12).fill(0);

  Plotly.react('chart-cars-mois', [
    {
      type: 'scatter', mode: 'lines+markers', name: nomA,
      x: mois, y: valuesA, line: { color: COLOR_A, shape: 'spline' },
      fill: 'tozeroy', fillcolor: COLOR_A_FILL
    },
    {
      type: 'scatter', mode: 'lines+markers', name: nomB,
      x: mois, y: valuesB, line: { color: COLOR_B, shape: 'spline' },
      fill: 'tozeroy', fillcolor: COLOR_B_FILL
    }
  ], _baseLayout({
    hovermode: 'x unified',
    xaxis: { showgrid: false },
    yaxis: { title: 'Nombre d\'accidents' }
  }), PLOTLY_CFG);
}

/**
 * _renderGravite()
 */
function _renderGravite(aA, aB, nomA, nomB) {
  const labels = ['Indemne', 'Blessé léger', 'Blessé hospitalisé', 'Tué'];
  const gA = aA.gravites || {};
  const gB = aB.gravites || {};

  Plotly.react('chart-cars-gravite', [
    {
      type: 'bar', name: nomA,
      x: labels, y: labels.map(l => gA[l] || 0),
      marker: { color: COLOR_A }
    },
    {
      type: 'bar', name: nomB,
      x: labels, y: labels.map(l => gB[l] || 0),
      marker: { color: COLOR_B }
    }
  ], _baseLayout({
    barmode: 'group',
    yaxis: { title: 'Personnes impliquées' }
  }), PLOTLY_CFG);
}

/**
 * Orchestrateur principal
 */
function renderAccidents(cityA, cityB) {
  const aA = cityA.accidents, aB = cityB.accidents;
  if (!aA || !aB) return;
  const nomA = cityA.base.nom, nomB = cityB.base.nom;

  try { _renderSankey(aA, aB, nomA, nomB); } catch (e) { console.error('[Cars] Sankey error:', e); }
  try { _renderHeatmap(aA, aB, nomA, nomB); } catch (e) { console.error('[Cars] Heatmap error:', e); }
  try { _renderMois(aA, aB, nomA, nomB); } catch (e) { console.error('[Cars] Mois error:', e); }
  try { _renderGravite(aA, aB, nomA, nomB); } catch (e) { console.error('[Cars] Gravite error:', e); }
}

window.CarsChart = { renderAccidents };
