# Urban Insights - Tableau de bord comparatif

## Installation & Démarrage (Plug & Play)

Ce projet est conçu pour être "Zero-Waste" et fonctionner **sans aucun serveur backend**. Les données sont chargées et gérées directement en mémoire via des variables globales (bypassing des restrictions CORS locales).

### Comment lancer l'application :
1. **Extrayez** l'archive du projet sur votre ordinateur.
2. Naviguez dans le dossier `dashboard`.
3. **Double-cliquez** simplement sur le fichier `index.html` pour l'ouvrir dans le navigateur de votre choix (Google Chrome, Firefox, Safari, Edge...).

Aucune installation de dépendance (Node.js, NPM, Python etc.) n'est requise pour visualiser le dashboard et toutes ses fonctionnalités.

## Architecture & Arborescence

Le projet est intentionnellement découpé pour isoler les responsabilités (Données, Logique Transverse, Graphiques spécifiques).

```text
dashboard/
├── index.html          # Page d'accueil vitrine du projet
├── comparateur.html    # Application principale (Tableau de bord Plotly)
├── style.css           # Feuille de style principale (UI Glassmorphism & Dark Mode)
├── app.js              # Orchestrateur principal (Gestion d'état et navigation)
├── dataService.js      # Service de gestion et d'ingestion des bases de données
│
├── data/               # Dossier des bases de données pré-chargées (Variables Globales)
│   ├── villes.js       # Données générales et démographiques
│   ├── meteo.js        # Données historiques climatiques
│   ├── culture.js      # Données sur le tourisme et la culture
│   ├── accidents.js    # Données d'accidentologie (Sankey Diagram)
│   ├── emploi.js       # Données sur l'emploi et statistiques CSP
│   └── logement.js     # Données immobilières
│
├── js/                 # Logique métier et contrôleurs d'affichage Plotly
│   ├── chart-utils.js  # Utilitaires de configuration visuels globaux
│   ├── kpi.js          # Génération dynamique des cartes indicateurs (KPIs)
│   ├── general.js      # Graphiques démographiques (Jauges et barres)
│   ├── weather.js      # Graphiques météo (Heatmap historique & Prévisions)
│   ├── culture.js      # Graphiques culturels (Radar multi-axes)
│   ├── emploi.js       # Graphiques emploi (Sunburst hiérarchique)
│   ├── logement.js     # Graphiques logement (Distributions Violin plots)
│   ├── map.js          # Cartographie interactive (Mapbox)
│   └── cars.js         # Diagrammes de flux transactionnels (Sankey)
│
└── scripts/            # Scripts utilitaires locaux
    └── filterData.js   # Script Node.js de filtrage de population (> 20k habitants)
```

## Fonctionnement Technique

Pour respecter la contrainte du **100% Client-Side** sans bloquer sur les politiques de sécurité CORS des navigateurs modernes (qui interdisent la lecture de fichiers locaux via `fetch`), nous avons opté pour une approche "Zero-Waste" par injection globale :

1. **Ingestion des Données :** Les fichiers dans `data/` ne sont pas de purs JSON. Ils assignent directement leurs objets à des variables globales attchées à la fenêtre (ex: `window.DATA_VILLES = [...]`). Lorsque `comparateur.html` charge ces scripts, les données sont immédiatement disponibles en mémoire.
2. **Orchestration Centrale :** Le fichier `app.js` agit comme le chef d'orchestre. Il initialise le `DataService` pour indexer les villes, puis gère la navigation des onglets via un système performant de **délégation d'événements** (un seul écouteur sur le conteneur parent au lieu de X écouteurs sur chaque bouton de tabulation).
3. **Modularité Visuelle :** Chaque onglet délègue son affichage à un fichier spécifique dans `/js`. Par exemple, cliquer sur l'onglet Météo déclenche spécifiquement `weather.js`, qui pioche les températures dans les données globales et génère un rendu `Plotly.react()` encapsulé.
4. **Appels API Autonomes :** L'application est capable de se connecter indépendamment à des API publiques gratuites (comme `open-meteo.com` dans `weather.js`) de manière asynchrone, complétant ainsi son set de données pré-chargé hors-ligne.

## Équipe & Répartition des Rôles

Ce projet collaboratif a été découpé spécifiquement pour couvrir différentes briques de compétences :
- **🟢 Helena :** Architecte Core (JavaScript pur & manipulation du DOM, configuration globale, données).
- **🟡 Imane :** Graphiques Standards Plotly (Démographie, Météo, Tourisme - Jauges, Heatmap, radar).
- **🔴 Quentin :** Mathématiques & Hiérarchies Plotly Avancé (Sunburst emploi, Violin plots avec distribution log-normale).
- **🟣 Deonna :** Flux Géo-Spatiaux Plotly Avancé (Cartographie multi-couches Mapbox, Diagrammes de flux Sankey).
