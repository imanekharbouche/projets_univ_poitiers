/**
 * @AI_SPACE
 * @purpose : Gestionnaire de la visualisation cartographique avancée (Heatmap + Points).
 * @logic : Combine une couche densitymapbox (chaleur du dynamisme) et une couche scattermapbox (points interactifs).
 * @decisions : usage de Plotly.react pour maintenir l'état du zoom et superposer les couches de données.
 * @references : https://plotly.com/javascript/mapbox-layers/
 */

/* ============================================================
   js/map.js — Visualisation Cartographique Dynamique
============================================================ */

'use strict';

/**
 * Calcule un score de dynamisme enrichi pour une ville (Base 100).
 */
function computeDynamisme(city, emploi, culture, logement, meteo, accidents) {
  // 1. EMPLOI (30 pts)
  const empScore = ((emploi?.taux_chomage || 100) < 8) ? 30 : 15;

  // 2. CULTURE (20 pts)
  const culScore = Math.min((culture?.evenements_annuels || 0) / 15, 20);

  // 3. LOGEMENT (20 pts) : Attractivité par le prix
  const price = logement?.prix_moyen_m2 || 6000;
  let logScore = 5;
  if      (price < 3000) logScore = 20;
  else if (price < 5000) logScore = 15;
  else if (price < 8000) logScore = 10;

  // 4. MÉTÉO (15 pts) : Ensoleillement annuel
  const sunHours = (meteo?.ensoleillement || []).reduce((a, b) => a + (Number(b) || 0), 0);
  const metScore = Math.min(sunHours / 150, 15);

  // 5. SÉCURITÉ (15 pts) : Ratio accidents/population
  const accCount = accidents?.nb_total || 0;
  const ratio = (accCount / (city?.population || 1)) * 500;
  const secScore = Math.max(0, 15 - ratio);

  return Math.min(empScore + culScore + logScore + metScore + secScore, 100);
}

/**
 * renderMap()
 */
function renderMap(villes, codgeoA, codgeoB, allEmploi, allCulture, allLogement, allMeteo, allAccidents) {
  const scores = villes.map(v => computeDynamisme(
    v, 
    allEmploi[v.codgeo], 
    allCulture[v.codgeo], 
    allLogement[v.codgeo],
    allMeteo[v.codgeo],
    allAccidents[v.codgeo]
  ));

  // 1. Couche Heatmap (Densité de dynamisme)
  const traceHeatmap = {
    type: 'densitymapbox',
    lat: villes.map(v => v.lat),
    lon: villes.map(v => v.lon),
    z: scores,
    radius: 25,
    colorscale: 'Viridis',
    showscale: true,
    opacity: 0.4,
    colorbar: {
      title: { text: 'Dynamisme', font: { size: 10 } },
      thickness: 10, len: 0.5, y: 0.5
    },
    showlegend: false,
    hoverinfo: 'none'
  };

  // 2. Couche Points Interactifs (Scatter)
  const tracePoints = {
    type: 'scattermapbox',
    lat: villes.map(v => v.lat),
    lon: villes.map(v => v.lon),
    mode: 'markers',
    marker: {
      size: 8,
      color: 'white',
      opacity: 0.3
    },
    showlegend: false,
    text: villes.map(v => v.nom),
    customdata: villes.map(v => {
      const emp = allEmploi[v.codgeo];
      const cul = allCulture[v.codgeo];
      const log = allLogement[v.codgeo];
      const met = allMeteo[v.codgeo];
      const sun = (met?.ensoleillement || []).reduce((a, b) => a + (Number(b) || 0), 0);
      return [
        v.population ? v.population.toLocaleString('fr-FR') : 'N/C',
        emp ? (emp.taux_chomage + '%') : 'N/C',
        cul ? cul.evenements_annuels : 'N/C',
        log ? (log.prix_moyen_m2 + ' €/m²') : 'N/C',
        sun ? (sun + 'h/an') : 'N/C',
        computeDynamisme(v, emp, cul, log, met, allAccidents[v.codgeo]).toFixed(0)
      ];
    }),
    hovertemplate: 
      '<b>%{text}</b><br><br>' +
      '👥 Pop. : %{customdata[0]}<br>' +
      '💼 Chômage : %{customdata[1]}<br>' +
      '🎭 Culture : %{customdata[2]} evts<br>' +
      '🏠 Immo : %{customdata[3]}<br>' +
      '☀️ Soleil : %{customdata[4]}<br>' +
      '<b>⚡ Score : %{customdata[5]}%</b><br>' +
      '<extra></extra>'
  };

  // 3. Marquage des villes sélectionnées
  const cityA = villes.find(v => v.codgeo === codgeoA);
  const cityB = villes.find(v => v.codgeo === codgeoB);

  const traceSelection = {
    type: 'scattermapbox',
    lat: [cityA?.lat, cityB?.lat].filter(Boolean),
    lon: [cityA?.lon, cityB?.lon].filter(Boolean),
    mode: 'markers+text',
    text: [cityA?.nom, cityB?.nom].filter(Boolean),
    textposition: 'top center',
    marker: {
      size: 15,
      color: '#DC2626',
      opacity: 1
    },
    hoverinfo: 'none',
    showlegend: false
  };

  const layout = {
    mapbox: {
      style: 'carto-positron', 
      center: { lat: 46.5, lon: 2.5 },
      zoom: 4.8
    },
    margin: { t: 0, r: 0, b: 0, l: 0 },
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)'
  };

  try {
    Plotly.react('map-container', [traceHeatmap, tracePoints, traceSelection], layout, PLOTLY_CFG);
  } catch (err) {
    console.error('[MapChart] Erreur lors du rendu de la carte:', err);
    const container = document.getElementById('map-container');
    if (container) {
      container.innerHTML = `<div class="alert error">Erreur de rendu de la carte.</div>`;
    }
  }
}

window.MapChart = { renderMap };
